"""前端整合測試用的小工具:從 migrations 解析資料表欄位,產生假 Supabase 的 schema 與 seed。"""
import json, re, glob, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)           # repo/

def parse_schema():
    sql = ''
    for f in sorted(glob.glob(os.path.join(ROOT, 'supabase/migrations/*.sql'))):
        sql += open(f, encoding='utf-8').read() + '\n'
    sql = re.sub(r'--[^\n]*', '', sql)
    out = {}
    for m in re.finditer(r'create table if not exists public\.(\w+)\s*\(', sql):
        name = m.group(1); i = m.end(); depth = 1; j = i
        while depth:
            c = sql[j]
            depth += (c == '(') - (c == ')'); j += 1
        body = sql[i:j - 1]
        parts, d, cur = [], 0, ''
        for ch in body:
            if ch == '(': d += 1
            if ch == ')': d -= 1
            if ch == ',' and d == 0: parts.append(cur); cur = ''
            else: cur += ch
        parts.append(cur)
        t = dict(cols={}, pk=[], unique=[], autoid=False, idtype=None)
        for p in parts:
            p = ' '.join(p.split())
            if not p: continue
            low = p.lower()
            if low.startswith('primary key'):
                t['pk'] = [x.strip() for x in re.search(r'\((.*)\)', p).group(1).split(',')]; continue
            if re.match(r'(unique|check|constraint|foreign key)', low):
                mu = re.match(r'unique \((\w+)\)', low)
                continue
            col = p.split(' ')[0]
            rest = low[len(col):]
            c = dict(required=('not null' in rest or 'primary key' in rest))
            if 'primary key' in rest: t['pk'] = [col]
            if ' unique' in rest and 'primary key' not in rest: t['unique'].append(col)
            if 'generated always as identity' in rest:
                t['autoid'] = True; t['idtype'] = 'int'; c['required'] = False
            elif 'gen_random_uuid()' in rest:
                t['autoid'] = True; t['idtype'] = 'uuid'; c['required'] = False
            md = re.search(r' default (\'[^\']*\'|true|false|-?\d+|now\(\))', rest)
            if md:
                v = md.group(1); c['required'] = False
                if v.startswith("'"): c['def'] = v.strip("'")
                elif v in ('true', 'false'): c['def'] = (v == 'true')
                elif v == 'now()': pass
                else: c['def'] = int(v)
            t['cols'][col] = c
        out[name] = t
    # alter table public.X add column if not exists ...
    for m in re.finditer(r'alter table public\.(\w+)\s+(add column if not exists[^;]*);', sql):
        t = out[m.group(1)]; body = m.group(2); parts, d, cur = [], 0, ''
        for ch in body:
            if ch == '(': d += 1
            if ch == ')': d -= 1
            if ch == ',' and d == 0: parts.append(cur); cur = ''
            else: cur += ch
        parts.append(cur)
        for p in parts:
            p = ' '.join(p.split()); p = re.sub(r'^add column if not exists ', '', p)
            col = p.split(' ')[0]; rest = p.lower()[len(col):]
            c = dict(required=('not null' in rest))
            md = re.search(r" default ('[^']*'|true|false|-?\d+)", rest)
            if md:
                c['required'] = False; v = md.group(1)
                if v.startswith("'"): c['def'] = v.strip("'")
                elif v in ('true', 'false'): c['def'] = (v == 'true')
                else: c['def'] = int(v)
            t['cols'][col] = c
    return out

def seed():
    sys.path.insert(0, ROOT + '/..')
    import importlib
    cwd = os.getcwd(); os.chdir(ROOT + '/..')
    content = importlib.import_module('content')
    os.chdir(cwd)
    d = dict(
        products=[dict(id=p['id'], kind='physical', name=p['name'], title=p['title'], price=p['price'], active=True, sort=i) for i, p in enumerate(content.PRODUCTS)],
        courses=[dict(id=c['id'], name=c['name'], price=0, status='draft', sort=i) for i, c in enumerate(content.COURSES)],
        course_chapters=[], chapter_videos=[],
        plans=[dict(id='monthly', name='月繳', amount=100, period_type='M', frequency=1, exec_times=99, active=True, sort=0),
               dict(id='yearly', name='年繳', amount=1000, period_type='Y', frequency=1, exec_times=9, active=True, sort=1)],
        site_settings=[dict(key='payments_enabled', value=True, updated_at='2026-01-01'), dict(key='line_url', value='', updated_at='2026-01-01'), dict(key='youtube_url', value='', updated_at='2026-01-01')],
        resources=[dict(id='r1', name='學測國寫全攻略 試讀', gate=True, storage_path='r1.pdf', href=None), dict(id='r2', name='教材完整目錄', gate=True, storage_path=None, href=None),
                   dict(id='r3', name='Instagram 學習貼文', gate=False, storage_path=None, href='https://www.instagram.com/chinese.win/')],
        admin_emails=['teacher@example.com'], profiles=[], memberships=[], enrollments=[], resource_claims=[], orders=[], order_items=[], payments=[],
        essays=[], essay_files=[], feedback_templates=[dict(id=1, label='立意明確', body='立意明確,主旨能貫串全文。', sort_order=1)], _seq_feedback_templates=1, live_events=[], live_links=[], contact_messages=[], progress=[])
    n = 0
    for c in content.COURSES:
        for i, t in enumerate(c['chaps']):
            n += 1
            d['course_chapters'].append(dict(id=n, course_id=c['id'], position=i, title=t, is_preview=False))
    d['_seq_course_chapters'] = n
    return d

def fake_js():
    return 'window.__SCHEMA=%s;window.__SEED=%s;\n%s' % (json.dumps(parse_schema()), json.dumps(seed(), ensure_ascii=False), open(os.path.join(HERE, 'fake-supabase.js'), encoding='utf-8').read())

if __name__ == '__main__':
    s = parse_schema()
    for k, v in s.items(): print(k, list(v['cols']), 'pk', v['pk'], 'auto', v['idtype'])
