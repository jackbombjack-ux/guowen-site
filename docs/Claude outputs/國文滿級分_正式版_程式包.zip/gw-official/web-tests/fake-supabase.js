/* 測試用的假 Supabase:把 supabase-js 的 UMD 換成這支,用瀏覽器 localStorage 當資料庫。
 * 它會依 window.__SCHEMA(由 migrations 解析出來)檢查欄位名稱,欄位寫錯就會丟錯。
 * 權限規則(RLS)不在這裡測,那是 supabase/tests 的工作。 */
(function(){
var DBK='fake-db',SK='fake-session',CK='fake-calls';
var SCHEMA=window.__SCHEMA||{};
function load(){try{return JSON.parse(localStorage.getItem(DBK))||null}catch(e){return null}}
function save(d){localStorage.setItem(DBK,JSON.stringify(d))}
var DB=load();
if(!DB){DB=JSON.parse(JSON.stringify(window.__SEED||{}));save(DB)}
function T(t){if(!SCHEMA[t])throw new Error('FAKE: unknown table '+t);DB[t]=DB[t]||[];return DB[t]}
function calls(){try{return JSON.parse(localStorage.getItem(CK))||[]}catch(e){return []}}
function logCall(n,b){var c=calls();c.push({name:n,body:b});localStorage.setItem(CK,JSON.stringify(c))}
function uid(){return crypto.randomUUID()}
function session(){try{return JSON.parse(localStorage.getItem(SK))}catch(e){return null}}
function cur(){var s=session();return s&&s.user}
function isAdminU(){var u=cur();if(!u)return false;var p=T('profiles').find(function(x){return x.id===u.id});return !!(p&&p.role==='admin')}
function checkCols(t,cols,what){cols.forEach(function(c){if(!SCHEMA[t].cols[c])throw new Error('FAKE: '+what+' column "'+c+'" does not exist on '+t)})}
function splitTop(s){var out=[],d=0,cur='';for(var i=0;i<s.length;i++){var ch=s[i];if(ch==='(')d++;if(ch===')')d--;if(ch===','&&d===0){out.push(cur);cur=''}else cur+=ch}if(cur.trim())out.push(cur);return out.map(function(x){return x.trim()})}
var EMBED={order_items:{fk:'order_id'},essay_files:{fk:'essay_id'}};
function project(t,row,sel){
  if(sel==='*'||!sel)return Object.assign({},row);
  var o={};
  splitTop(sel).forEach(function(part){
    var m=part.match(/^(\w+)\((.*)\)$/);
    if(m){
      var ch=m[1],e=EMBED[ch];if(!e)throw new Error('FAKE: unsupported embed '+ch);
      T(ch);checkCols(ch,splitTop(m[2]).filter(function(c){return c!=='*'}),'embed select');
      o[ch]=T(ch).filter(function(r){return r[e.fk]===row.id}).map(function(r){return project(ch,r,m[2])});
    }else if(part==='*'){Object.assign(o,row)}
    else{checkCols(t,[part],'select');o[part]=row[part]===undefined?null:row[part]}
  });
  return o;
}
function B(t){
  T(t);
  var q={t:t,op:'select',sel:'*',filters:[],order:[],lim:null,single:null,count:null,head:false,rows:null,onConflict:null,ret:false};
  var api={
    select:function(s,o){if(q.op==='select'){q.sel=s||'*';if(o){q.count=o.count;q.head=!!o.head}}else{q.ret=true;q.sel=s||'*'}return api},
    insert:function(r){q.op='insert';q.rows=Array.isArray(r)?r:[r];return api},
    update:function(p){q.op='update';q.rows=p;return api},
    upsert:function(r,o){q.op='upsert';q.rows=Array.isArray(r)?r:[r];q.onConflict=o&&o.onConflict;return api},
    delete:function(){q.op='delete';return api},
    eq:function(c,v){checkCols(t,[c],'eq');q.filters.push(function(r){return r[c]===v});return api},
    in:function(c,vs){checkCols(t,[c],'in');q.filters.push(function(r){return vs.indexOf(r[c])>-1});return api},
    gte:function(c,v){checkCols(t,[c],'gte');q.filters.push(function(r){return r[c]>=v});return api},
    order:function(c,o){checkCols(t,[c],'order');q.order.push({c:c,asc:!(o&&o.ascending===false)});return api},
    limit:function(n){q.lim=n;return api},
    maybeSingle:function(){q.single='maybe';return api},
    single:function(){q.single='one';return api},
    then:function(res,rej){return Promise.resolve().then(run).then(res,rej)}
  };
  function err(m,code){return {data:null,error:{message:m,code:code||'FAKE'}}}
  function run(){
    var S=SCHEMA[t],rows;
    try{
      if(q.op==='insert'||q.op==='upsert'){
        var out=[];
        for(var i=0;i<q.rows.length;i++){
          var r=Object.assign({},q.rows[i]);checkCols(t,Object.keys(r),'insert');
          S.autoid&&r.id===undefined&&(r.id=S.idtype==='uuid'?uid():(DB['_seq_'+t]=(DB['_seq_'+t]||0)+1));
          if(S.cols.created_at&&r.created_at===undefined)r.created_at=new Date().toISOString();
          Object.keys(S.cols).forEach(function(c){if(S.cols[c].def!==undefined&&r[c]===undefined)r[c]=S.cols[c].def});
          for(var c in S.cols){if(S.cols[c].required&&(r[c]===undefined||r[c]===null))return err('null value in column "'+c+'" of relation "'+t+'" violates not-null constraint','23502')}
          var pk=q.op==='upsert'&&q.onConflict?q.onConflict.split(','):S.pk;
          var ex=T(t).find(function(x){return pk.every(function(k){return x[k]===r[k]})});
          if(ex){
            if(q.op==='insert')return err('duplicate key value violates unique constraint','23505');
            Object.assign(ex,r);out.push(ex);continue;
          }
          if(S.unique)for(var u=0;u<S.unique.length;u++){var uk=S.unique[u];if(T(t).some(function(x){return x[uk]===r[uk]&&r[uk]!==undefined}))return err('duplicate key value violates unique constraint','23505')}
          T(t).push(r);out.push(r);
        }
        save(DB);rows=out;
      }else{
        rows=T(t).filter(function(r){return q.filters.every(function(f){return f(r)})});
        if(q.op==='update'){checkCols(t,Object.keys(q.rows),'update');rows.forEach(function(r){Object.assign(r,q.rows)});save(DB)}
        if(q.op==='delete'){DB[t]=T(t).filter(function(r){return rows.indexOf(r)<0});save(DB)}
      }
      if(q.op==='select'){
        q.order.slice().reverse().forEach(function(o){rows=rows.slice().sort(function(a,b){var x=a[o.c],y=b[o.c];if(x===y)return 0;if(x==null)return 1;if(y==null)return -1;return (x<y?-1:1)*(o.asc?1:-1)})});
        if(q.lim!=null)rows=rows.slice(0,q.lim);
      }
      var cnt=rows.length;
      if(q.op==='select'||q.ret){
        if(q.head)return {data:null,error:null,count:cnt};
        var pr=rows.map(function(r){return project(t,r,q.sel)});
        if(q.single){
          if(pr.length>1)return err('multiple rows returned','PGRST116');
          if(pr.length===0)return q.single==='maybe'?{data:null,error:null}:err('no rows','PGRST116');
          return {data:pr[0],error:null};
        }
        return {data:pr,error:null,count:cnt};
      }
      return {data:null,error:null};
    }catch(e){return {data:null,error:{message:e.message,code:'FAKE_THROW'}}}
  }
  return api;
}
var authCbs=[];
function ensureProfile(u){
  var p=T('profiles').find(function(x){return x.id===u.id});
  if(!p){var admin=(DB.admin_emails||[]).indexOf(u.email)>-1;T('profiles').push({id:u.id,email:u.email,name:u.user_metadata.full_name,avatar_url:null,role:admin?'admin':'student',created_at:new Date().toISOString()});save(DB)}
}
var FILES=function(){DB._files=DB._files||{};return DB._files};
var FN={
 'create-order':function(body){
   var u=cur();if(!u)return {error:'請先登入'};
   var no='GW'+Date.now().toString().slice(-8)+Math.floor(Math.random()*90+10);
   var o={id:uid(),merchant_trade_no:no,user_id:u.id,status:'pending',fulfillment:'none',created_at:new Date().toISOString()};
   if(window.__FN_FAIL)return {error:window.__FN_FAIL};
   if(body.type==='membership'){var pl=T('plans').find(function(p){return p.id===body.plan&&p.active});if(!pl)return {error:'方案不存在'};Object.assign(o,{kind:'membership',amount:pl.amount,plan_id:pl.id})}
   else if(body.type==='course'){var c=T('courses').find(function(p){return p.id===body.course});if(!c)return {error:'找不到課程'};Object.assign(o,{kind:'course',amount:c.price,course_id:c.id})}
   else if(body.type==='cart'){
     var tot=0,items=[];body.items.forEach(function(i){var p=T('products').find(function(x){return x.id===i.id&&x.active});if(!p)throw new Error('有商品已下架或不存在');tot+=p.price*i.qty;items.push({product_id:p.id,name:p.name,unit_price:p.price,qty:i.qty})});
     if(!body.recipient||!body.recipient.name)return {error:'請填寫收件資料'};
     Object.assign(o,{kind:'product',amount:tot,recipient_name:body.recipient.name,recipient_phone:body.recipient.phone,recipient_address:body.recipient.address,note:body.note||null});
     items.forEach(function(it){it.order_id=o.id;T('order_items').push(it)});
   }else return {error:'不支援的訂單類型'};
   T('orders').push(o);save(DB);
   return {url:'https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5',fields:{MerchantID:'3002607',MerchantTradeNo:no,TotalAmount:String(o.amount),CheckMacValue:'X'},tradeNo:no};
 },
 'transcribe-essay':function(body){var u=cur();var e=T('essays').find(function(x){return x.id===body.essay_id});var adm=(T('profiles').find(function(x){return x.id===u.id})||{}).role==='admin';if(!e||(!adm&&e.student_id!==u.id))return {error:'找不到這篇作文'};if(window.__TRANSCRIBE_FAIL){e.transcript_status='failed';save(DB);return {error:'辨識暫時失敗'}}if(!adm&&e.transcript_status==='done')return {ok:true,already:true};if(typeof body.save_text==='string'){if(!body.save_text.trim())return {error:'辨識結果是空的'};e.transcript=body.save_text;e.transcript_status='done';e.transcript_engine='tesseract';e.transcript_at=new Date().toISOString();save(DB);return {ok:true,engine:'tesseract'}}if(window.__OCR_FALLBACK){window.__FALLBACK_CALLS=(window.__FALLBACK_CALLS||0)+1;return {ok:false,fallback:'client',reason:'quota'}}e.transcript='第一段:今天天氣很好。\n第二段:我們去公園。';e.transcript_status='done';e.transcript_engine='vision';e.transcript_at=new Date().toISOString();save(DB);return {ok:true}},
 'notify-graded':function(body){var u=cur();var adm=(T('profiles').find(function(x){return x.id===u.id})||{}).role==='admin';if(!adm)return {error:'沒有權限'};var e=T('essays').find(function(x){return x.id===body.essay_id});if(!e||e.status!=='graded'||!e.student_id)return {ok:false,reason:'not_applicable'};if(window.__NO_MAIL_KEY)return {ok:false,reason:'no_key'};if(e.notified_at)return {ok:true,already:true};e.notified_at=new Date().toISOString();save(DB);return {ok:true}},
 'cancel-membership':function(){var u=cur();var m=T('memberships').find(function(x){return x.user_id===u.id});if(!m)return {error:'你目前沒有付費會員'};m.status='cancelled';save(DB);return {ok:true}}
};
function client(url,key){
  return {
   auth:{
     getSession:async function(){var s=session();return {data:{session:s},error:null}},
     onAuthStateChange:function(cb){authCbs.push(cb);setTimeout(function(){cb('INITIAL_SESSION',session())},0);return {data:{subscription:{unsubscribe:function(){}}}}},
     signInWithOAuth:async function(o){
       var who=localStorage.getItem('fake-next-user')||'student';
       var P={student:{id:'00000000-0000-0000-0000-0000000000b1',email:'student@example.com',user_metadata:{full_name:'王小明'}},student2:{id:'00000000-0000-0000-0000-0000000000c1',email:'other@example.com',user_metadata:{full_name:'李同學'}},teacher:{id:'00000000-0000-0000-0000-0000000000a1',email:'teacher@example.com',user_metadata:{full_name:'國文老師'}}};
       var u=P[who];localStorage.setItem(SK,JSON.stringify({access_token:'t',user:u}));ensureProfile(u);
       localStorage.setItem('fake-oauth-calls',String((+localStorage.getItem('fake-oauth-calls')||0)+1));
       location.href=o.options.redirectTo;return {data:{},error:null};
     },
     signOut:async function(){localStorage.removeItem(SK);authCbs.forEach(function(cb){cb('SIGNED_OUT',null)});return {error:null}}
   },
   from:B,
   rpc:async function(name,args){
     if(name==='enroll_free'){
       var u=cur();if(!u)return {data:null,error:{message:'not authenticated'}};
       var c=T('courses').find(function(x){return x.id===args.p_course});
       if(!c||c.status!=='open')return {data:null,error:{message:'課程尚未開放'}};
       if(c.price>0)return {data:null,error:{message:'這門課需要付費'}};
       if(!T('enrollments').some(function(e){return e.user_id===u.id&&e.course_id===c.id})){T('enrollments').push({user_id:u.id,course_id:c.id,source:'free',created_at:new Date().toISOString()});save(DB)}
       return {data:null,error:null};
     }
     if(name==='mark_essays_seen'){var u2=cur();var n=0;if(u2)T('essays').forEach(function(e){if(e.student_id===u2.id&&e.status==='graded'&&!e.student_seen_at){e.student_seen_at=new Date().toISOString();n++}});save(DB);return {data:n,error:null}}
     return {data:null,error:{message:'FAKE: unknown rpc '+name}};
   },
   storage:{from:function(bucket){return {
     upload:async function(path,file,opts){
       if(!file||!file.size)return {data:null,error:{message:'empty file'}};
       if(!opts||!opts.contentType)return {data:null,error:{message:'FAKE: contentType required'}};
       if(window.__UPLOAD_FAIL_AT!==undefined&&Object.keys(FILES()).length>=window.__UPLOAD_FAIL_AT)return {data:null,error:{message:'upload failed'}};
       var key=bucket+'/'+path;if(FILES()[key])return {data:null,error:{message:'The resource already exists'}};
       var parent=T('essays').find(function(e){return bucket==='essays'&&e.id===path.split('/')[0]});
       if(bucket==='essays'&&!parent)return {data:null,error:{message:'new row violates row-level security policy'}};
       FILES()[key]={size:file.size,type:opts.contentType};save(DB);return {data:{path:path},error:null};
     },
     remove:async function(paths){paths.forEach(function(p){delete FILES()[bucket+'/'+p]});save(DB);return {data:[],error:null}},
     createSignedUrl:async function(path){return {data:{signedUrl:'data:image/gif;base64,R0lGODlhAQABAAAAACw=#'+bucket+'/'+path},error:null}},
     createSignedUrls:async function(paths){return {data:paths.map(function(p){return {path:p,signedUrl:'data:image/gif;base64,R0lGODlhAQABAAAAACw=#'+bucket+'/'+p,error:null}}),error:null}}
   }}},
   functions:{invoke:async function(name,o){
     logCall(name,o&&o.body);
     if(!cur())return {data:null,error:{message:'unauth',context:{json:async function(){return {error:'請先登入'}}}}};
     try{var r=FN[name](o.body);
       if(r.error)return {data:null,error:{message:'non-2xx',context:{json:async function(){return {error:r.error}}}}};
       return {data:r,error:null};
     }catch(e){return {data:null,error:{message:'non-2xx',context:{json:async function(){return {error:e.message}}}}}}
   }}
  };
}
window.supabase={createClient:client};
window.__fake={
  db:function(){return DB},reload:function(){DB=load()},save:function(){save(DB)},calls:calls,
  markPaid:function(no){
    var o=T('orders').find(function(x){return x.merchant_trade_no===no});if(!o)throw new Error('no order');
    o.status='paid';o.paid_at=new Date().toISOString();
    if(o.kind==='membership'){var pl=T('plans').find(function(p){return p.id===o.plan_id});var ex=T('memberships').find(function(m){return m.user_id===o.user_id});var base=ex&&new Date(ex.valid_until)>new Date()?new Date(ex.valid_until):new Date();var until=new Date(base.getTime()+(pl.period_type==='Y'?365:30)*864e5).toISOString();
      if(ex)Object.assign(ex,{plan:pl.id,status:'active',valid_until:until,source:'ecpay',order_id:o.id});else T('memberships').push({user_id:o.user_id,plan:pl.id,status:'active',valid_until:until,source:'ecpay',order_id:o.id,updated_at:new Date().toISOString()})}
    if(o.kind==='course')T('enrollments').push({user_id:o.user_id,course_id:o.course_id,source:'order',created_at:new Date().toISOString()});
    if(o.kind==='product')o.fulfillment='to_ship';
    save(DB);
  }
};
})();
