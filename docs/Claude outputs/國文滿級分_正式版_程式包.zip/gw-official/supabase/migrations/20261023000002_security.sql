-- 國文滿級分 正式版資料庫:函式、觸發器、RLS(列級權限)

-- ============================================================ 身分判斷函式
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

-- 付費會員:已付款涵蓋期間 + 3 天寬限(綠界扣款偶爾晚一兩天)
create or replace function public.is_member(uid uuid default auth.uid()) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.memberships m
    where m.user_id = uid and m.valid_until + interval '3 days' > now()
  );
$$;

create or replace function public.is_enrolled(cid text, uid uuid default auth.uid()) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.enrollments e where e.user_id = uid and e.course_id = cid);
$$;

-- ============================================================ 新使用者自動建立 profile
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  v_email text := lower(coalesce(new.email, ''));
begin
  insert into public.profiles (id, email, name, avatar_url, role)
  values (
    new.id, v_email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(v_email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url',
    case when exists (select 1 from public.admin_emails a where a.email = v_email) then 'admin' else 'student' end
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 之後才把 Email 加進 admin_emails 時,也同步升級已存在的帳號
create or replace function public.sync_admin_email() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  update public.profiles set role = 'admin' where lower(email) = new.email;
  return new;
end $$;
drop trigger if exists on_admin_email_added on public.admin_emails;
create trigger on_admin_email_added after insert on public.admin_emails
  for each row execute function public.sync_admin_email();

-- 學生不能自己改 role / email
create or replace function public.protect_profile() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  -- 只限制「已登入的一般學生」;後台維護、觸發器與 service role 沒有 auth.uid(),不受影響
  if auth.uid() is not null and not public.is_admin() and (new.role <> old.role or new.email <> old.email or new.id <> old.id) then
    raise exception 'not allowed';
  end if;
  return new;
end $$;
drop trigger if exists protect_profile_trg on public.profiles;
create trigger protect_profile_trg before update on public.profiles
  for each row execute function public.protect_profile();

-- ============================================================ 報名(免費課程)
create or replace function public.enroll_free(p_course text) returns void
language plpgsql security definer set search_path = '' as $$
declare v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'login required'; end if;
  if not exists (select 1 from public.courses c where c.id = p_course and c.status = 'open' and c.price = 0) then
    raise exception 'course not open for free enrollment';
  end if;
  insert into public.enrollments (user_id, course_id, source) values (v_uid, p_course, 'free')
  on conflict do nothing;
end $$;

-- ============================================================ 付款通知處理(只有 service_role 能呼叫)
-- 綠界 ReturnURL / PeriodReturnURL 驗證過檢查碼後,由 Edge Function 呼叫。
-- event_key 保證同一筆通知重複送達也只處理一次。
create or replace function public.apply_payment(
  p_trade_no text, p_event_key text, p_seq int, p_amount int, p_success boolean,
  p_ecpay_trade_no text, p_gwsr text, p_rtn_code text, p_rtn_msg text, p_raw jsonb
) returns text
language plpgsql security definer set search_path = '' as $$
declare
  v_order public.orders%rowtype;
  v_plan  public.plans%rowtype;
  v_pid   bigint;
  v_base  timestamptz;
  v_until timestamptz;
  v_cur   timestamptz;
begin
  select * into v_order from public.orders where merchant_trade_no = p_trade_no for update;
  if not found then return 'unknown_order'; end if;

  if p_amount is distinct from v_order.amount then
    insert into public.payments (order_id, event_key, seq, amount, status, ecpay_trade_no, gwsr, rtn_code, rtn_msg, raw)
    values (v_order.id, p_event_key, p_seq, coalesce(p_amount, 0), 'failed', p_ecpay_trade_no, p_gwsr, p_rtn_code, 'amount mismatch: ' || coalesce(p_rtn_msg, ''), p_raw)
    on conflict (event_key) do nothing;
    return 'amount_mismatch';
  end if;

  insert into public.payments (order_id, event_key, seq, amount, status, ecpay_trade_no, gwsr, rtn_code, rtn_msg, raw)
  values (v_order.id, p_event_key, p_seq, p_amount, case when p_success then 'success' else 'failed' end,
          p_ecpay_trade_no, p_gwsr, p_rtn_code, p_rtn_msg, p_raw)
  on conflict (event_key) do nothing
  returning id into v_pid;
  if v_pid is null then return 'duplicate'; end if;

  if not p_success then
    if v_order.status = 'pending' and p_seq = 1 then
      update public.orders set status = 'failed' where id = v_order.id;
    end if;
    return 'failed_recorded';
  end if;

  if v_order.status = 'pending' then
    update public.orders set status = 'paid', paid_at = now(), ecpay_trade_no = coalesce(p_ecpay_trade_no, ecpay_trade_no)
    where id = v_order.id;
  end if;

  if v_order.kind = 'product' then
    update public.orders o set fulfillment = case when exists (
        select 1 from public.order_items oi join public.products p on p.id = oi.product_id
        where oi.order_id = o.id and p.kind = 'physical') then 'to_ship' else 'done' end
    where o.id = v_order.id and o.fulfillment = 'none';

  elsif v_order.kind = 'course' then
    insert into public.enrollments (user_id, course_id, source) values (v_order.user_id, v_order.course_id, 'order')
    on conflict do nothing;

  elsif v_order.kind = 'membership' then
    select * into v_plan from public.plans where id = v_order.plan_id;
    select valid_until into v_cur from public.memberships where user_id = v_order.user_id;
    -- 還在有效(含寬限)期間內就從原到期日往後接,避免寬限天數一期一期累積
    v_base := case when v_cur is not null and v_cur + interval '3 days' > now() then v_cur else now() end;
    v_until := v_base + case v_plan.period_type
        when 'M' then make_interval(months => v_plan.frequency)
        when 'Y' then make_interval(years  => v_plan.frequency)
        else make_interval(days => v_plan.frequency) end;
    insert into public.memberships (user_id, plan, status, valid_until, source, order_id, updated_at)
    values (v_order.user_id, v_order.plan_id, 'active', v_until, 'ecpay', v_order.id, now())
    on conflict (user_id) do update
      set plan = excluded.plan, status = 'active', valid_until = excluded.valid_until,
          source = 'ecpay', order_id = excluded.order_id, updated_at = now();
  end if;

  return 'applied';
end $$;

revoke all on function public.apply_payment(text,text,int,int,boolean,text,text,text,text,jsonb) from public, anon, authenticated;
grant execute on function public.apply_payment(text,text,int,int,boolean,text,text,text,text,jsonb) to service_role;
revoke all on function public.enroll_free(text) from public, anon;
grant execute on function public.enroll_free(text) to authenticated;

-- ============================================================ RLS
alter table public.admin_emails     enable row level security;
alter table public.profiles         enable row level security;
alter table public.site_settings    enable row level security;
alter table public.products         enable row level security;
alter table public.courses          enable row level security;
alter table public.course_chapters  enable row level security;
alter table public.chapter_videos   enable row level security;
alter table public.enrollments      enable row level security;
alter table public.progress         enable row level security;
alter table public.plans            enable row level security;
alter table public.memberships      enable row level security;
alter table public.orders           enable row level security;
alter table public.order_items      enable row level security;
alter table public.payments         enable row level security;
alter table public.resources        enable row level security;
alter table public.resource_claims  enable row level security;
alter table public.live_events      enable row level security;
alter table public.live_links       enable row level security;
alter table public.essays           enable row level security;
alter table public.essay_files      enable row level security;
alter table public.contact_messages enable row level security;

-- admin_emails:只有 admin 看得到與管理
create policy admin_emails_all on public.admin_emails for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- profiles
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
create policy profiles_update_self on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on public.profiles for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- 公開內容:所有人可讀,老師可寫
create policy settings_read  on public.site_settings for select to anon, authenticated using (true);
create policy settings_write on public.site_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy products_read  on public.products for select to anon, authenticated using (active or public.is_admin());
create policy products_write on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy courses_read   on public.courses for select to anon, authenticated using (true);
create policy courses_write  on public.courses for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy chapters_read  on public.course_chapters for select to anon, authenticated using (true);
create policy chapters_write on public.course_chapters for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy videos_read on public.chapter_videos for select to anon, authenticated using (
  public.is_admin()
  or exists (select 1 from public.course_chapters ch
             where ch.id = chapter_id
               and (ch.is_preview or public.is_enrolled(ch.course_id)))
);
create policy videos_write on public.chapter_videos for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy plans_read  on public.plans for select to anon, authenticated using (active or public.is_admin());
create policy plans_write on public.plans for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy resources_read  on public.resources for select to anon, authenticated using (true);
create policy resources_write on public.resources for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy live_events_read  on public.live_events for select to anon, authenticated using (true);
create policy live_events_write on public.live_events for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 會員限定直播連結:付費會員與老師才讀得到(沒登入、未付費者即使知道網址也查不到)
create policy live_links_read  on public.live_links for select to authenticated using (public.is_member() or public.is_admin());
create policy live_links_write on public.live_links for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 報名、進度
create policy enroll_read  on public.enrollments for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy enroll_admin on public.enrollments for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy progress_own on public.progress for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_enrolled(course_id));
create policy progress_admin_read on public.progress for select to authenticated using (public.is_admin());

-- 會員資格:本人唯讀;老師可手動開通/停用
create policy memberships_read  on public.memberships for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy memberships_admin on public.memberships for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 訂單、付款:本人唯讀;老師可讀並更新出貨狀態。建立訂單一律走 Edge Function(伺服器端算價格)
create policy orders_read on public.orders for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy orders_admin_update on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy order_items_read on public.order_items for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));
create policy payments_read on public.payments for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));

-- 資源領取
create policy claims_read   on public.resource_claims for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy claims_insert on public.resource_claims for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.resources r where r.id = resource_id and r.gate));

-- 作文
create policy essays_read on public.essays for select to authenticated using (student_id = auth.uid() or public.is_admin());
create policy essays_insert_student on public.essays for insert to authenticated with check (
  source = 'student' and student_id = auth.uid() and created_by = auth.uid()
  and status = 'pending' and feedback is null and graded_at is null and graded_by is null and source_note is null);
create policy essays_insert_teacher on public.essays for insert to authenticated with check (
  source = 'teacher' and student_id is null and created_by = auth.uid() and public.is_admin());
create policy essays_update_admin on public.essays for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy essays_delete_admin on public.essays for delete to authenticated using (public.is_admin());

create policy essay_files_read on public.essay_files for select to authenticated using (
  exists (select 1 from public.essays e where e.id = essay_id and (e.student_id = auth.uid() or public.is_admin())));
create policy essay_files_insert_student on public.essay_files for insert to authenticated with check (
  kind = 'submission' and exists (select 1 from public.essays e
    where e.id = essay_id and e.student_id = auth.uid() and e.status = 'pending'));
create policy essay_files_insert_admin on public.essay_files for insert to authenticated with check (public.is_admin());
create policy essay_files_delete_admin on public.essay_files for delete to authenticated using (public.is_admin());

-- 聯絡表單:任何人可送出,只有老師能讀
create policy contact_insert on public.contact_messages for insert to anon, authenticated with check (true);
create policy contact_read   on public.contact_messages for select to authenticated using (public.is_admin());

-- ============================================================ 資料表權限(RLS 之外的第一道門)
grant usage on schema public to anon, authenticated, service_role;
grant select on public.site_settings, public.products, public.courses, public.course_chapters,
               public.chapter_videos, public.plans, public.resources, public.live_events to anon;
grant insert on public.contact_messages to anon;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant all on all tables in schema public to service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;
-- 學生只能新增/讀取,不能改掉自己的訂單等:由 RLS 把關,上面 grant 只是讓 RLS 有機會評估
revoke insert, update, delete on public.orders, public.order_items, public.payments from authenticated;
grant update on public.orders to authenticated;   -- 僅老師(RLS)可更新出貨狀態
revoke insert, delete on public.profiles from authenticated;
