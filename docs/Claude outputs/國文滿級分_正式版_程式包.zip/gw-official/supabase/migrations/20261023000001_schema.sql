-- 國文滿級分 正式版資料庫:資料表
-- 在 Supabase SQL Editor 或 `supabase db push` 執行。可重複執行的部分都用 if not exists。

create extension if not exists pgcrypto;

-- ============================================================ 帳號
-- 老師的 Google 帳號 Email 放這張表,第一次登入時會自動成為 admin
create table if not exists public.admin_emails (
  email text primary key check (email = lower(email))
);

create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text not null,
  name       text,
  avatar_url text,
  role       text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

-- ============================================================ 網站設定
create table if not exists public.site_settings (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);

-- ============================================================ 商品與課程
create table if not exists public.products (
  id         text primary key,
  kind       text not null default 'physical' check (kind in ('physical','digital')),
  name       text not null,
  title      text not null,
  price      int  not null check (price >= 0),
  active     boolean not null default true,
  sort       int  not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.courses (
  id         text primary key,
  name       text not null,
  price      int  not null default 0 check (price >= 0),   -- 0 = 免費報名
  status     text not null default 'draft' check (status in ('draft','open')),  -- draft=籌備中 open=開放報名
  sort       int  not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.course_chapters (
  id         bigint generated always as identity primary key,
  course_id  text not null references public.courses(id) on delete cascade,
  position   int  not null check (position >= 0),
  title      text not null,
  is_preview boolean not null default false,               -- 試看章節:未報名也能看
  unique (course_id, position)
);

-- 影片代碼和章節分開存,才能用 RLS 只給報名的人看
create table if not exists public.chapter_videos (
  chapter_id bigint primary key references public.course_chapters(id) on delete cascade,
  youtube_id text not null check (youtube_id ~ '^[A-Za-z0-9_-]{6,20}$')
);

create table if not exists public.enrollments (
  user_id    uuid not null references public.profiles(id) on delete cascade,
  course_id  text not null references public.courses(id) on delete cascade,
  source     text not null default 'free' check (source in ('free','order','admin')),
  created_at timestamptz not null default now(),
  primary key (user_id, course_id)
);

create table if not exists public.progress (
  user_id    uuid not null references public.profiles(id) on delete cascade,
  course_id  text not null references public.courses(id) on delete cascade,
  position   int  not null default 0 check (position >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id, course_id)
);

-- ============================================================ 付費會員
create table if not exists public.plans (
  id          text primary key,                         -- monthly / yearly
  name        text not null,
  amount      int  not null check (amount > 0),
  period_type char(1) not null check (period_type in ('D','M','Y')),
  frequency   int  not null check (frequency >= 1),
  exec_times  int  not null check (exec_times > 1),     -- 綠界定期定額:總期數(月繳最多 99、年繳最多 9)
  active      boolean not null default false,           -- 價格確認後再開啟
  sort        int  not null default 0
);

create table if not exists public.memberships (
  user_id     uuid primary key references public.profiles(id) on delete cascade,
  plan        text references public.plans(id),
  status      text not null default 'active' check (status in ('active','cancelled')),
  valid_until timestamptz not null,                     -- 已付款涵蓋到這個時間
  source      text not null default 'ecpay' check (source in ('ecpay','manual')),
  order_id    uuid,
  updated_at  timestamptz not null default now()
);

-- ============================================================ 訂單與付款
create table if not exists public.orders (
  id                uuid primary key default gen_random_uuid(),
  merchant_trade_no text not null unique check (length(merchant_trade_no) <= 20),
  user_id           uuid not null references public.profiles(id),
  kind              text not null check (kind in ('product','course','membership')),
  status            text not null default 'pending' check (status in ('pending','paid','failed','cancelled')),
  amount            int  not null check (amount > 0),
  plan_id           text references public.plans(id),
  course_id         text references public.courses(id),
  recipient_name    text,
  recipient_phone   text,
  recipient_address text,
  note              text,
  fulfillment       text not null default 'none' check (fulfillment in ('none','to_ship','shipped','done')),
  ecpay_trade_no    text,
  created_at        timestamptz not null default now(),
  paid_at           timestamptz
);
create index if not exists orders_user_idx on public.orders(user_id, created_at desc);

create table if not exists public.order_items (
  id         bigint generated always as identity primary key,
  order_id   uuid not null references public.orders(id) on delete cascade,
  product_id text not null references public.products(id),
  name       text not null,
  unit_price int  not null,
  qty        int  not null check (qty between 1 and 20)
);

-- 綠界每一次通知(含定期定額每期扣款)都記一筆;event_key 唯一,重複通知不會重複開通
create table if not exists public.payments (
  id             bigint generated always as identity primary key,
  order_id       uuid not null references public.orders(id) on delete cascade,
  event_key      text not null unique,
  seq            int  not null default 1,               -- 第幾期
  amount         int  not null,
  status         text not null check (status in ('success','failed')),
  ecpay_trade_no text,
  gwsr           text,
  rtn_code       text,
  rtn_msg        text,
  raw            jsonb,
  created_at     timestamptz not null default now()
);

-- ============================================================ 免費資源
create table if not exists public.resources (
  id           text primary key,
  name         text not null,
  gate         boolean not null default true,           -- true = 登入後領取
  storage_path text,                                    -- resources bucket 內的檔案路徑
  href         text
);

create table if not exists public.resource_claims (
  user_id     uuid not null references public.profiles(id) on delete cascade,
  resource_id text not null references public.resources(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, resource_id)
);

-- ============================================================ 直播
create table if not exists public.live_events (
  id          bigint generated always as identity primary key,
  title       text not null,
  starts_at   timestamptz,
  public_url  text,                                     -- 公開直播的 YouTube 連結
  created_at  timestamptz not null default now()
);

-- 會員限定直播連結:RLS 只讓付費會員與老師讀取
create table if not exists public.live_links (
  event_id bigint primary key references public.live_events(id) on delete cascade,
  url      text not null
);

-- ============================================================ 作文批改
create table if not exists public.essays (
  id          uuid primary key default gen_random_uuid(),
  student_id  uuid references public.profiles(id) on delete set null,   -- 老師自行上傳的作文為 null
  created_by  uuid not null references public.profiles(id),
  source      text not null check (source in ('student','teacher')),
  source_note text,                                     -- 老師上傳時的學生/來源備註
  title       text not null check (length(title) between 1 and 60),
  grade       text,
  note        text check (note is null or length(note) <= 500),
  status      text not null default 'pending' check (status in ('pending','graded')),
  feedback    text,
  graded_at   timestamptz,
  graded_by   uuid references public.profiles(id),
  created_at  timestamptz not null default now()
);
create index if not exists essays_student_idx on public.essays(student_id, created_at desc);
create index if not exists essays_status_idx on public.essays(status, created_at desc);

create table if not exists public.essay_files (
  id         bigint generated always as identity primary key,
  essay_id   uuid not null references public.essays(id) on delete cascade,
  path       text not null unique,                      -- essays bucket 內的路徑:<essay_id>/<kind>-<n>.<ext>
  page_no    int  not null default 1,
  kind       text not null default 'submission' check (kind in ('submission','feedback')),
  created_at timestamptz not null default now()
);

-- ============================================================ 聯絡表單
create table if not exists public.contact_messages (
  id         bigint generated always as identity primary key,
  name       text not null check (length(name) between 1 and 60),
  email      text not null check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and length(email) <= 120),
  message    text not null check (length(message) between 1 and 2000),
  created_at timestamptz not null default now()
);
