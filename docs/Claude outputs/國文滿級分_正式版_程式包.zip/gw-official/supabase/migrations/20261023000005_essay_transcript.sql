-- 作文自動辨識:照片轉成文字(由 transcribe-essay 函式用 service role 寫入;老師可修正)
alter table public.essays
  add column if not exists transcript        text check (transcript is null or length(transcript) <= 20000),
  add column if not exists transcript_status text not null default 'none' check (transcript_status in ('none','pending','done','failed')),
  add column if not exists transcript_at     timestamptz;

-- 學生送出作文時不能自己帶辨識結果(只能由後端函式或老師寫入)
drop policy if exists essays_insert_student on public.essays;
create policy essays_insert_student on public.essays for insert to authenticated with check (
  source = 'student' and student_id = auth.uid() and created_by = auth.uid()
  and status = 'pending' and feedback is null and graded_at is null and graded_by is null and source_note is null
  and transcript is null and transcript_status = 'none' and transcript_at is null);
