-- 作文辨識:記錄由哪種方式辨識,並用每月用量計數控制 Google 文字辨識的免費額度
alter table public.essays
  add column if not exists transcript_engine text check (transcript_engine is null or transcript_engine in ('vision','tesseract','manual'));

drop policy if exists essays_insert_student on public.essays;
create policy essays_insert_student on public.essays for insert to authenticated with check (
  source = 'student' and student_id = auth.uid() and created_by = auth.uid()
  and status = 'pending' and feedback is null and graded_at is null and graded_by is null and source_note is null
  and transcript is null and transcript_status = 'none' and transcript_at is null and transcript_engine is null);

-- 每月用量(單位 = 一張照片);只有後端函式(service role)能讀寫
create table if not exists public.ocr_usage (
  month text primary key check (month ~ '^[0-9]{4}-[0-9]{2}$'),
  units integer not null default 0 check (units >= 0)
);
alter table public.ocr_usage enable row level security;
revoke all on public.ocr_usage from anon, authenticated;
grant select, insert, update on public.ocr_usage to service_role;

-- 預留額度:未超過上限就累加並回傳 true;超過回傳 false。負數代表退回。
create or replace function public.ocr_reserve(p_month text, p_units integer, p_limit integer)
returns boolean language plpgsql security definer set search_path = public as $$
declare v integer;
begin
  insert into public.ocr_usage(month, units) values (p_month, 0) on conflict (month) do nothing;
  if p_units <= 0 then
    update public.ocr_usage set units = greatest(0, units + p_units) where month = p_month;
    return true;
  end if;
  update public.ocr_usage set units = units + p_units
    where month = p_month and units + p_units <= p_limit returning units into v;
  return v is not null;
end $$;
revoke all on function public.ocr_reserve(text, integer, integer) from public, anon, authenticated;
grant execute on function public.ocr_reserve(text, integer, integer) to service_role;
