-- 檔案儲存:作文照片(私有)、免費資源 PDF(私有)

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('essays',    'essays',    false, 10485760, array['image/jpeg','image/png','image/webp','image/heic','image/heif']),
  ('resources', 'resources', false, 52428800, array['application/pdf'])
on conflict (id) do update
  set public = excluded.public, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

-- 作文照片路徑規則:<essay_id>/<kind>-<n>.<ext>;第一層資料夾就是作文 id
create policy essays_obj_insert on storage.objects for insert to authenticated with check (
  bucket_id = 'essays' and exists (
    select 1 from public.essays e
    where e.id::text = (storage.foldername(name))[1]
      and (public.is_admin() or (e.student_id = auth.uid() and e.status = 'pending'))));

create policy essays_obj_select on storage.objects for select to authenticated using (
  bucket_id = 'essays' and (public.is_admin() or exists (
    select 1 from public.essays e
    where e.id::text = (storage.foldername(name))[1] and e.student_id = auth.uid())));

create policy essays_obj_delete on storage.objects for delete to authenticated using (
  bucket_id = 'essays' and public.is_admin());

-- 免費資源 PDF:登入並領取過才能下載;檔案由老師上傳
create policy resources_obj_select on storage.objects for select to authenticated using (
  bucket_id = 'resources' and (public.is_admin() or exists (
    select 1 from public.resources r join public.resource_claims c on c.resource_id = r.id
    where r.storage_path = name and c.user_id = auth.uid())));

create policy resources_obj_write on storage.objects for all to authenticated using (
  bucket_id = 'resources' and public.is_admin()) with check (bucket_id = 'resources' and public.is_admin());
