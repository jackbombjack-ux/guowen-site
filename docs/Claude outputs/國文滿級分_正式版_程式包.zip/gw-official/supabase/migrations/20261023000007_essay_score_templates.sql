-- 作文批改:分數、學生已讀/通知、評語範本
alter table public.essays
  add column if not exists score numeric(5,1),
  add column if not exists score_max numeric(5,1),
  add column if not exists student_seen_at timestamptz,
  add column if not exists notified_at timestamptz;
alter table public.essays drop constraint if exists essays_score_chk;
alter table public.essays add constraint essays_score_chk check (
  (score is null and score_max is null)
  or (score is not null and score_max is not null and score_max between 1 and 100 and score between 0 and score_max));

-- 學生新增作文時,不能自己帶分數/已讀/通知欄位
drop policy if exists essays_insert_student on public.essays;
create policy essays_insert_student on public.essays for insert to authenticated with check (
  source = 'student' and student_id = auth.uid() and created_by = auth.uid()
  and status = 'pending' and feedback is null and graded_at is null and graded_by is null and source_note is null
  and transcript is null and transcript_status = 'none' and transcript_at is null and transcript_engine is null
  and score is null and score_max is null and student_seen_at is null and notified_at is null);

-- 學生打開「我的作文」後,把已批改的標為已讀(學生沒有 update 權限,只能透過這個函式)
create or replace function public.mark_essays_seen() returns integer
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  if auth.uid() is null then return 0; end if;
  update public.essays set student_seen_at = now()
   where student_id = auth.uid() and status = 'graded' and student_seen_at is null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.mark_essays_seen() from public, anon;
grant execute on function public.mark_essays_seen() to authenticated;

-- 評語範本(只有管理者看得到、改得動)
create table if not exists public.feedback_templates (
  id         bigint generated always as identity primary key,
  label      text not null check (length(label) between 1 and 20),
  body       text not null check (length(body) between 1 and 1000),
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
alter table public.feedback_templates enable row level security;
drop policy if exists fbt_admin on public.feedback_templates;
create policy fbt_admin on public.feedback_templates for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
revoke all on public.feedback_templates from anon;
grant select, insert, update, delete on public.feedback_templates to authenticated;

insert into public.feedback_templates(label, body, sort_order)
select * from (values
 ('立意明確', '立意明確,主旨能貫串全文,而且有自己的想法,這點很好。', 1),
 ('結構完整', '結構完整,起承轉合清楚。下次可以在段落之間加上承接句,讓轉折更自然。', 2),
 ('取材可加強', '取材貼近生活,若能再加入一個具體的人、事、物細節,文章會更有說服力。', 3),
 ('字詞標點', '用字遣詞大致通順,請留意錯別字與標點符號,寫完後務必自己唸一遍檢查。', 4),
 ('結尾有力', '結尾能呼應開頭並提升主旨,收束有力。', 5),
 ('鼓勵', '整體表現進步很多,繼續保持練習的節奏,老師很期待你的下一篇!', 6)
) as v(label, body, sort_order)
where not exists (select 1 from public.feedback_templates);
