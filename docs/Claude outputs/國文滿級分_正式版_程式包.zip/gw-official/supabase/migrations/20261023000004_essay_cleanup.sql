-- 學生上傳失敗時,可以清掉自己「還沒批改」的作文與照片(已批改的不能刪)
create policy essays_delete_own_pending on public.essays for delete to authenticated
  using (student_id = auth.uid() and status = 'pending');

create policy essays_obj_delete_own on storage.objects for delete to authenticated using (
  bucket_id = 'essays' and exists (
    select 1 from public.essays e
    where e.id::text = (storage.foldername(name))[1] and e.student_id = auth.uid() and e.status = 'pending'));
