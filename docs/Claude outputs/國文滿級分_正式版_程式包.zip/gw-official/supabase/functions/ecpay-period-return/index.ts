// 綠界「定期定額執行結果通知」(PeriodReturnURL):每期扣款後綠界會 POST 到這裡。
import { createClient } from 'npm:@supabase/supabase-js@2';
import { loadEcpayEnv, parseForm } from '../_shared/ecpay.ts';
import { handleNotification } from '../_shared/payments.ts';
import { requireEnv, text } from '../_shared/http.ts';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return text('method not allowed', 405);
  const env = loadEcpayEnv((k) => Deno.env.get(k));
  const form = parseForm(await req.text());
  const admin = createClient(requireEnv('SUPABASE_URL'), requireEnv('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
  const r = await handleNotification('period', form, env, async (fn, args) => { const { data, error } = await admin.rpc(fn, args); return { data, error }; });
  return text(r.body, r.status);
});
