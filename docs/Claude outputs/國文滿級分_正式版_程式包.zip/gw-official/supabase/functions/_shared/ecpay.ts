// 綠界(ECPay)全方位金流 AIO V5:檢查碼、參數工具。
// 只用標準 Web API(crypto.subtle),Deno 與 Node 都能執行,方便單元測試。

export type Params = Record<string, string | number>;

export const AIO_URL = {
  stage: 'https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5',
  production: 'https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5',
} as const;

export const PERIOD_ACTION_URL = {
  stage: 'https://payment-stage.ecpay.com.tw/Cashier/CreditCardPeriodAction',
  production: 'https://payment.ecpay.com.tw/Cashier/CreditCardPeriodAction',
} as const;

// 綠界公開的測試商店(僅限 stage 環境)。正式環境務必改成自己的商店代號與金鑰。
export const STAGE_TEST = {
  merchantId: '3002607',
  hashKey: 'pwFHCqoQZGmho4w6',
  hashIV: 'EkRm7iFT261dpevs',
};

/** .NET HttpUtility.UrlEncode 相容編碼,並轉小寫(綠界規定的檢查碼前置處理) */
export function netUrlEncode(s: string): string {
  return encodeURIComponent(s)
    .replace(/%20/g, '+')
    .replace(/~/g, '%7e')
    .replace(/'/g, '%27')
    .toLowerCase();
  // encodeURIComponent 本來就不會編碼 - _ . ! * ( ),與綠界對照表的 .NET 欄位一致
}

export async function sha256Hex(s: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** 參數名稱排序:不分大小寫(與綠界官方 SDK 的 strcasecmp 相同),例如 gwsr 會排在 FirstAuthAmount 之後 */
function sortedKeys(params: Params): string[] {
  return Object.keys(params)
    .filter((k) => k !== 'CheckMacValue')
    .sort((a, b) => {
      const la = a.toLowerCase(), lb = b.toLowerCase();
      return la < lb ? -1 : la > lb ? 1 : a < b ? -1 : a > b ? 1 : 0;
    });
}

export async function checkMacValue(params: Params, hashKey: string, hashIV: string): Promise<string> {
  const body = sortedKeys(params).map((k) => `${k}=${params[k]}`).join('&');
  const raw = `HashKey=${hashKey}&${body}&HashIV=${hashIV}`;
  return (await sha256Hex(netUrlEncode(raw))).toUpperCase();
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export async function verifyCheckMac(params: Params, hashKey: string, hashIV: string): Promise<boolean> {
  const given = String(params['CheckMacValue'] ?? '').toUpperCase();
  if (!given) return false;
  return timingSafeEqual(given, await checkMacValue(params, hashKey, hashIV));
}

/** application/x-www-form-urlencoded → 物件 */
export function parseForm(body: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of new URLSearchParams(body)) out[k] = v;
  return out;
}

/** 綠界要求的交易時間格式 yyyy/MM/dd HH:mm:ss(台北時間) */
export function tradeDate(d = new Date()): string {
  const t = new Date(d.getTime() + 8 * 3600 * 1000).toISOString(); // UTC+8
  return `${t.slice(0, 4)}/${t.slice(5, 7)}/${t.slice(8, 10)} ${t.slice(11, 19)}`;
}

/** 特店交易編號:英數字、最多 20 字、不可重複。GW + 時間(base36) + 亂數 */
export function newTradeNo(prefix = 'GW'): string {
  const rnd = crypto.getRandomValues(new Uint8Array(5));
  const r = [...rnd].map((b) => (b % 36).toString(36)).join('').toUpperCase();
  return (prefix + Date.now().toString(36).toUpperCase() + r).slice(0, 20);
}

export interface EcpayEnv {
  mode: 'stage' | 'production';
  merchantId: string;
  hashKey: string;
  hashIV: string;
}

export function loadEcpayEnv(get: (k: string) => string | undefined): EcpayEnv {
  const mode = get('ECPAY_MODE') === 'production' ? 'production' : 'stage';
  if (mode === 'production') {
    const merchantId = get('ECPAY_MERCHANT_ID'), hashKey = get('ECPAY_HASH_KEY'), hashIV = get('ECPAY_HASH_IV');
    if (!merchantId || !hashKey || !hashIV) throw new Error('ECPAY_MERCHANT_ID / HASH_KEY / HASH_IV 尚未設定');
    return { mode, merchantId, hashKey, hashIV };
  }
  return {
    mode,
    merchantId: get('ECPAY_MERCHANT_ID') || STAGE_TEST.merchantId,
    hashKey: get('ECPAY_HASH_KEY') || STAGE_TEST.hashKey,
    hashIV: get('ECPAY_HASH_IV') || STAGE_TEST.hashIV,
  };
}
