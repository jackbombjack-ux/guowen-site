// 綠界伺服器通知(ReturnURL / PeriodReturnURL)的處理邏輯。
// 不依賴 Deno 或 Supabase SDK,方便在本機單元測試;rpc 由呼叫端(Edge Function)傳入。
import { type EcpayEnv, verifyCheckMac } from './ecpay.ts';

export type Rpc = (fn: string, args: Record<string, unknown>) => Promise<{ data: unknown; error: { message: string } | null }>;
export interface Result { status: number; body: string; outcome: string }

const OK = '1|OK';

/**
 * kind = 'return':一般付款結果(含定期定額第 1 期、ATM、超商);'period':定期定額之後每期的扣款結果。
 * 回應規則:簽章錯誤回 400(綠界不會重送無效請求);資料庫暫時出錯回 500(綠界會在 5~15 分鐘後重送);
 * 其餘(包含已處理過、找不到訂單、模擬付款)一律回 1|OK,避免綠界無限重送。
 */
export async function handleNotification(
  kind: 'return' | 'period', form: Record<string, string>, env: EcpayEnv, rpc: Rpc,
  log: (msg: string) => void = console.log,
): Promise<Result> {
  if (!(await verifyCheckMac(form, env.hashKey, env.hashIV))) {
    log(`[${kind}] bad CheckMacValue for ${form.MerchantTradeNo ?? '?'}`);
    return { status: 400, body: '0|CheckMacValue error', outcome: 'bad_mac' };
  }
  if (form.MerchantID !== env.merchantId) {
    return { status: 400, body: '0|MerchantID mismatch', outcome: 'bad_merchant' };
  }
  const tradeNo = form.MerchantTradeNo;
  if (!tradeNo) return { status: 400, body: '0|missing MerchantTradeNo', outcome: 'bad_request' };

  // 後台「模擬付款」會帶 SimulatePaid=1:不是真的收到錢,不能開通
  if (form.SimulatePaid === '1') {
    log(`[${kind}] simulated payment ignored: ${tradeNo}`);
    return { status: 200, body: OK, outcome: 'simulated' };
  }

  const success = form.RtnCode === '1';
  let seq: number, amount: number, eventKey: string;
  if (kind === 'return') {
    amount = Number(form.TradeAmt);
    seq = 1;
    eventKey = success ? `${tradeNo}:1` : `${tradeNo}:fail:${form.RtnCode}:${form.TradeNo ?? ''}`;
  } else {
    amount = Number(form.Amount);
    const total = Number(form.TotalSuccessTimes ?? 0);
    seq = success ? total : total + 1;
    eventKey = success ? `${tradeNo}:${total}` : `${tradeNo}:fail:${form.gwsr ?? form.ProcessDate ?? ''}`;
    if (success && !(total >= 1)) {
      return { status: 400, body: '0|bad TotalSuccessTimes', outcome: 'bad_request' };
    }
  }
  if (!Number.isInteger(amount) || amount <= 0) {
    return { status: 400, body: '0|bad amount', outcome: 'bad_request' };
  }

  const { data, error } = await rpc('apply_payment', {
    p_trade_no: tradeNo,
    p_event_key: eventKey,
    p_seq: seq,
    p_amount: amount,
    p_success: success,
    p_ecpay_trade_no: form.TradeNo ?? null,
    p_gwsr: form.gwsr ?? form.Gwsr ?? null,
    p_rtn_code: form.RtnCode ?? null,
    p_rtn_msg: form.RtnMsg ?? null,
    p_raw: form,
  });
  if (error) {
    log(`[${kind}] apply_payment error for ${tradeNo}: ${error.message}`);
    return { status: 500, body: '0|server error', outcome: 'db_error' };
  }
  const outcome = String(data);
  log(`[${kind}] ${tradeNo} -> ${outcome}`);
  return { status: 200, body: OK, outcome };
}
