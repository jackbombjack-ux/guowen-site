// 結帳:價格計算、資料驗證、組出要 POST 給綠界的欄位。純函式,方便測試。
import { AIO_URL, type EcpayEnv, type Params, checkMacValue, tradeDate } from './ecpay.ts';

export interface ProductRow { id: string; name: string; title: string; price: number; kind: 'physical' | 'digital'; active: boolean }
export interface PlanRow { id: string; name: string; amount: number; period_type: 'D' | 'M' | 'Y'; frequency: number; exec_times: number; active: boolean }
export interface Recipient { name?: string; phone?: string; address?: string }

export class UserError extends Error {
  status: number;
  constructor(message: string, status = 400) { super(message); this.status = status; }
}

const MAX_LINES = 10;

export function priceCart(
  items: unknown, products: ProductRow[],
): { lines: { product: ProductRow; qty: number }[]; total: number; needsShipping: boolean } {
  if (!Array.isArray(items) || items.length === 0) throw new UserError('購物車是空的');
  if (items.length > MAX_LINES) throw new UserError('一次最多結帳 10 種商品');
  const byId = new Map(products.map((p) => [p.id, p]));
  const seen = new Set<string>();
  const lines: { product: ProductRow; qty: number }[] = [];
  for (const raw of items) {
    const id = String((raw as { id?: unknown })?.id ?? '');
    const qty = Number((raw as { qty?: unknown })?.qty);
    if (seen.has(id)) throw new UserError('商品重複');
    seen.add(id);
    const product = byId.get(id);
    if (!product || !product.active) throw new UserError('有商品已下架或不存在');
    if (!Number.isInteger(qty) || qty < 1 || qty > 20) throw new UserError('數量需為 1 到 20');
    lines.push({ product, qty });
  }
  const total = lines.reduce((s, l) => s + l.product.price * l.qty, 0);
  if (total <= 0) throw new UserError('訂單金額不正確');
  return { lines, total, needsShipping: lines.some((l) => l.product.kind === 'physical') };
}

export function validateRecipient(r: Recipient | undefined): Required<Recipient> {
  const name = (r?.name ?? '').trim(), phone = (r?.phone ?? '').trim(), address = (r?.address ?? '').trim();
  if (name.length < 1 || name.length > 30) throw new UserError('請填寫收件人姓名');
  if (!/^[0-9+\-\s()]{8,20}$/.test(phone)) throw new UserError('請填寫正確的聯絡電話');
  if (address.length < 5 || address.length > 120) throw new UserError('請填寫完整的收件地址');
  return { name, phone, address };
}

/** 綠界 ItemName 以 # 分隔、最長 400 字;把使用者可控的字元清掉 */
export function itemName(parts: string[]): string {
  const clean = parts.map((s) => s.replace(/[#\r\n]/g, ' ').trim()).join('#');
  return clean.length > 400 ? clean.slice(0, 397) + '...' : clean;
}

export interface Urls { returnUrl: string; periodReturnUrl: string; clientBackUrl: string }

export async function buildOneTimeFields(
  env: EcpayEnv, o: { tradeNo: string; amount: number; itemName: string; desc?: string }, urls: Urls,
): Promise<{ url: string; fields: Params }> {
  const fields: Params = {
    MerchantID: env.merchantId,
    MerchantTradeNo: o.tradeNo,
    MerchantTradeDate: tradeDate(),
    PaymentType: 'aio',
    TotalAmount: o.amount,
    TradeDesc: o.desc ?? '國文滿級分',
    ItemName: o.itemName,
    ReturnURL: urls.returnUrl,
    ChoosePayment: 'ALL',
    ClientBackURL: urls.clientBackUrl,
    EncryptType: 1,
  };
  fields.CheckMacValue = await checkMacValue(fields, env.hashKey, env.hashIV);
  return { url: AIO_URL[env.mode], fields };
}

export async function buildPeriodFields(
  env: EcpayEnv, o: { tradeNo: string; plan: PlanRow }, urls: Urls,
): Promise<{ url: string; fields: Params }> {
  const p = o.plan;
  // 綠界限制:月繳 Frequency 1~12、ExecTimes 最多 99;年繳 Frequency 1、ExecTimes 最多 9;日繳 Frequency 1~365、ExecTimes 最多 999
  const limits = { M: { f: 12, e: 99 }, Y: { f: 1, e: 9 }, D: { f: 365, e: 999 } }[p.period_type];
  if (p.frequency < 1 || p.frequency > limits.f || p.exec_times < 2 || p.exec_times > limits.e) {
    throw new UserError('會員方案的週期設定不符合綠界規定', 500);
  }
  const fields: Params = {
    MerchantID: env.merchantId,
    MerchantTradeNo: o.tradeNo,
    MerchantTradeDate: tradeDate(),
    PaymentType: 'aio',
    TotalAmount: p.amount,
    TradeDesc: '國文滿級分',
    ItemName: itemName([`付費會員(${p.name})`]),
    ReturnURL: urls.returnUrl,
    ChoosePayment: 'Credit',
    ClientBackURL: urls.clientBackUrl,
    EncryptType: 1,
    PeriodAmount: p.amount,
    PeriodType: p.period_type,
    Frequency: p.frequency,
    ExecTimes: p.exec_times,
    PeriodReturnURL: urls.periodReturnUrl,
  };
  fields.CheckMacValue = await checkMacValue(fields, env.hashKey, env.hashIV);
  return { url: AIO_URL[env.mode], fields };
}
