// 共用:CORS、回應工具、環境變數
export function allowedOrigins(): string[] {
  const site = Deno.env.get('SITE_URL') ?? '';
  const extra = (Deno.env.get('EXTRA_ORIGINS') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  return [site.replace(/\/+$/, ''), 'http://localhost:8765', 'http://127.0.0.1:8765', ...extra].filter(Boolean);
}

export function corsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get('origin') ?? '';
  const ok = allowedOrigins().includes(origin);
  return {
    'Access-Control-Allow-Origin': ok ? origin : (allowedOrigins()[0] ?? ''),
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Vary': 'Origin',
  };
}

export function json(req: Request, body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(req), 'Content-Type': 'application/json; charset=utf-8' },
  });
}

export function text(body: string, status = 200): Response {
  return new Response(body, { status, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
}

export function requireEnv(k: string): string {
  const v = Deno.env.get(k);
  if (!v) throw new Error(`環境變數 ${k} 尚未設定`);
  return v;
}
