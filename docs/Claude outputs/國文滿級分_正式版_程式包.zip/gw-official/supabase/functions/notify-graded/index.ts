// 作文批改完成後,寄 Email 通知學生(透過 Resend)。
// 只有管理者能呼叫;沒設 RESEND_API_KEY 時直接略過(學生在會員專區仍會看到「新批改」提示)。
// 每篇作文只寄一次(notified_at)。
import { createClient } from 'npm:@supabase/supabase-js@2';
import { UserError } from '../_shared/checkout.ts';
import { corsHeaders, json, requireEnv } from '../_shared/http.ts';

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(req) });
  if (req.method !== 'POST') return json(req, { error: 'method not allowed' }, 405);
  try {
    const supaUrl = requireEnv('SUPABASE_URL');
    const userClient = createClient(supaUrl, requireEnv('SUPABASE_ANON_KEY'), {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } }, auth: { persistSession: false },
    });
    const { data: ures, error: uerr } = await userClient.auth.getUser();
    if (uerr || !ures.user) throw new UserError('請先登入', 401);
    const body = await req.json().catch(() => ({}));
    const essayId = String(body?.essay_id ?? '');
    if (!/^[0-9a-f-]{36}$/i.test(essayId)) throw new UserError('作文編號不正確');

    const admin = createClient(supaUrl, requireEnv('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
    const { data: prof } = await admin.from('profiles').select('role').eq('id', ures.user.id).maybeSingle();
    if (prof?.role !== 'admin') throw new UserError('沒有權限', 403);

    const key = Deno.env.get('RESEND_API_KEY');
    if (!key) return json(req, { ok: false, reason: 'no_key' });

    const { data: essay } = await admin.from('essays')
      .select('id,title,status,student_id,score,score_max,notified_at').eq('id', essayId).maybeSingle();
    if (!essay || essay.status !== 'graded' || !essay.student_id) return json(req, { ok: false, reason: 'not_applicable' });
    if (essay.notified_at) return json(req, { ok: true, already: true });

    const { data: stu } = await admin.from('profiles').select('email,name').eq('id', essay.student_id).maybeSingle();
    const to = stu?.email;
    if (!to) return json(req, { ok: false, reason: 'no_email' });

    const site = (Deno.env.get('SITE_URL') ?? '').replace(/\/+$/, '');
    const link = site ? `${site}/member.html` : '';
    const from = Deno.env.get('RESEND_FROM') ?? '國文滿級分 <onboarding@resend.dev>';
    const name = stu?.name ? esc(String(stu.name)) : '同學';
    const scoreLine = essay.score != null ? `<p>分數:<b>${essay.score} / ${essay.score_max}</b></p>` : '';
    const html = `<div style="font-family:system-ui,'PingFang TC','Noto Sans TC',sans-serif;line-height:1.8;color:#1a1a1a;max-width:520px">
<p>${name} 你好,</p>
<p>你送出的作文「<b>${esc(String(essay.title))}</b>」老師已經批改完成了。</p>${scoreLine}
${link ? `<p><a href="${esc(link)}" style="display:inline-block;padding:10px 20px;background:#8b6a1f;color:#fff;border-radius:6px;text-decoration:none">到會員專區查看評語</a></p>` : ''}
<p style="color:#777;font-size:13px">國文滿級分專業工作室</p></div>`;

    const resp = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ from, to: [to], subject: `【國文滿級分】作文「${essay.title}」已批改`, html }),
    });
    if (!resp.ok) {
      console.error('resend failed', resp.status, (await resp.text()).slice(0, 300));
      return json(req, { ok: false, reason: 'send_failed' });
    }
    await admin.from('essays').update({ notified_at: new Date().toISOString() }).eq('id', essayId);
    return json(req, { ok: true });
  } catch (e) {
    if (e instanceof UserError) return json(req, { error: e.message }, e.status);
    console.error('notify-graded failed', e);
    return json(req, { error: '通知暫時失敗' }, 500);
  }
});
