// 綠界「付款結果通知」(ReturnURL):付款成功後綠界伺服器會 POST 到這裡。
// 部署時 verify_jwt = false(見 config.toml);來源靠 CheckMacValue 驗證。
import { createClient } from 'npm:@supabase/supabase-js@2';
import { loadEcpayEnv, parseForm } from '../_shared/ecpay.ts';
import { handleNotification } from '../_shared/payments.ts';
import { requireEnv, text } from '../_shared/http.ts';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return text('method not allowed', 405);
  const env = loadEcpayEnv((k) => Deno.env.get(k));
  const form = parseForm(await req.text());
  const admin = createClient(requireEnv('SUPABASE_URL'), requireEnv('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
  const r = await handleNotification('return', form, env, async (fn, args) => { const { data, error } = await admin.rpc(fn, args); return { data, error }; });
  return text(r.body, r.status);
});
