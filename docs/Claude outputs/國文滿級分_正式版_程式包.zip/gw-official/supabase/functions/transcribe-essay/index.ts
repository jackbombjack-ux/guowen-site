// 作文自動辨識(兩段式):
//  1. 先用 Google Cloud Vision 辨識(每月上限內,預設 950 張照片,在 Google 免費額度 1000 之內)。
//  2. 額度用完、沒設金鑰、或 Google 失敗時,回傳 { fallback: 'client' },由網頁端用 Tesseract.js 在瀏覽器辨識,
//     辨識完再用 { essay_id, save_text } 把文字存回來。
// 只有作文本人或老師能觸發;辨識完成後學生不能重複觸發(老師可以強制重辨識)。
import { createClient } from 'npm:@supabase/supabase-js@2';
import { UserError } from '../_shared/checkout.ts';
import { corsHeaders, json, requireEnv } from '../_shared/http.ts';

const EXT_OK = new Set(['jpg', 'jpeg', 'png', 'webp']);
const MAX_PAGES = 8;

function b64(bytes: Uint8Array): string {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

type Sym = { text?: string; property?: { detectedBreak?: { type?: string } } };
type Para = { words?: { symbols?: Sym[] }[] };
// 把 Vision 的結果整理成中文文字:行尾換行不保留(稿紙每行很短),段落之間換行
function visionToText(resp: { fullTextAnnotation?: { text?: string; pages?: { blocks?: { paragraphs?: Para[] }[] }[] } }): string {
  const fa = resp?.fullTextAnnotation;
  if (!fa) return '';
  const paras: string[] = [];
  for (const pg of fa.pages ?? []) for (const bl of pg.blocks ?? []) for (const p of bl.paragraphs ?? []) {
    let s = '';
    for (const w of p.words ?? []) for (const sym of w.symbols ?? []) {
      const t = sym.text ?? '';
      s += t;
      const br = sym.property?.detectedBreak?.type;
      if (br === 'SPACE' || br === 'EOL_SURE_SPACE') { if (/[A-Za-z0-9,.;:!?]$/.test(t)) s += ' '; }
      else if (br === 'LINE_BREAK') { if (/[A-Za-z0-9]$/.test(t)) s += ' '; }
    }
    s = s.trim();
    if (s) paras.push(s);
  }
  return (paras.length ? paras.join('\n') : (fa.text ?? '').replace(/\n/g, '')).trim();
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(req) });
  if (req.method !== 'POST') return json(req, { error: 'method not allowed' }, 405);
  let essayId = '';
  let pendingSet = false;
  const supaUrl = Deno.env.get('SUPABASE_URL') ?? '';
  let admin: ReturnType<typeof createClient> | null = null;
  try {
    supaUrl || requireEnv('SUPABASE_URL');
    const userClient = createClient(supaUrl, requireEnv('SUPABASE_ANON_KEY'), {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } }, auth: { persistSession: false },
    });
    const { data: ures, error: uerr } = await userClient.auth.getUser();
    if (uerr || !ures.user) throw new UserError('請先登入', 401);
    const body = await req.json().catch(() => ({}));
    essayId = String(body?.essay_id ?? '');
    if (!/^[0-9a-f-]{36}$/i.test(essayId)) throw new UserError('作文編號不正確');

    admin = createClient(supaUrl, requireEnv('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
    const { data: prof } = await admin.from('profiles').select('role').eq('id', ures.user.id).maybeSingle();
    const isAdmin = prof?.role === 'admin';
    const { data: essay } = await admin.from('essays').select('id,student_id,transcript_status').eq('id', essayId).maybeSingle();
    if (!essay || (!isAdmin && essay.student_id !== ures.user.id)) throw new UserError('找不到這篇作文', 404);
    if (!isAdmin && essay.transcript_status === 'done') return json(req, { ok: true, already: true });

    // 網頁端辨識完成,把文字存回來
    if (typeof body?.save_text === 'string') {
      const t = body.save_text.trim().slice(0, 20000);
      if (!t) throw new UserError('辨識結果是空的');
      await admin.from('essays').update({ transcript: t, transcript_status: 'done', transcript_engine: 'tesseract', transcript_at: new Date().toISOString() }).eq('id', essayId);
      return json(req, { ok: true, engine: 'tesseract' });
    }

    if (essay.transcript_status === 'pending') {
      const { data: t } = await admin.from('essays').select('transcript_at').eq('id', essayId).maybeSingle();
      if (t?.transcript_at && Date.now() - new Date(t.transcript_at).getTime() < 90_000) return json(req, { ok: true, pending: true });
    }

    const { data: files } = await admin.from('essay_files').select('path,page_no')
      .eq('essay_id', essayId).eq('kind', 'submission').order('page_no');
    if (!files?.length) throw new UserError('這篇作文沒有照片');
    const use = files.slice(0, MAX_PAGES).filter((f) => EXT_OK.has(f.path.split('.').pop()?.toLowerCase() ?? ''));
    if (!use.length) throw new UserError('照片格式無法辨識');

    // 沒設金鑰 → 直接交給網頁端
    const key = Deno.env.get('GOOGLE_VISION_KEY');
    if (!key) return json(req, { ok: false, fallback: 'client', reason: 'no_key' });
    // 額度:以「照片張數」計,UTC 月份
    const limit = Number(Deno.env.get('OCR_MONTHLY_LIMIT') ?? '950') || 950;
    const month = new Date().toISOString().slice(0, 7);
    const { data: okQuota, error: qerr } = await admin.rpc('ocr_reserve', { p_month: month, p_units: use.length, p_limit: limit });
    if (qerr) throw qerr;
    if (!okQuota) return json(req, { ok: false, fallback: 'client', reason: 'quota' });

    await admin.from('essays').update({ transcript_status: 'pending', transcript_at: new Date().toISOString() }).eq('id', essayId);
    pendingSet = true;
    const pages: string[] = [];
    try {
      for (const f of use) {
        const { data: blob, error } = await admin.storage.from('essays').download(f.path);
        if (error || !blob) throw new Error('download failed: ' + f.path);
        const resp = await fetch('https://vision.googleapis.com/v1/images:annotate?key=' + encodeURIComponent(key), {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ requests: [{
            image: { content: b64(new Uint8Array(await blob.arrayBuffer())) },
            features: [{ type: 'DOCUMENT_TEXT_DETECTION' }],
            imageContext: { languageHints: ['zh-Hant'] },
          }] }),
        });
        if (!resp.ok) throw new Error('vision ' + resp.status + ' ' + (await resp.text()).slice(0, 300));
        const out = await resp.json();
        const r0 = out?.responses?.[0];
        if (r0?.error) throw new Error('vision error ' + JSON.stringify(r0.error).slice(0, 300));
        pages.push(visionToText(r0 ?? {}));
      }
    } catch (e) {
      // Google 失敗(沒開帳單、金鑰錯誤等):退回額度,改由網頁端辨識
      console.error('vision failed', e);
      await admin.rpc('ocr_reserve', { p_month: month, p_units: -use.length, p_limit: limit });
      await admin.from('essays').update({ transcript_status: essay.transcript_status === 'pending' ? 'none' : essay.transcript_status }).eq('id', essayId).eq('transcript_status', 'pending');
      pendingSet = false;
      return json(req, { ok: false, fallback: 'client', reason: 'vision_error' });
    }
    const text = pages.filter(Boolean).join('\n').trim();
    if (!text) throw new Error('empty transcript');
    await admin.from('essays').update({ transcript: text.slice(0, 20000), transcript_status: 'done', transcript_engine: 'vision', transcript_at: new Date().toISOString() }).eq('id', essayId);
    pendingSet = false;
    return json(req, { ok: true, engine: 'vision' });
  } catch (e) {
    if (admin && essayId && pendingSet) await admin.from('essays').update({ transcript_status: 'failed' }).eq('id', essayId).eq('transcript_status', 'pending');
    if (e instanceof UserError) return json(req, { error: e.message }, e.status);
    console.error('transcribe-essay failed', e);
    return json(req, { error: '辨識暫時失敗,稍後可以重新辨識' }, 500);
  }
});
