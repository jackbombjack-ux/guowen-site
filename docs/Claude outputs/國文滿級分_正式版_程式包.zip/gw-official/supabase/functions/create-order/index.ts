// 建立訂單並回傳要 POST 給綠界的表單欄位。
// 價格一律在這裡由資料庫計算,不相信前端送來的金額。
// 請求(需登入):
//   { type: 'cart', items: [{id, qty}], recipient: {name, phone, address}, note? }
//   { type: 'membership', plan: 'monthly' | 'yearly' }
//   { type: 'course', course: '<course id>' }
// 回應:{ url, fields }  前端用 <form method="post" action=url> 送出 fields 即可。
import { createClient } from 'npm:@supabase/supabase-js@2';
import { loadEcpayEnv, newTradeNo } from '../_shared/ecpay.ts';
import {
  UserError, buildOneTimeFields, buildPeriodFields, itemName, priceCart, validateRecipient,
  type PlanRow, type ProductRow,
} from '../_shared/checkout.ts';
import { corsHeaders, json, requireEnv } from '../_shared/http.ts';

const GRACE_MS = 3 * 864e5;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(req) });
  if (req.method !== 'POST') return json(req, { error: 'method not allowed' }, 405);
  try {
    const supaUrl = requireEnv('SUPABASE_URL');
    const siteUrl = requireEnv('SITE_URL').replace(/\/+$/, '');
    const env = loadEcpayEnv((k) => Deno.env.get(k));

    // 1) 驗證登入身分
    const auth = req.headers.get('Authorization') ?? '';
    const userClient = createClient(supaUrl, requireEnv('SUPABASE_ANON_KEY'), {
      global: { headers: { Authorization: auth } }, auth: { persistSession: false },
    });
    const { data: ures, error: uerr } = await userClient.auth.getUser();
    if (uerr || !ures.user) throw new UserError('請先登入', 401);
    const user = ures.user;

    const admin = createClient(supaUrl, requireEnv('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
    const body = await req.json().catch(() => ({}));

    // 線上付款總開關:老師在後台「設定」打開之前,一律不建立訂單
    const { data: sw } = await admin.from('site_settings').select('value').eq('key', 'payments_enabled').maybeSingle();
    if (sw?.value !== true) throw new UserError('線上付款尚未開放,請先透過 LINE 聯繫我們', 403);

    // 2) 簡單防濫用:10 分鐘內未付款訂單太多就先擋
    const since = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const { count } = await admin.from('orders').select('id', { count: 'exact', head: true })
      .eq('user_id', user.id).eq('status', 'pending').gte('created_at', since);
    if ((count ?? 0) >= 10) throw new UserError('操作太頻繁,請稍後再試', 429);

    const tradeNo = newTradeNo('GW');
    const urls = {
      returnUrl: `${supaUrl}/functions/v1/ecpay-return`,
      periodReturnUrl: `${supaUrl}/functions/v1/ecpay-period-return`,
      clientBackUrl: `${siteUrl}/member.html?pay=${tradeNo}`,
    };

    let result;
    if (body.type === 'cart') {
      const { data: products, error } = await admin.from('products').select('id,name,title,price,kind,active');
      if (error) throw error;
      const cart = priceCart(body.items, (products ?? []) as ProductRow[]);
      const rec = cart.needsShipping ? validateRecipient(body.recipient) : null;
      const { data: order, error: oerr } = await admin.from('orders').insert({
        merchant_trade_no: tradeNo, user_id: user.id, kind: 'product', amount: cart.total,
        recipient_name: rec?.name, recipient_phone: rec?.phone, recipient_address: rec?.address,
        note: typeof body.note === 'string' ? body.note.slice(0, 200) : null,
      }).select('id').single();
      if (oerr) throw oerr;
      const { error: ierr } = await admin.from('order_items').insert(cart.lines.map((l) => ({
        order_id: order.id, product_id: l.product.id, name: l.product.name, unit_price: l.product.price, qty: l.qty,
      })));
      if (ierr) throw ierr;
      result = await buildOneTimeFields(env, {
        tradeNo, amount: cart.total, itemName: itemName(cart.lines.map((l) => `${l.product.name} x${l.qty}`)),
      }, urls);

    } else if (body.type === 'membership') {
      const { data: plan } = await admin.from('plans').select('*').eq('id', String(body.plan)).eq('active', true).maybeSingle();
      if (!plan) throw new UserError('這個方案目前未開放', 400);
      const { data: mem } = await admin.from('memberships').select('status,valid_until,source').eq('user_id', user.id).maybeSingle();
      if (mem && mem.status === 'active' && new Date(mem.valid_until).getTime() + GRACE_MS > Date.now()) {
        throw new UserError('你已經是付費會員,不需要重複加入', 409);
      }
      const { error: oerr } = await admin.from('orders').insert({
        merchant_trade_no: tradeNo, user_id: user.id, kind: 'membership', amount: plan.amount, plan_id: plan.id,
      });
      if (oerr) throw oerr;
      result = await buildPeriodFields(env, { tradeNo, plan: plan as PlanRow }, urls);

    } else if (body.type === 'course') {
      const { data: course } = await admin.from('courses').select('id,name,price,status').eq('id', String(body.course)).maybeSingle();
      if (!course || course.status !== 'open') throw new UserError('這門課程目前未開放報名', 400);
      if (course.price <= 0) throw new UserError('這門課程可免費報名', 400);
      const { data: enr } = await admin.from('enrollments').select('course_id').eq('user_id', user.id).eq('course_id', course.id).maybeSingle();
      if (enr) throw new UserError('你已經報名這門課程', 409);
      const { error: oerr } = await admin.from('orders').insert({
        merchant_trade_no: tradeNo, user_id: user.id, kind: 'course', amount: course.price, course_id: course.id,
      });
      if (oerr) throw oerr;
      result = await buildOneTimeFields(env, { tradeNo, amount: course.price, itemName: itemName([course.name]) }, urls);

    } else {
      throw new UserError('不支援的訂單類型');
    }
    return json(req, { ...result, tradeNo });
  } catch (e) {
    if (e instanceof UserError) return json(req, { error: e.message }, e.status);
    console.error('create-order failed', e);
    return json(req, { error: '系統忙碌,請稍後再試' }, 500);
  }
});
