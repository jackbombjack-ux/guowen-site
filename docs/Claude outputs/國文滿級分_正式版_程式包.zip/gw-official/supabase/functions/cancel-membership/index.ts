// 取消訂閱:請綠界停止之後的定期扣款。已付款的期間仍可使用到到期日。
import { createClient } from 'npm:@supabase/supabase-js@2';
import { PERIOD_ACTION_URL, type Params, checkMacValue, loadEcpayEnv, parseForm, verifyCheckMac } from '../_shared/ecpay.ts';
import { UserError } from '../_shared/checkout.ts';
import { corsHeaders, json, requireEnv } from '../_shared/http.ts';

const ALREADY_DISABLED = '90100149'; // 綠界:此訂單已停用

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(req) });
  if (req.method !== 'POST') return json(req, { error: 'method not allowed' }, 405);
  try {
    const supaUrl = requireEnv('SUPABASE_URL');
    const env = loadEcpayEnv((k) => Deno.env.get(k));
    const userClient = createClient(supaUrl, requireEnv('SUPABASE_ANON_KEY'), {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } }, auth: { persistSession: false },
    });
    const { data: ures, error: uerr } = await userClient.auth.getUser();
    if (uerr || !ures.user) throw new UserError('請先登入', 401);

    const admin = createClient(supaUrl, requireEnv('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
    const { data: mem } = await admin.from('memberships').select('status,source,order_id').eq('user_id', ures.user.id).maybeSingle();
    if (!mem) throw new UserError('你目前沒有付費會員', 404);
    if (mem.status === 'cancelled') return json(req, { ok: true, already: true });
    if (mem.source !== 'ecpay' || !mem.order_id) throw new UserError('這個會員資格不是用定期扣款開通的,請聯絡老師處理', 400);

    const { data: order } = await admin.from('orders').select('merchant_trade_no,user_id').eq('id', mem.order_id).maybeSingle();
    if (!order || order.user_id !== ures.user.id) throw new UserError('找不到訂閱紀錄', 404);

    const fields: Params = {
      MerchantID: env.merchantId,
      MerchantTradeNo: order.merchant_trade_no,
      Action: 'Cancel',
      TimeStamp: Math.floor(Date.now() / 1000),
    };
    fields.CheckMacValue = await checkMacValue(fields, env.hashKey, env.hashIV);
    const resp = await fetch(PERIOD_ACTION_URL[env.mode], {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(Object.entries(fields).map(([k, v]) => [k, String(v)])),
    });
    const out = parseForm(await resp.text());
    // 回應若帶有檢查碼就一併驗證
    if (out.CheckMacValue && !(await verifyCheckMac(out, env.hashKey, env.hashIV))) {
      throw new Error('ECPay response CheckMacValue mismatch');
    }
    if (out.RtnCode !== '1' && out.RtnCode !== ALREADY_DISABLED) {
      console.error('ECPay cancel failed', out.RtnCode, out.RtnMsg);
      throw new UserError('綠界暫時無法取消,請稍後再試或聯絡老師', 502);
    }
    await admin.from('memberships').update({ status: 'cancelled', updated_at: new Date().toISOString() }).eq('user_id', ures.user.id);
    return json(req, { ok: true });
  } catch (e) {
    if (e instanceof UserError) return json(req, { error: e.message }, e.status);
    console.error('cancel-membership failed', e);
    return json(req, { error: '系統忙碌,請稍後再試' }, 500);
  }
});
