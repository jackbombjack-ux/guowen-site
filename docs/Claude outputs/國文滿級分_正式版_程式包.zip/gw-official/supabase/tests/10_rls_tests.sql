-- 本機測試:權限規則與付款開通。用法見 tests/run.sh
\set ON_ERROR_STOP on
create schema if not exists t;
grant usage on schema t to public;

create or replace function t.as_user(u uuid) returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
create or replace function t.as_anon() returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', '', false); execute 'set role anon'; end $$;
create or replace function t.as_service() returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', '', false); execute 'set role service_role'; end $$;
create or replace function t.as_root() returns void language plpgsql as $$
begin execute 'reset role'; end $$;

create or replace function t.ok(name text, cond boolean) returns void language plpgsql as $$
begin
  if cond is not true then raise exception 'FAIL: %', name; end if;
  raise notice 'pass: %', name;
end $$;

-- 預期這段 SQL 會失敗(權限不足或 RLS 擋下)
create or replace function t.denied(name text, q text) returns void language plpgsql as $$
begin
  begin
    execute q;
  exception when others then
    raise notice 'pass: % (denied: %)', name, left(sqlerrm, 60);
    return;
  end;
  raise exception 'FAIL (should be denied): %', name;
end $$;


-- 預期 UPDATE/DELETE 被 RLS 悄悄擋下(影響 0 筆)
create or replace function t.noeffect(name text, q text) returns void language plpgsql as $$
declare n int;
begin
  begin
    execute q; get diagnostics n = row_count;
  exception when others then
    raise notice 'pass: % (denied: %)', name, left(sqlerrm, 60); return;
  end;
  if n <> 0 then raise exception 'FAIL (changed % rows): %', n, name; end if;
  raise notice 'pass: % (0 rows affected)', name;
end $$;

-- 預期查詢回傳筆數
create or replace function t.rows(name text, q text, n int) returns void language plpgsql as $$
declare c int;
begin
  execute 'select count(*) from (' || q || ') s' into c;
  if c <> n then raise exception 'FAIL: % (expected % rows, got %)', name, n, c; end if;
  raise notice 'pass: %', name;
end $$;

-- ============ 準備資料
\ir ../seed.sql
insert into public.admin_emails (email) values ('teacher@example.com');
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'Teacher@Example.com', '{"full_name":"老師"}'),
  ('00000000-0000-0000-0000-0000000000b1', 'alice@example.com', '{"full_name":"Alice"}'),
  ('00000000-0000-0000-0000-0000000000c1', 'bob@example.com', '{}');
update public.plans set active = true;   -- 測試用:開啟方案

select t.ok('admin email auto-promoted (case-insensitive)',
  (select role from public.profiles where id = '00000000-0000-0000-0000-0000000000a1') = 'admin');
select t.ok('student default role',
  (select role from public.profiles where id = '00000000-0000-0000-0000-0000000000b1') = 'student');
select t.ok('name falls back to email prefix',
  (select name from public.profiles where id = '00000000-0000-0000-0000-0000000000c1') = 'bob');
-- 後來才加入 admin_emails 的 Email,已存在帳號也會升級
insert into public.admin_emails (email) values ('bob@example.com');
select t.ok('late admin email promotes existing account',
  (select role from public.profiles where id = '00000000-0000-0000-0000-0000000000c1') = 'admin');
update public.profiles set role = 'student' where id = '00000000-0000-0000-0000-0000000000c1';
delete from public.admin_emails where email = 'bob@example.com';

-- ============ 匿名訪客
select t.as_anon();
select t.rows('anon sees products', 'select 1 from public.products', 6);
select t.rows('anon sees courses', 'select 1 from public.courses', 2);
select t.rows('anon sees active plans', 'select 1 from public.plans', 2);
select t.denied('anon cannot see profiles', 'select 1 from public.profiles');
select t.denied('anon cannot read orders', 'select 1 from public.orders');
select t.rows('anon sees no chapter videos', 'select 1 from public.chapter_videos', 0);
select t.denied('anon cannot write products', $$update public.products set price = 1$$);
select t.denied('anon cannot call apply_payment', $$select public.apply_payment('x','e',1,1,true,null,null,null,null,null)$$);
select t.denied('anon cannot enroll', $$select public.enroll_free('guoxie')$$);
select t.as_root();

-- ============ 老師建立直播連結、影片、一般資料
select t.as_user('00000000-0000-0000-0000-0000000000a1');
insert into public.live_events (id, title) overriding system value values (1, '會員直播');
insert into public.live_links (event_id, url) values (1, 'https://youtube.com/live/secret');
update public.courses set status = 'open' where id = 'guoxie';
update public.courses set price = 0 where id = 'guoxie';
insert into public.chapter_videos (chapter_id, youtube_id)
  select id, 'abcDEF12345' from public.course_chapters where course_id = 'guoxie' and position = 0;
select t.ok('admin can update product price', (select count(*) from public.products) = 6);
update public.products set price = 650 where id = 'tulong';
select t.ok('admin price update works', (select price from public.products where id = 'tulong') = 650);
update public.products set price = 600 where id = 'tulong';
select t.as_root();

-- ============ 學生:直播、影片、報名
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.rows('non-member cannot read live link', 'select 1 from public.live_links', 0);
select t.rows('student sees only own profile', 'select 1 from public.profiles', 1);
select t.rows('not enrolled -> no video id', 'select 1 from public.chapter_videos', 0);
select t.noeffect('student cannot write products', $$update public.products set price = 1$$);
select t.denied('student cannot grant self admin', $$update public.profiles set role = 'admin' where id = auth.uid()$$);
update public.profiles set name = 'Alice L' where id = auth.uid();
select t.ok('student can rename self', (select name from public.profiles where id = auth.uid()) = 'Alice L');
select t.denied('student cannot insert membership', $$insert into public.memberships (user_id, plan, valid_until) values (auth.uid(), 'monthly', now() + interval '1 year')$$);
select t.denied('student cannot insert order', $$insert into public.orders (merchant_trade_no, user_id, kind, amount) values ('X1', auth.uid(), 'product', 1)$$);
select t.denied('cannot enroll in draft course', $$select public.enroll_free('guwen')$$);
select public.enroll_free('guoxie');
select t.rows('enrolled -> sees video id', 'select 1 from public.chapter_videos', 1);
insert into public.progress (user_id, course_id, position) values (auth.uid(), 'guoxie', 3);
select t.denied('cannot save progress for course not enrolled', $$insert into public.progress (user_id, course_id, position) values (auth.uid(), 'guwen', 1)$$);
select t.as_root();

-- ============ 付款開通(service role)
-- 以 service role 建立訂單(Edge Function 的作法)
select t.as_service();
insert into public.orders (merchant_trade_no, user_id, kind, amount, plan_id)
  values ('GWMEM0001', '00000000-0000-0000-0000-0000000000b1', 'membership', 100, 'monthly');
insert into public.orders (id, merchant_trade_no, user_id, kind, amount, recipient_name)
  values ('11111111-1111-1111-1111-111111111111', 'GWBOOK001', '00000000-0000-0000-0000-0000000000c1', 'product', 1200, 'Bob');
insert into public.order_items (order_id, product_id, name, unit_price, qty) values
  ('11111111-1111-1111-1111-111111111111', 'tulong', '屠龍寶刀', 600, 2);
select t.ok('apply_payment: first membership payment applied',
  public.apply_payment('GWMEM0001','GWMEM0001:1',1,100,true,'EC1','GW1','1','ok','{}'::jsonb) = 'applied');
select t.ok('apply_payment: duplicate notification ignored',
  public.apply_payment('GWMEM0001','GWMEM0001:1',1,100,true,'EC1','GW1','1','ok','{}'::jsonb) = 'duplicate');
select t.ok('apply_payment: unknown order', public.apply_payment('NOPE','NOPE:1',1,100,true,null,null,'1','ok',null) = 'unknown_order');
select t.ok('apply_payment: wrong amount rejected', public.apply_payment('GWMEM0001','GWMEM0001:9',9,1,true,null,null,'1','ok',null) = 'amount_mismatch');
select t.as_root();
select t.ok('membership became active ~1 month',
  (select valid_until from public.memberships where user_id = '00000000-0000-0000-0000-0000000000b1') between now() + interval '27 days' and now() + interval '32 days');
select t.ok('order marked paid', (select status from public.orders where merchant_trade_no = 'GWMEM0001') = 'paid');

-- 第二期:從原到期日往後接,不是從今天
do $$ declare v1 timestamptz; v2 timestamptz; begin
  perform t.as_root();
  select valid_until into v1 from public.memberships where user_id = '00000000-0000-0000-0000-0000000000b1';
  perform set_config('request.jwt.claim.sub', '', false);
  execute 'set role service_role';
  perform public.apply_payment('GWMEM0001','GWMEM0001:2',2,100,true,'EC2','GW2','1','ok','{}'::jsonb);
  execute 'reset role';
  select valid_until into v2 from public.memberships where user_id = '00000000-0000-0000-0000-0000000000b1';
  if v2 <> v1 + interval '1 month' then raise exception 'FAIL: period 2 should extend from old end (% -> %)', v1, v2; end if;
  raise notice 'pass: period 2 extends from previous end';
end $$;

-- 實體書訂單 → 待出貨
select t.as_service();
select t.ok('product order applied', public.apply_payment('GWBOOK001','GWBOOK001:1',1,1200,true,'EC3',null,'1','ok','{}'::jsonb) = 'applied');
select t.as_root();
select t.ok('physical order -> to_ship', (select fulfillment from public.orders where merchant_trade_no = 'GWBOOK001') = 'to_ship');

-- 失敗通知:首期失敗 → 訂單 failed
select t.as_service();
insert into public.orders (merchant_trade_no, user_id, kind, amount, plan_id)
  values ('GWMEM0002', '00000000-0000-0000-0000-0000000000c1', 'membership', 100, 'monthly');
select t.ok('failed first auth recorded', public.apply_payment('GWMEM0002','GWMEM0002:fail:1',1,100,false,null,null,'10100058','刷卡失敗',null) = 'failed_recorded');
select t.as_root();
select t.ok('order failed', (select status from public.orders where merchant_trade_no = 'GWMEM0002') = 'failed');
select t.ok('no membership after failure', not exists (select 1 from public.memberships where user_id = '00000000-0000-0000-0000-0000000000c1'));

-- 付費課程訂單 → 自動報名
select t.as_service();
update public.courses set price = 500 where id = 'guwen';
insert into public.orders (merchant_trade_no, user_id, kind, amount, course_id)
  values ('GWCOUR001', '00000000-0000-0000-0000-0000000000c1', 'course', 500, 'guwen');
select public.apply_payment('GWCOUR001','GWCOUR001:1',1,500,true,'EC4',null,'1','ok','{}'::jsonb);
select t.as_root();
select t.ok('course order -> enrolled', exists (select 1 from public.enrollments where user_id = '00000000-0000-0000-0000-0000000000c1' and course_id = 'guwen'));

-- ============ 付費會員讀直播連結;別人的訂單看不到
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.rows('member can read live link', 'select 1 from public.live_links', 1);
select t.rows('student sees only own orders', 'select 1 from public.orders', 1);
select t.rows('student sees own payments only (success x2 + mismatch log)', 'select 1 from public.payments', 3);
select t.as_root();
-- 到期後(超過寬限)就看不到
update public.memberships set valid_until = now() - interval '4 days' where user_id = '00000000-0000-0000-0000-0000000000b1';
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.rows('expired member cannot read live link', 'select 1 from public.live_links', 0);
select t.as_root();
update public.memberships set valid_until = now() - interval '1 day' where user_id = '00000000-0000-0000-0000-0000000000b1';
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.rows('grace period still allows live link', 'select 1 from public.live_links', 1);
select t.as_root();

-- ============ 作文
select t.as_user('00000000-0000-0000-0000-0000000000b1');
insert into public.essays (id, student_id, created_by, source, title, grade)
  values ('22222222-2222-2222-2222-222222222222', auth.uid(), auth.uid(), 'student', '溫暖的心', '高三');
select t.denied('student cannot post as teacher', $$insert into public.essays (student_id, created_by, source, title) values (null, auth.uid(), 'teacher', 'x')$$);
select t.denied('student cannot pre-grade own essay', $$insert into public.essays (student_id, created_by, source, title, status, feedback) values (auth.uid(), auth.uid(), 'student', 'x', 'graded', '滿分')$$);
select t.denied('student cannot insert own transcript', $$insert into public.essays (student_id, created_by, source, title, transcript, transcript_status) values (auth.uid(), auth.uid(), 'student', 'x', '偽造內容', 'done')$$);
select t.noeffect('student cannot edit transcript', $$update public.essays set transcript = '改掉' where id = '22222222-2222-2222-2222-222222222222'$$);
select t.denied('student cannot submit for someone else', $$insert into public.essays (student_id, created_by, source, title) values ('00000000-0000-0000-0000-0000000000c1', auth.uid(), 'student', 'x')$$);
insert into public.essay_files (essay_id, path, page_no) values ('22222222-2222-2222-2222-222222222222', '22222222-2222-2222-2222-222222222222/submission-1.jpg', 1);
insert into storage.objects (bucket_id, name, owner) values ('essays', '22222222-2222-2222-2222-222222222222/submission-1.jpg', auth.uid());
select t.denied('student cannot upload into others essay folder',
  $$insert into storage.objects (bucket_id, name) values ('essays', '99999999-9999-9999-9999-999999999999/submission-1.jpg')$$);
select t.noeffect('student cannot update essay status', $$update public.essays set status = 'graded' where id = '22222222-2222-2222-2222-222222222222'$$);
select t.rows('student sees own essay', 'select 1 from public.essays', 1);
select t.rows('student sees own object', 'select 1 from storage.objects', 1);
select t.as_root();

select t.as_user('00000000-0000-0000-0000-0000000000c1');
select t.rows('other student sees no essays', 'select 1 from public.essays', 0);
select t.rows('other student sees no essay files', 'select 1 from public.essay_files', 0);
select t.rows('other student sees no objects', 'select 1 from storage.objects', 0);
select t.as_root();

select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.rows('teacher sees student essay', 'select 1 from public.essays', 1);
insert into public.essays (id, student_id, created_by, source, source_note, title, grade)
  values ('33333333-3333-3333-3333-333333333333', null, auth.uid(), 'teacher', '王同學', '靜夜情懷', '國三');
insert into storage.objects (bucket_id, name) values ('essays', '33333333-3333-3333-3333-333333333333/submission-1.jpg');
select t.rows('teacher sees all essays', 'select 1 from public.essays', 2);
update public.essays set status = 'graded', feedback = '結尾可再收束', graded_at = now(), graded_by = auth.uid()
  where id = '22222222-2222-2222-2222-222222222222';
insert into public.essay_files (essay_id, path, kind) values ('22222222-2222-2222-2222-222222222222', '22222222-2222-2222-2222-222222222222/feedback-1.jpg', 'feedback');
insert into storage.objects (bucket_id, name) values ('essays', '22222222-2222-2222-2222-222222222222/feedback-1.jpg');
select t.as_root();
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.ok('student reads teacher feedback', (select feedback from public.essays where id = '22222222-2222-2222-2222-222222222222') = '結尾可再收束');
select t.rows('student sees feedback photo', $$select 1 from storage.objects where name like '%feedback-1.jpg'$$, 1);
select t.as_root();

-- ============ 免費資源、聯絡表單
select t.as_user('00000000-0000-0000-0000-0000000000b1');
insert into public.resource_claims (user_id, resource_id) values (auth.uid(), 'r1');
select t.denied('cannot claim for others', $$insert into public.resource_claims (user_id, resource_id) values ('00000000-0000-0000-0000-0000000000c1', 'r2')$$);
select t.denied('cannot claim non-gated resource', $$insert into public.resource_claims (user_id, resource_id) values (auth.uid(), 'r3')$$);
select t.as_root();
select t.as_anon();
insert into public.contact_messages (name, email, message) values ('訪客', 'v@example.com', '你好');
select t.denied('anon cannot read messages', 'select 1 from public.contact_messages');
select t.denied('bad email rejected', $$insert into public.contact_messages (name, email, message) values ('a','nope','hi')$$);
select t.as_root();
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.rows('teacher reads messages', 'select 1 from public.contact_messages', 1);
select t.as_root();

-- ============ 學生清掉自己未批改的作文
select t.as_user('00000000-0000-0000-0000-0000000000b1');
insert into public.essays (id, student_id, created_by, source, title, grade)
  values ('44444444-4444-4444-4444-444444444444', auth.uid(), auth.uid(), 'student', '失敗的上傳', '高三');
insert into storage.objects (bucket_id, name, owner) values ('essays', '44444444-4444-4444-4444-444444444444/submission-1.jpg', auth.uid());
delete from storage.objects where name like '44444444%';
select t.rows('student cleaned own pending photo', $$select 1 from storage.objects where name like '44444444%'$$, 0);
delete from public.essays where id = '44444444-4444-4444-4444-444444444444';
select t.rows('student cleaned own pending essay', $$select 1 from public.essays where id = '44444444-4444-4444-4444-444444444444'$$, 0);
select t.noeffect('student cannot delete graded essay', $$delete from public.essays where id = '22222222-2222-2222-2222-222222222222'$$);
select t.rows('graded essay still there', $$select 1 from public.essays where id = '22222222-2222-2222-2222-222222222222'$$, 1);
select t.as_root();
select t.as_user('00000000-0000-0000-0000-0000000000c1');
select t.noeffect('other student cannot delete', $$delete from public.essays where id = '22222222-2222-2222-2222-222222222222'$$);
select t.as_root();

-- ============ 辨識額度(只有後端 service role 能動)
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.denied('student cannot call ocr_reserve', $$select public.ocr_reserve('2026-10', 1, 950)$$);
select t.denied('student cannot write ocr_usage', $$insert into public.ocr_usage(month, units) values ('2026-10', 0)$$);
select t.denied('student cannot read ocr_usage', $$select 1 from public.ocr_usage$$);
select t.denied('student cannot set transcript_engine on insert', $$insert into public.essays (student_id, created_by, source, title, transcript_engine) values (auth.uid(), auth.uid(), 'student', 'x', 'vision')$$);
select t.as_service();
select t.ok('reserve within limit', public.ocr_reserve('2026-10', 3, 5));
select t.ok('reserve over limit is refused', not public.ocr_reserve('2026-10', 3, 5));
select t.ok('units unchanged after refusal', (select units from public.ocr_usage where month = '2026-10') = 3);
select public.ocr_reserve('2026-10', -3, 5);
select t.ok('refund returns units', (select units from public.ocr_usage where month = '2026-10') = 0);
select public.ocr_reserve('2026-10', -9, 5);
select t.ok('refund never goes below zero', (select units from public.ocr_usage where month = '2026-10') = 0);
select t.ok('exact limit allowed', public.ocr_reserve('2026-11', 5, 5));
select t.as_root();


-- ============ 分數 / 已讀 / 評語範本
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.denied('student cannot insert with score', $$insert into public.essays (student_id, created_by, source, title, score, score_max) values (auth.uid(), auth.uid(), 'student', 'x', 60, 60)$$);
select t.rows('student sees no templates', 'select 1 from public.feedback_templates', 0);
select t.noeffect('student cannot update own score', $$update public.essays set score = 60, score_max = 60 where student_id = auth.uid()$$);
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.ok('teacher can read seeded templates', (select count(*) from public.feedback_templates) >= 6);
update public.essays set score = 45.5, score_max = 60, status = 'graded', student_seen_at = null where id = '22222222-2222-2222-2222-222222222222';
select t.ok('teacher set score', (select score from public.essays where id = '22222222-2222-2222-2222-222222222222') = 45.5);
select t.denied('score above max rejected', $$update public.essays set score = 61, score_max = 60 where id = '22222222-2222-2222-2222-222222222222'$$);
select t.denied('score without max rejected', $$update public.essays set score = 10, score_max = null where id = '22222222-2222-2222-2222-222222222222'$$);
insert into public.feedback_templates(label, body) values ('測試', '範本內容');
select t.rows('teacher can add template', $$select 1 from public.feedback_templates where label = '測試'$$, 1);
delete from public.feedback_templates where label = '測試';
select t.rows('teacher can delete template', $$select 1 from public.feedback_templates where label = '測試'$$, 0);
select t.as_root();
select t.as_user('00000000-0000-0000-0000-0000000000c1');
select t.ok('other student marks nothing seen', public.mark_essays_seen() = 0);
select t.ok('other student essay still unseen', (select student_seen_at from public.essays where id = '22222222-2222-2222-2222-222222222222' ) is null) ;
select t.as_root();
select t.as_user('00000000-0000-0000-0000-0000000000b1');
select t.ok('owner marks graded essay seen', public.mark_essays_seen() >= 1);
select t.ok('seen timestamp set', (select student_seen_at from public.essays where id = '22222222-2222-2222-2222-222222222222') is not null);
select t.ok('second call changes nothing', public.mark_essays_seen() = 0);
select t.as_root();

\echo ALL TESTS PASSED
