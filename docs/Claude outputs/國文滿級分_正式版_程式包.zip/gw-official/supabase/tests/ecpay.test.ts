// 綠界檢查碼測試。執行:node --test supabase/tests/ecpay.test.ts(Node 22.18+)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkMacValue, verifyCheckMac, netUrlEncode, newTradeNo, tradeDate, parseForm, loadEcpayEnv } from '../functions/_shared/ecpay.ts';

// 綠界官方文件「檢查碼機制」(AIO,SHA256)的範例
test('官方範例:CheckMacValue 與文件一致', async () => {
  const params = {
    TradeDesc: '促銷方案', PaymentType: 'aio', MerchantTradeDate: '2023/03/12 15:30:23',
    MerchantTradeNo: 'ecpay20230312153023', MerchantID: '3002607',
    ReturnURL: 'https://www.ecpay.com.tw/receive.php', ItemName: 'Apple iphone 15',
    TotalAmount: 30000, ChoosePayment: 'ALL', EncryptType: 1,
  };
  const mac = await checkMacValue(params, 'pwFHCqoQZGmho4w6', 'EkRm7iFT261dpevs');
  assert.equal(mac, '6C51C9E6888DE861FD62FB1DD17029FC742634498FD813DC43D4243B5685B840');
});

test('驗證:正確的檢查碼通過,被改過的金額不通過', async () => {
  const key = 'pwFHCqoQZGmho4w6', iv = 'EkRm7iFT261dpevs';
  const p: Record<string, string> = { MerchantID: '3002607', MerchantTradeNo: 'GW1', RtnCode: '1', TradeAmt: '600' };
  p.CheckMacValue = await checkMacValue(p, key, iv);
  assert.equal(await verifyCheckMac(p, key, iv), true);
  assert.equal(await verifyCheckMac({ ...p, TradeAmt: '1' }, key, iv), false);
  assert.equal(await verifyCheckMac({ ...p, CheckMacValue: '' }, key, iv), false);
  assert.equal(await verifyCheckMac(p, key, 'wrongiv'), false);
  // 檢查碼大小寫不拘
  assert.equal(await verifyCheckMac({ ...p, CheckMacValue: p.CheckMacValue.toLowerCase() }, key, iv), true);
});

test('編碼:.NET 風格(空白 +、~ 與 \' 要編碼、- _ . ! * ( ) 不編碼)', () => {
  assert.equal(netUrlEncode('a b'), 'a+b');
  assert.equal(netUrlEncode("A~B'C"), 'a%7eb%27c');
  assert.equal(netUrlEncode('x-y_z.w!v*u(t)'), 'x-y_z.w!v*u(t)');
  assert.equal(netUrlEncode('屠龍'), '%e5%b1%a0%e9%be%8d');
  assert.equal(netUrlEncode('a&b=c/d:e'), 'a%26b%3dc%2fd%3ae');
});

test('排序不分大小寫:小寫開頭的 gwsr 排在 FirstAuthAmount 與 MerchantID 之間', async () => {
  // 手算:key 依 lowercase 排序 → FirstAuthAmount, gwsr, MerchantID
  const p = { MerchantID: 'm', gwsr: '9', FirstAuthAmount: '5' };
  const raw = 'HashKey=k&FirstAuthAmount=5&gwsr=9&MerchantID=m&HashIV=v';
  const { sha256Hex } = await import('../functions/_shared/ecpay.ts');
  const expect = (await sha256Hex(netUrlEncode(raw))).toUpperCase();
  assert.equal(await checkMacValue(p, 'k', 'v'), expect);
});

test('工具:交易編號、時間格式、表單解析、環境設定', () => {
  const a = newTradeNo(), b = newTradeNo();
  assert.match(a, /^[A-Z0-9]{1,20}$/);
  assert.notEqual(a, b);
  assert.match(tradeDate(new Date('2026-10-22T16:30:05Z')), /^2026\/10\/23 00:30:05$/); // UTC+8
  assert.deepEqual(parseForm('a=1&b=%E4%B8%AD+%E6%96%87'), { a: '1', b: '中 文' });
  const stage = loadEcpayEnv(() => undefined);
  assert.equal(stage.mode, 'stage');
  assert.equal(stage.merchantId, '3002607');
  assert.throws(() => loadEcpayEnv((k) => (k === 'ECPAY_MODE' ? 'production' : undefined)), /尚未設定/);
});
