#!/usr/bin/env bash
# 本機測試資料庫權限規則(需要本機有 PostgreSQL,不會碰到雲端)
# 用法: PGHOST=/tmp PGPORT=5433 PGUSER=postgres bash supabase/tests/run.sh
set -euo pipefail
cd "$(dirname "$0")"
DB=gw_test
psql -v ON_ERROR_STOP=1 -q -d postgres -c "drop database if exists $DB" -c "create database $DB"
for f in 00_stub_supabase.sql ../migrations/*.sql 10_rls_tests.sql; do
  echo "== $f"; psql -v ON_ERROR_STOP=1 -q -d $DB -f "$f" 2>&1 | grep -E "pass:|FAIL|ERROR|ALL TESTS" || true
done
