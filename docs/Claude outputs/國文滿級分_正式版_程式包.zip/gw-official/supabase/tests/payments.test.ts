// 付款通知與結帳邏輯測試。執行:node --test supabase/tests/payments.test.ts
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkMacValue, STAGE_TEST, type EcpayEnv } from '../functions/_shared/ecpay.ts';
import { handleNotification, type Rpc } from '../functions/_shared/payments.ts';
import { buildOneTimeFields, buildPeriodFields, itemName, priceCart, validateRecipient, UserError, type ProductRow, type PlanRow } from '../functions/_shared/checkout.ts';

const env: EcpayEnv = { mode: 'stage', merchantId: STAGE_TEST.merchantId, hashKey: STAGE_TEST.hashKey, hashIV: STAGE_TEST.hashIV };
const quiet = () => {};

async function signed(fields: Record<string, string>) {
  return { ...fields, CheckMacValue: await checkMacValue(fields, env.hashKey, env.hashIV) };
}
function fakeRpc(result: unknown = 'applied', error: { message: string } | null = null) {
  const calls: Record<string, unknown>[] = [];
  const rpc: Rpc = async (_fn, args) => { calls.push(args); return { data: result, error }; };
  return { rpc, calls };
}

test('一般付款成功:驗章通過 → 呼叫 apply_payment → 回 1|OK', async () => {
  const { rpc, calls } = fakeRpc('applied');
  const form = await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWABC', RtnCode: '1', RtnMsg: '交易成功', TradeNo: 'EC9', TradeAmt: '1200', PaymentType: 'Credit_CreditCard' });
  const r = await handleNotification('return', form, env, rpc, quiet);
  assert.deepEqual([r.status, r.body, r.outcome], [200, '1|OK', 'applied']);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].p_trade_no, 'GWABC');
  assert.equal(calls[0].p_event_key, 'GWABC:1');
  assert.equal(calls[0].p_amount, 1200);
  assert.equal(calls[0].p_success, true);
});

test('檢查碼錯誤:回 400,絕不呼叫資料庫', async () => {
  const { rpc, calls } = fakeRpc();
  const form = { ...(await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWABC', RtnCode: '1', TradeAmt: '1200' })), TradeAmt: '1' };
  const r = await handleNotification('return', form, env, rpc, quiet);
  assert.equal(r.status, 400);
  assert.equal(calls.length, 0);
});

test('別家商店代號:拒絕', async () => {
  const { rpc, calls } = fakeRpc();
  const form = await signed({ MerchantID: '2000132', MerchantTradeNo: 'GWABC', RtnCode: '1', TradeAmt: '100' });
  const r = await handleNotification('return', form, env, rpc, quiet);
  assert.deepEqual([r.status, r.outcome, calls.length], [400, 'bad_merchant', 0]);
});

test('模擬付款(SimulatePaid=1):回 1|OK 但不開通', async () => {
  const { rpc, calls } = fakeRpc();
  const form = await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWABC', RtnCode: '1', TradeAmt: '100', SimulatePaid: '1' });
  const r = await handleNotification('return', form, env, rpc, quiet);
  assert.deepEqual([r.status, r.body, r.outcome, calls.length], [200, '1|OK', 'simulated', 0]);
});

test('付款失敗:記錄失敗事件,success=false', async () => {
  const { rpc, calls } = fakeRpc('failed_recorded');
  const form = await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWABC', RtnCode: '10100058', RtnMsg: '授權失敗', TradeAmt: '100' });
  const r = await handleNotification('return', form, env, rpc, quiet);
  assert.equal(r.status, 200);
  assert.equal(calls[0].p_success, false);
  assert.match(String(calls[0].p_event_key), /^GWABC:fail:10100058:/);
});

test('資料庫暫時出錯:回 500,讓綠界稍後重送', async () => {
  const { rpc } = fakeRpc(null, { message: 'connection reset' });
  const form = await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWABC', RtnCode: '1', TradeAmt: '100' });
  const r = await handleNotification('return', form, env, rpc, quiet);
  assert.deepEqual([r.status, r.outcome], [500, 'db_error']);
});

test('重複通知:資料庫回 duplicate,仍回 1|OK', async () => {
  const { rpc } = fakeRpc('duplicate');
  const form = await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWABC', RtnCode: '1', TradeAmt: '100', TradeNo: 'X' });
  const r = await handleNotification('return', form, env, rpc, quiet);
  assert.deepEqual([r.status, r.body, r.outcome], [200, '1|OK', 'duplicate']);
});

test('定期定額每期通知:含小寫 gwsr 的欄位也能驗章,期數取自 TotalSuccessTimes', async () => {
  const { rpc, calls } = fakeRpc('applied');
  const form = await signed({
    MerchantID: '3002607', MerchantTradeNo: 'GWPER1', RtnCode: '1', RtnMsg: 'ok', PeriodType: 'M', Frequency: '1', ExecTimes: '99',
    Amount: '100', gwsr: '12345', ProcessDate: '2026/11/23 10:00:00', AuthCode: '777777', FirstAuthAmount: '100', TotalSuccessTimes: '2',
  });
  const r = await handleNotification('period', form, env, rpc, quiet);
  assert.deepEqual([r.status, r.outcome], [200, 'applied']);
  assert.equal(calls[0].p_event_key, 'GWPER1:2');
  assert.equal(calls[0].p_seq, 2);
  assert.equal(calls[0].p_amount, 100);
  assert.equal(calls[0].p_gwsr, '12345');
});

test('定期定額失敗(扣款失敗)不會延長會員', async () => {
  const { rpc, calls } = fakeRpc('failed_recorded');
  const form = await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWPER1', RtnCode: '10100058', RtnMsg: '失敗', Amount: '100', gwsr: '9', ProcessDate: '2026/12/23 10:00:00', TotalSuccessTimes: '2' });
  await handleNotification('period', form, env, rpc, quiet);
  assert.equal(calls[0].p_success, false);
  assert.equal(calls[0].p_seq, 3);
});

// ---------------- 結帳 ----------------
const products: ProductRow[] = [
  { id: 'a', name: '屠龍寶刀', title: 't', price: 600, kind: 'physical', active: true },
  { id: 'b', name: '電子書', title: 't', price: 300, kind: 'digital', active: true },
  { id: 'c', name: '下架書', title: 't', price: 100, kind: 'physical', active: false },
];

test('購物車:伺服器端算價,忽略前端金額', () => {
  const r = priceCart([{ id: 'a', qty: 2, price: 1 }, { id: 'b', qty: 1 }], products);
  assert.equal(r.total, 1500);
  assert.equal(r.needsShipping, true);
  assert.equal(priceCart([{ id: 'b', qty: 1 }], products).needsShipping, false);
});

test('購物車:拒絕下架、重複、數量不合理、空車', () => {
  for (const bad of [[], [{ id: 'c', qty: 1 }], [{ id: 'zz', qty: 1 }], [{ id: 'a', qty: 0 }], [{ id: 'a', qty: 21 }], [{ id: 'a', qty: 1.5 }], [{ id: 'a', qty: 1 }, { id: 'a', qty: 1 }], null]) {
    assert.throws(() => priceCart(bad, products), UserError);
  }
});

test('收件資料驗證', () => {
  assert.deepEqual(validateRecipient({ name: ' 王小明 ', phone: '0912-345-678', address: '台北市中正區重慶南路一段 122 號' }),
    { name: '王小明', phone: '0912-345-678', address: '台北市中正區重慶南路一段 122 號' });
  assert.throws(() => validateRecipient({ name: '', phone: '0912345678', address: '台北市中正區' }), UserError);
  assert.throws(() => validateRecipient({ name: 'a', phone: 'abc', address: '台北市中正區' }), UserError);
  assert.throws(() => validateRecipient({ name: 'a', phone: '0912345678', address: '短' }), UserError);
  assert.throws(() => validateRecipient(undefined), UserError);
});

test('ItemName:# 是分隔符,使用者內容中的 # 與換行要清掉;過長要截斷', () => {
  assert.equal(itemName(['A#B', 'C\nD']), 'A B#C D');
  assert.ok(itemName(['x'.repeat(500)]).length <= 400);
});

const urls = { returnUrl: 'https://p.supabase.co/functions/v1/ecpay-return', periodReturnUrl: 'https://p.supabase.co/functions/v1/ecpay-period-return', clientBackUrl: 'https://site.example/member.html?pay=GW1' };

test('一次性付款欄位:有檢查碼、ChoosePayment=ALL、金額正確', async () => {
  const { url, fields } = await buildOneTimeFields(env, { tradeNo: 'GW1', amount: 1500, itemName: '屠龍寶刀 x2' }, urls);
  assert.match(url, /payment-stage\.ecpay\.com\.tw/);
  assert.equal(fields.ChoosePayment, 'ALL');
  assert.equal(fields.TotalAmount, 1500);
  assert.equal(fields.CheckMacValue, await checkMacValue(fields, env.hashKey, env.hashIV));
  assert.equal(fields.PeriodType, undefined);
});

const monthly: PlanRow = { id: 'monthly', name: '月繳', amount: 100, period_type: 'M', frequency: 1, exec_times: 99, active: true };
test('定期定額欄位:Credit、PeriodAmount = TotalAmount、有 PeriodReturnURL', async () => {
  const { fields } = await buildPeriodFields(env, { tradeNo: 'GW2', plan: monthly }, urls);
  assert.equal(fields.ChoosePayment, 'Credit');
  assert.equal(fields.PeriodAmount, fields.TotalAmount);
  assert.deepEqual([fields.PeriodType, fields.Frequency, fields.ExecTimes], ['M', 1, 99]);
  assert.equal(fields.PeriodReturnURL, urls.periodReturnUrl);
  assert.equal(fields.CheckMacValue, await checkMacValue(fields, env.hashKey, env.hashIV));
});

test('定期定額:超出綠界限制的方案設定會被擋下', async () => {
  for (const bad of [{ ...monthly, exec_times: 100 }, { ...monthly, frequency: 13 }, { ...monthly, period_type: 'Y' as const, frequency: 2, exec_times: 5 }, { ...monthly, period_type: 'Y' as const, frequency: 1, exec_times: 10 }]) {
    await assert.rejects(buildPeriodFields(env, { tradeNo: 'GW3', plan: bad }, urls), UserError);
  }
});

// 前後端介面對照:Edge Function 傳給 apply_payment 的參數名稱,必須和 SQL 函式宣告完全一致
import { readFileSync } from 'node:fs';
test('apply_payment 參數名稱與 SQL 宣告一致', async () => {
  const sql = readFileSync(new URL('../migrations/20261023000002_security.sql', import.meta.url), 'utf8');
  const m = sql.match(/function public\.apply_payment\(([\s\S]*?)\)\s*returns text/);
  assert.ok(m, '找不到 apply_payment 宣告');
  const sqlNames = [...m![1].matchAll(/\b(p_[a-z_]+)\b/g)].map((x) => x[1]).sort();
  const { rpc, calls } = fakeRpc();
  const form = await signed({ MerchantID: '3002607', MerchantTradeNo: 'GWABC', RtnCode: '1', TradeAmt: '100' });
  await handleNotification('return', form, env, rpc, quiet);
  assert.deepEqual(Object.keys(calls[0]).sort(), sqlNames);
});
