-- 由 gen_seed.py 從網站內容自動產生。價格與是否為實體書皆為暫定值,上線前請在老師後台或這裡修改。

insert into public.site_settings (key, value) values
  ('price_confirmed', 'false'::jsonb),
  ('payments_enabled', 'false'::jsonb),
  ('line_url', '""'::jsonb),
  ('youtube_url', '""'::jsonb),
  ('ga_id', '""'::jsonb)
on conflict (key) do nothing;

insert into public.products (id, kind, name, title, price, active, sort) values
  ('tulong', 'physical', '屠龍寶刀', '高中國寫之屠龍寶刀', 600, true, 0),
  ('yitian', 'physical', '倚天神劍', '高中國寫之倚天神劍', 600, true, 1),
  ('notes', 'physical', '國文學霸筆記 核心古文15篇', '國文學霸筆記――核心古文 15 篇', 600, true, 2),
  ('gaokao', 'physical', '學測國寫全攻略', '學測國寫全攻略:歷屆試題解析 × 範文精讀', 600, true, 3),
  ('jhfa', 'physical', '國中作文高分秘笈・功法篇', '國中作文高分秘笈・功法篇', 600, true, 4),
  ('jhsu', 'physical', '國中作文高分秘笈・素材篇', '國中作文高分秘笈・素材篇', 600, true, 5)
on conflict (id) do nothing;

insert into public.courses (id, name, price, status, sort) values
  ('guoxie', '學測國寫衝刺班', 0, 'draft', 0),
  ('guwen', '十五核心古文總複習', 0, 'draft', 1)
on conflict (id) do nothing;

insert into public.course_chapters (course_id, position, title) values
  ('guoxie', 0, '文體:作文三體六面一點通'),
  ('guoxie', 1, '審題:審題五芒星與立意金字塔'),
  ('guoxie', 2, '結構(一)起:開頭起筆,破題定調'),
  ('guoxie', 3, '結構(二)承:段落延展,鋪陳深化'),
  ('guoxie', 4, '結構(三)轉:劇情轉折,引爆亮點'),
  ('guoxie', 5, '結構(四)合:收束全文,餘韻悠長'),
  ('guoxie', 6, '知性類作文命題趨勢與高分技巧'),
  ('guoxie', 7, '情意類作文命題趨勢與高分技巧'),
  ('guoxie', 8, '鍛字鍊句:放大鏡寫作法與映像放射器'),
  ('guoxie', 9, '鍛字鍊句:魔法變形術、典故召喚陣與佳句模板'),
  ('guwen', 0, '師說'),
  ('guwen', 1, '項脊軒志'),
  ('guwen', 2, '桃花源記'),
  ('guwen', 3, '晚遊六橋待月記'),
  ('guwen', 4, '鹿港乘桴記'),
  ('guwen', 5, '出師表'),
  ('guwen', 6, '燭之武退秦師'),
  ('guwen', 7, '勞山道士'),
  ('guwen', 8, '赤壁賦'),
  ('guwen', 9, '大同與小康'),
  ('guwen', 10, '畫菊自序'),
  ('guwen', 11, '諫逐客書'),
  ('guwen', 12, '勸和論'),
  ('guwen', 13, '虬髯客傳'),
  ('guwen', 14, '鴻門宴')
on conflict (course_id, position) do nothing;

-- 會員方案:金額是佔位值(inactive),價格確認後把 amount 改成正式價格並設 active = true
insert into public.plans (id, name, amount, period_type, frequency, exec_times, active, sort) values
  ('monthly', '月繳', 100, 'M', 1, 99, false, 0),   -- PLACEHOLDER 金額
  ('yearly',  '年繳', 1000, 'Y', 1, 9,  false, 1)    -- PLACEHOLDER 金額
on conflict (id) do nothing;

insert into public.resources (id, name, gate, href) values
  ('r1', '學測國寫全攻略 試讀', true, null),
  ('r2', '教材完整目錄', true, null),
  ('r3', 'Instagram 學習貼文', false, 'https://www.instagram.com/chinese.win/'),
  ('r4', 'Threads 國文短講', false, 'https://www.threads.com/@chinese.win')
on conflict (id) do nothing;

-- 老師帳號:改成客戶實際的 Google Email(小寫),第一次登入就會是 admin
-- insert into public.admin_emails (email) values ('teacher@gmail.com');
