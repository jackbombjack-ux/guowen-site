/* ---------- 水墨 4.0:預先繪製的山水(亮/暗兩版),覆寫 scene / heroSVG ----------
   山水圖由程式原創生成:層層遠山、雲霧、墨黑松崖。亮色用宣紙底,暗色用夜色墨景。 */
function inkImgs(name,pos){
  var st=pos?' style="object-position:'+pos+'"':'';
  return '<img class="sc ir on-light" src="images/ink/'+name+'-light.webp" alt="" loading="lazy" decoding="async"'+st+'>'+
         '<img class="sc ir on-dark" src="images/ink/'+name+'-dark.webp" alt="" loading="lazy" decoding="async"'+st+'>';
}
function scene(seed,o){
  var n=Math.abs(Math.round(seed*3+(o&&o.pines?1:0)+(o&&o.sun?2:0)))%8;
  return inkImgs('s'+n,'50% 72%');
}
function heroSVG(){
  function layer(i,k){
    return '<div class="hl hl'+i+(k?' px':'')+'"'+(k?' data-k="'+k+'"':'')+'>'+
      '<img class="ir on-light" src="images/ink/hero-light-'+i+'.webp" alt="" decoding="async">'+
      '<img class="ir on-dark" src="images/ink/hero-dark-'+i+'.webp" alt="" decoding="async"></div>';
  }
  return layer(0,0)+layer(1,9)+layer(2,20);
}
function footerMtn(){return ''}
