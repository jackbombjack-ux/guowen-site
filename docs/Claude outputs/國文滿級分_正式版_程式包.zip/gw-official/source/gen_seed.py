# -*- coding: utf-8 -*-
"""由 content.py 產生 supabase/seed.sql(教材、課程、章節、資源、設定)"""
import sys, json
sys.path.insert(0, '.')
from content import PRODUCTS, COURSES, RESOURCES
q = lambda s: "'" + str(s).replace("'", "''") + "'"
out = ['-- 由 gen_seed.py 從網站內容自動產生。價格與是否為實體書皆為暫定值,上線前請在老師後台或這裡修改。', '']
out.append('insert into public.site_settings (key, value) values')
out.append("  ('price_confirmed', 'false'::jsonb),\n  ('payments_enabled', 'false'::jsonb),\n  ('line_url', '\"\"'::jsonb),\n  ('youtube_url', '\"\"'::jsonb),\n  ('ga_id', '\"\"'::jsonb)\non conflict (key) do nothing;\n")
out.append('insert into public.products (id, kind, name, title, price, active, sort) values')
rows = []
for i, p in enumerate(PRODUCTS):
    rows.append("  (%s, 'physical', %s, %s, %d, true, %d)" % (q(p['id']), q(p['name']), q(p['title']), p['price'], i))
out.append(',\n'.join(rows) + '\non conflict (id) do nothing;\n')
out.append('insert into public.courses (id, name, price, status, sort) values')
out.append(',\n'.join("  (%s, %s, 0, 'draft', %d)" % (q(c['id']), q(c['name']), i) for i, c in enumerate(COURSES)) + '\non conflict (id) do nothing;\n')
out.append('insert into public.course_chapters (course_id, position, title) values')
rows = []
for c in COURSES:
    for i, t in enumerate(c['chaps']):
        rows.append("  (%s, %d, %s)" % (q(c['id']), i, q(t)))
out.append(',\n'.join(rows) + '\non conflict (course_id, position) do nothing;\n')
out.append('-- 會員方案:金額是佔位值(inactive),價格確認後把 amount 改成正式價格並設 active = true')
out.append("insert into public.plans (id, name, amount, period_type, frequency, exec_times, active, sort) values\n  ('monthly', '月繳', 100, 'M', 1, 99, false, 0),   -- PLACEHOLDER 金額\n  ('yearly',  '年繳', 1000, 'Y', 1, 9,  false, 1)    -- PLACEHOLDER 金額\non conflict (id) do nothing;\n")
out.append('insert into public.resources (id, name, gate, href) values')
rows = []
for r in RESOURCES:
    rows.append("  (%s, %s, %s, %s)" % (q(r['id']), q(r['name']), 'true' if r['gate'] else 'false', q(r['href']) if r.get('href') else 'null'))
out.append(',\n'.join(rows) + '\non conflict (id) do nothing;\n')
out.append("-- 老師帳號:改成客戶實際的 Google Email(小寫),第一次登入就會是 admin\n-- insert into public.admin_emails (email) values ('teacher@gmail.com');\n")
open('repo/supabase/seed.sql', 'w', encoding='utf-8').write('\n'.join(out))
print('seed written')
