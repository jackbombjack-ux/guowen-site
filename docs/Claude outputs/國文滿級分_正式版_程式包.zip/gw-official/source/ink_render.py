# -*- coding: utf-8 -*-
"""程式生成水墨山水(原創,不使用任何現成圖片)。
輸出:hero 三層(遠/中/近,供視差)與 8 張場景圖,各有亮色與暗色版。"""
import numpy as np, math, os, sys
from PIL import Image, ImageDraw, ImageFilter
from scipy.ndimage import gaussian_filter, gaussian_filter1d

OUT = os.environ.get('INK_OUT', 'ink_out')

PAL = {
    'light': dict(
        sky_top=(249, 246, 239), sky_bot=(236, 230, 217), haze=(244, 240, 231),
        tone=[(168, 171, 173), (126, 129, 132), (84, 86, 90), (46, 47, 50), (17, 17, 19)],
        grain=1.0),
    'dark': dict(
        sky_top=(14, 19, 28), sky_bot=(40, 53, 70), haze=(70, 86, 108),
        tone=[(62, 78, 100), (47, 61, 80), (32, 43, 59), (19, 27, 39), (6, 9, 14)],
        grain=0.5),
}

# ---------------------------------------------------------------- 雜訊工具
def rs(seed): return np.random.RandomState(seed & 0x7fffffff)

def fbm1(n, seed, scales=(1, .5, .25, .12, .06), amps=(1, .55, .3, .16, .08)):
    r = rs(seed); out = np.zeros(n, np.float32)
    for s, a in zip(scales, amps):
        sig = max(1.0, n * s * .05)
        v = gaussian_filter1d(r.randn(n).astype(np.float32), sig, mode='wrap')
        v /= (v.std() + 1e-6); out += a * v
    out /= (np.abs(out).max() + 1e-6)
    return out

def noise2(h, w, seed, sx, sy, mode='reflect'):
    r = rs(seed)
    v = gaussian_filter(r.randn(h, w).astype(np.float32), (sy, sx), mode=mode)
    v -= v.mean(); v /= (v.std() + 1e-6)
    return v

def lerp(a, b, t): return a + (b - a) * t
def smooth(x): x = np.clip(x, 0, 1); return x * x * (3 - 2 * x)

# ---------------------------------------------------------------- 畫布與合成
class Layer:
    """RGBA(預乘前)浮點畫布;alpha 0..1"""
    def __init__(self, W, H):
        self.W, self.H = W, H
        self.rgb = np.zeros((H, W, 3), np.float32)
        self.a = np.zeros((H, W), np.float32)

    def over(self, rgb, a):
        """把 (rgb, a) 疊在自己上面"""
        a3 = a[..., None]
        oa = self.a[..., None]
        na = a3 + oa * (1 - a3)
        with np.errstate(divide='ignore', invalid='ignore'):
            nrgb = np.where(na > 1e-6, (rgb * a3 + self.rgb * oa * (1 - a3)) / np.maximum(na, 1e-6), 0)
        self.rgb = nrgb.astype(np.float32); self.a = na[..., 0].astype(np.float32)

    def fill(self, rgb): self.over(np.broadcast_to(np.array(rgb, np.float32), (self.H, self.W, 3)), np.ones((self.H, self.W), np.float32))

    def sky(self, top, bot, horizon=.62):
        y = np.linspace(0, 1, self.H, dtype=np.float32)[:, None]
        t = smooth(y / horizon)
        top = np.array(top, np.float32); bot = np.array(bot, np.float32)
        img = top[None, None, :] * (1 - t[..., None]) + bot[None, None, :] * t[..., None]
        self.over(np.broadcast_to(img, (self.H, self.W, 3)), np.ones((self.H, self.W), np.float32))

    def image(self, bg=None):
        """輸出 RGBA uint8;bg 為底色則先與底色合成(得到不透明圖)"""
        if bg is not None:
            out = self.rgb * self.a[..., None] + np.array(bg, np.float32) * (1 - self.a[..., None])
            return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8), 'RGB')
        rgba = np.dstack([np.clip(self.rgb, 0, 255), np.clip(self.a, 0, 1) * 255]).astype(np.uint8)
        return Image.fromarray(rgba, 'RGBA')

# ---------------------------------------------------------------- 稜線
def ridge(W, seed, base, amp, rough=.12, peaks=(), freq=1.0, jag=1.0, tilt=0.0, env=None, smooth_peaks=True):
    """回傳每個 x 的稜線 y(越小越高)。peaks: (cx, halfwidth, height, power)"""
    x = np.arange(W, dtype=np.float32)
    f = fbm1(W, seed, scales=(.9 * freq, .45 * freq, .22 * freq, .11 * freq), amps=(1, .6, .32, .14))
    v = .5 + .5 * f
    j = fbm1(W, seed + 91, scales=(.30, .15, .075, .04), amps=(1, .7, .45, .25))
    h = amp * v + rough * amp * jag * j
    for (cx, hw, ht, pw) in peaks:
        d = np.abs((x - cx) / hw)
        tri = np.clip(1 - d, 0, 1) ** pw
        gau = np.exp(-(d * 1.35) ** 2)
        b = .55 * tri + .45 * gau if smooth_peaks else tri
        # 山頭不規則:左右不對稱 + 凹凸
        asym = 1 + .10 * np.tanh((x - cx) / (hw * .5)) * np.clip(1 - d, 0, 1)
        b = b * asym * (1 + .10 * jag * fbm1(W, seed + int(cx) % 97 + 7, scales=(.2, .1, .05), amps=(1, .6, .4)))
        h = np.maximum(h, ht * b + .12 * amp * v)
    if env is not None:
        h = h * env(x / W)
    y = base - h + tilt * (x - W / 2) / W
    return y.astype(np.float32)

def mountain(L, ytop, tone_top, tone_bot, seed, fade=260, soft=2.0, tex=.35, shade=.35, edge=.30,
             vstreak=(1.6, 14), fog_bottom=.0, alpha_max=1.0, crag=0.0, wash=.18, hlight=None, cun=0, stip=0, rough_edge=3.0, dark_tone=None):
    """畫一層山:ytop 為稜線陣列。tone_* 為 (r,g,b)。"""
    H, W = L.H, L.W
    yy = np.arange(H, dtype=np.float32)[:, None]
    d = yy - ytop[None, :]                       # 離稜線的距離(正 = 在山內)
    if rough_edge:
        d = d + rough_edge * noise2(H, W, seed + 77, 2.5, 2.5) + rough_edge * .8 * noise2(H, W, seed + 78, 9, 9)
    cov = np.clip(d / max(soft, .5) + .5, 0, 1)  # 邊緣柔化
    t = smooth(d / fade)
    tt = np.array(tone_top, np.float32); tb = np.array(tone_bot, np.float32)
    col = tt[None, None, :] * (1 - t[..., None]) + tb[None, None, :] * t[..., None]
    # 陰面:稜線向右下傾的坡面,墨色由稜線往下暈開
    slope = np.gradient(gaussian_filter1d(ytop, 6)) * 1.0
    sh = np.clip(slope / 2.2, 0, 1)
    sh = gaussian_filter1d(sh, 10)
    prof = np.exp(-np.clip(d, 0, None) / (fade * .55))
    dark = (shade * sh[None, :] * prof + edge * np.exp(-np.clip(d, 0, None) / (fade * .12))) * (d > -2)
    # 皴法:縱向筆觸 + 低頻墨暈
    n1 = noise2(H, W, seed + 1, 2.2, 46)
    fis = np.clip(n1 - 1.05, 0, 1.6)                      # 稀疏的縱向裂紋(只留正峰)
    n2 = noise2(H, W, seed + 2, 60, 34)                    # 大塊墨暈
    n3 = noise2(H, W, seed + 3, 2.2, 3.4)                  # 乾筆飛白
    n4 = noise2(H, W, seed + 4, 14, 9)
    tx = tex * (.9 * fis + .25 * n3 + .3 * n4) + wash * 1.6 * n2
    k = 1 - dark * .55
    col = col * k[..., None]
    col = col * (1 - tx[..., None] * .20)
    if crag:  # 前景山石:更強的縱向裂紋
        cr = noise2(H, W, seed + 5, .9, 9) * crag
        col = col * (1 - np.clip(cr, -1, 1)[..., None] * .22)
    if hlight is not None:   # 山頭被霧氣吞掉:上亮下暗
        hl = np.exp(-np.clip(d, 0, None) / hlight[0]) * hlight[1]
        col = col + (np.array(hlight[2], np.float32) - col) * hl[..., None] * (d > 0)[..., None]
    a = cov * (1 - fog_bottom * smooth(d / fade)) * alpha_max
    a = np.clip(a, 0, 1)
    if cun or stip:
        dt = np.array(dark_tone if dark_tone is not None else tone_bot, np.float32) * .55
        big = Image.new('L', (W, H), 0); dr = ImageDraw.Draw(big)
        R = np.random.RandomState(seed + 33)
        xs = np.arange(W)
        for _ in range(int(cun)):      # 斧劈皴:稜線下的短斜筆
            x = R.randint(0, W); yb = ytop[x]
            if sh[x] < .12 and R.rand() < .85: continue
            y = yb + R.uniform(2, fade * .45) ; ln = R.uniform(10, 38) * H / 760
            dr.line([(x, y), (x - ln * R.uniform(.1, .35), y + ln)], fill=int(R.uniform(60, 150)), width=int(R.choice([1, 1, 2])))
        for _ in range(int(stip)):     # 點苔:稜線附近的小墨點
            x = R.randint(0, W); y = ytop[x] + R.uniform(-2, fade * .3); rr = R.uniform(1.0, 2.8) * H / 760
            dr.ellipse([x - rr, y - rr * .8, x + rr, y + rr * .8], fill=int(R.uniform(90, 200)))
        m = np.asarray(big.filter(ImageFilter.GaussianBlur(.6)), np.float32) / 255
        m = m * (a > .5)
        col = col * (1 - m[..., None] * .55) + dt[None, None, :] * m[..., None] * .55
    L.over(np.clip(col, 0, 255), a)

def fog(L, yc, thick, strength, seed, haze, xr=(0, 1), stretch=.012, lump=.15):
    """橫向霧帶"""
    H, W = L.H, L.W
    yy = np.arange(H, dtype=np.float32)[:, None]
    xx = np.arange(W, dtype=np.float32)[None, :]
    m = fbm1(W, seed, scales=(.6, .3, .15), amps=(1, .6, .3))
    amp = np.clip(.55 + .6 * m, 0, 1.3)
    cy = yc + 14 * fbm1(W, seed + 5, scales=(.7, .3), amps=(1, .5))
    g = np.exp(-((yy - cy[None, :]) / (thick * (.6 + .5 * amp[None, :]))) ** 2)
    xm = smooth((xx / W - xr[0]) / .12) * smooth((xr[1] - xx / W) / .12)
    nz = noise2(H, W, seed + 9, 40, 6)
    g = g * amp[None, :] * xm * (1 + lump * nz)
    a = np.clip(g * strength, 0, .95).astype(np.float32)
    L.over(np.broadcast_to(np.array(haze, np.float32), (H, W, 3)), a)

# ---------------------------------------------------------------- 松樹(用高解析遮罩畫,再縮小)
def _blob(dr, cx, cy, w, h, r, fill, jag=.16):
    n = 30; ph = [r.uniform(0, 6.28) for _ in range(3)]; pts = []
    for i in range(n):
        ang = math.pi * 2 * i / n
        rad = 1 + .12 * math.sin(2 * ang + ph[0]) + .08 * math.sin(3 * ang + ph[1]) + jag * r.uniform(-1, 1) * (1 if i % 2 else .3)
        if math.sin(ang) > .15 and i % 2 == 0: rad *= 1 + r.uniform(.10, .38)   # 下垂的針尖
        pts.append((cx + math.cos(ang) * w * .5 * rad, cy + math.sin(ang) * h * .5 * rad))
    dr.polygon(pts, fill=fill)
    # 邊緣的針葉細毛
    for i in range(int(n * .6)):
        ang = r.uniform(0, 6.28); L = max(2.0, w * .09)
        x0 = cx + math.cos(ang) * w * .48; y0 = cy + math.sin(ang) * h * .48
        dr.line([(x0, y0), (x0 + math.cos(ang) * L * r.uniform(.6, 1.6), y0 + math.sin(ang) * L * 1.3 + L * .4)], fill=fill, width=max(1, int(w * .012)))

def _tuft(dr, cx, cy, w, h, r, fill):
    _blob(dr, cx, cy, w, h, r, fill)

def conifer(dr, x, yb, h, r, fill=255, sway=.04):
    """細高松:彎曲樹幹 + 層層下垂的針葉團"""
    top = yb - h; lean = r.uniform(-sway, sway) * h
    def trunk_x(t): return x + lean * (t ** 1.6) + math.sin(t * 5 + x) * h * .006
    pts = [(trunk_x(i / 24), yb - h * i / 24) for i in range(25)]
    wid = max(1.2, h * .018)
    for i in range(24):
        dr.line([pts[i], pts[i + 1]], fill=fill, width=max(1, int(wid * (1 - i / 30))))
    nb = 16
    for k in range(nb):
        t = .22 + .78 * k / nb
        tx, ty = trunk_x(t), yb - h * t
        side = 1 if k % 2 == 0 else -1
        blen = h * (.14 * (1.08 - t) + .03) * r.uniform(.75, 1.25)
        ex, ey = tx + side * blen, ty + blen * .22
        dr.line([(tx, ty), (ex, ey)], fill=fill, width=max(1, int(wid * .6)))
        for q in range(4):
            u = (q + .7) / 4
            _tuft(dr, tx + (ex - tx) * u, ty + (ey - ty) * u + blen * (.05 + .06 * u), blen * (.50 - .08 * q) * r.uniform(.85, 1.25), blen * .27 * r.uniform(.8, 1.2), r, fill)
    _tuft(dr, trunk_x(1), top + h * .02, h * .09, h * .08, r, fill)

def padpine(dr, x, yb, h, r, fill=255):
    """彎曲的松:幾片扁平的雲團樹冠"""
    pts = []; lean = r.uniform(-.25, .25) * h
    for i in range(30):
        t = i / 29
        pts.append((x + lean * math.sin(t * 2.1) + r.uniform(-.3, .3), yb - h * t))
    for i in range(29):
        dr.line([pts[i], pts[i + 1]], fill=fill, width=max(2, int(h * .03 * (1 - pts[i][1] / yb * 0 - i / 40))))
    for k in range(r.randint(3, 5)):
        t = .45 + .55 * k / 4 + r.uniform(-.05, .05)
        px, py = pts[min(29, int(t * 29))]
        w = h * r.uniform(.20, .32) * (1.1 - t * .45)
        side = r.choice([-1, 1])
        bx = px + side * w * .25
        dr.line([(px, py), (bx, py - h * .02)], fill=fill, width=max(1, int(h * .015)))
        for q in range(7):
            _tuft(dr, bx + r.uniform(-.55, .55) * w, py - h * .03 + r.uniform(-.035, .02) * h, w * r.uniform(.38, .62), w * r.uniform(.18, .26), r, fill)

def tiny_trees(mask_dr, xs, ys, hs, r):
    for x, y, h in zip(xs, ys, hs):
        # 遠景小松:鋸齒層疊的針葉,略彎的細幹
        lean = r.uniform(-.06, .06) * h
        mask_dr.line([(x, y), (x + lean, y - h)], fill=255, width=max(1, int(h * .05)))
        nt = 6
        for k in range(nt):
            t = .18 + .8 * k / nt
            yy = y - h * t; xx = x + lean * t
            ww = h * .20 * (1.05 - t * .85) * r.uniform(.8, 1.15)
            hh = h * .12
            pts = [(xx - ww, yy + hh * .6), (xx - ww * .5, yy + hh * .1), (xx - ww * .25, yy + hh * .3), (xx, yy - hh * .5), (xx + ww * .25, yy + hh * .3), (xx + ww * .5, yy + hh * .1), (xx + ww, yy + hh * .6)]
            mask_dr.polygon(pts, fill=255)

def trees_layer(L, kind_specs, seed, tone, scale=2, soft=.8, ridge_y=None):
    """在 L 上畫一批樹。kind_specs: [(kind, x, ybase, h)]"""
    W, H = L.W, L.H
    big = Image.new('L', (W * scale, H * scale), 0); dr = ImageDraw.Draw(big)
    r = np.random.RandomState(seed)
    rr = type('R', (), {})()
    class RR:
        def __init__(s, st): s.st = st
        def uniform(s, a, b): return s.st.uniform(a, b)
        def randint(s, a, b): return s.st.randint(a, b)
        def choice(s, l): return l[s.st.randint(0, len(l))]
    R = RR(r)
    for kind, x, yb, h in kind_specs:
        if kind == 'conifer': conifer(dr, x * scale, yb * scale, h * scale, R)
        elif kind == 'pad': padpine(dr, x * scale, yb * scale, h * scale, R)
    m = big.resize((W, H), Image.LANCZOS)
    m = m.filter(ImageFilter.GaussianBlur(soft))
    a = np.asarray(m, np.float32) / 255
    # 樹冠內的濃淡:邊緣略淡,中心濃
    n = noise2(H, W, seed + 11, 2.5, 2.5)
    col = np.broadcast_to(np.array(tone, np.float32), (H, W, 3)) * (1 - .10 * n[..., None])
    L.over(np.clip(col, 0, 255), np.clip(a * 1.0, 0, 1))

def ridge_trees(ytop, x0, x1, n, hmin, hmax, seed, kinds=('conifer',), pad=0):
    r = np.random.RandomState(seed); out = []
    for _ in range(n):
        x = r.uniform(x0, x1); xi = int(min(len(ytop) - 1, max(0, x)))
        out.append((kinds[r.randint(0, len(kinds))], x, float(ytop[xi]) + r.uniform(0, 5) + pad, r.uniform(hmin, hmax)))
    return out

def tiny_layer(L, specs, seed, tone, soft=.6):
    W, H = L.W, L.H
    big = Image.new('L', (W * 2, H * 2), 0); dr = ImageDraw.Draw(big)
    R = np.random.RandomState(seed)
    class RR:
        def uniform(s, a, b): return R.uniform(a, b)
    xs = [s[0] * 2 for s in specs]; ys = [s[1] * 2 for s in specs]; hs = [s[2] * 2 for s in specs]
    tiny_trees(dr, xs, ys, hs, RR())
    m = big.resize((W, H), Image.LANCZOS).filter(ImageFilter.GaussianBlur(soft))
    a = np.asarray(m, np.float32) / 255
    L.over(np.broadcast_to(np.array(tone, np.float32), (H, W, 3)).copy(), a)

def birds(L, pts, tone, seed):
    W, H = L.W, L.H
    big = Image.new('L', (W * 2, H * 2), 0); dr = ImageDraw.Draw(big)
    for (x, y, s) in pts:
        x *= 2; y *= 2; s *= 2
        dr.line([(x - s, y + s * .15), (x - s * .4, y - s * .35), (x, y)], fill=255, width=2)
        dr.line([(x, y), (x + s * .4, y - s * .35), (x + s, y + s * .15)], fill=255, width=2)
    m = big.resize((W, H), Image.LANCZOS).filter(ImageFilter.GaussianBlur(.5))
    a = np.asarray(m, np.float32) / 255 * .75
    L.over(np.broadcast_to(np.array(tone, np.float32), (H, W, 3)).copy(), a)

# ---------------------------------------------------------------- 場景定義
def paper_grain(img_arr, seed, amt):
    H, W = img_arr.shape[:2]
    n = noise2(H, W, seed, .8, .8)
    n2 = noise2(H, W, seed + 4, 14, 14)
    return img_arr + (n * 2.2 + n2 * 1.6)[..., None] * amt

def build_scene(pal, W, H, seed, cfg, split=False):
    """回傳 layers 列表 [far, mid, near] 的 Layer;split=False 時合成一張。"""
    P = PAL[pal]; T = P['tone']; haze = P['haze']
    far = Layer(W, H); mid = Layer(W, H); near = Layer(W, H)
    far.sky(P['sky_top'], P['sky_bot'], horizon=cfg.get('horizon', .62))
    s = seed
    R = np.random.RandomState(s)
    sc = H / 760.0   # 以 760 高度為基準的比例
    # --- 遠山 1、2(低對比、被霧吞沒)
    y1 = ridge(W, s + 1, H * cfg['b1'], H * cfg['a1'], rough=.10, peaks=cfg.get('p1', ()), freq=cfg.get('f1', 1.0), jag=.9)
    mountain(far, y1, T[0], P['sky_bot'], s + 10, fade=H * .32, soft=3.5, tex=.25, shade=.18, edge=.10, hlight=(H * .07, .55, haze), fog_bottom=.85, rough_edge=1.2)
    fog(far, H * (cfg['b1'] + .03), H * .05, .55, s + 20, haze)
    y2 = ridge(W, s + 2, H * cfg['b2'], H * cfg['a2'], rough=.12, peaks=cfg.get('p2', ()), freq=cfg.get('f2', 1.15), jag=1.0)
    mountain(far, y2, T[1], lerp(np.array(T[1]), np.array(haze), .55), s + 11, fade=H * .30, soft=2.6, tex=.35, shade=.28, edge=.16, hlight=(H * .06, .45, haze), fog_bottom=.75, rough_edge=1.8)
    tr = ridge_trees(y2, W * .05, W * .95, cfg.get('n_tiny2', 26), 9 * sc, 22 * sc, s + 31)
    tiny_layer(far, [(x, y, h) for _, x, y, h in tr], s + 32, lerp(np.array(T[1]), np.array(T[2]), .6))
    fog(far, H * (cfg['b2'] + .02), H * .06, .62, s + 21, haze)
    # --- 中景:主峰(高聳,上亮下暗)
    env = cfg.get('env')
    y3 = ridge(W, s + 3, H * cfg['b3'], H * cfg['a3'], rough=.20, peaks=cfg.get('p3', ()), freq=cfg.get('f3', 1.3), jag=1.5, env=env)
    mountain(mid, y3, lerp(np.array(T[3]), np.array(T[4]), .45), T[4], s + 12, fade=H * .50, soft=1.6, tex=.65, shade=.45, edge=.25, crag=.7,
             hlight=(H * .09, .50, haze), fog_bottom=.92, cun=2600 * H / 920, stip=900 * H / 920, dark_tone=T[4])
    tr = ridge_trees(y3, W * cfg.get('tx0', .04), W * cfg.get('tx1', .96), cfg.get('n_pine3', 16), cfg.get('t3', (16, 46))[0] * sc, cfg.get('t3', (16, 46))[1] * sc, s + 33, kinds=('conifer',))
    trees_layer(mid, tr, s + 34, T[3], soft=.7)
    fog(mid, H * (cfg['b3'] + cfg.get('fy3', .05)), H * .06, .78, s + 22, haze)
    if 'p4' in cfg or 'a4' in cfg:
        y4 = ridge(W, s + 4, H * cfg['b4'], H * cfg['a4'], rough=.22, peaks=cfg.get('p4', ()), freq=cfg.get('f4', 1.5), jag=1.6, env=env)
        mountain(mid, y4, T[4], T[4], s + 13, fade=H * .36, soft=1.4, tex=.7, shade=.4, edge=.25, crag=.9, hlight=(H * .06, .30, haze), fog_bottom=.55, cun=1400 * H / 920, stip=500 * H / 920, dark_tone=T[4])
        tr = ridge_trees(y4, W * .02, W * .98, cfg.get('n_pine4', 12), cfg.get('t4', (24, 60))[0] * sc, cfg.get('t4', (24, 60))[1] * sc, s + 35)
        trees_layer(mid, tr, s + 36, T[4], soft=.7)
        fog(mid, H * (cfg['b4'] + .06), H * .05, .5, s + 23, haze)
    # --- 近景:左右兩側的山石與松
    for side, spec in cfg.get('fg', {}).items():
        x0, x1 = spec['x']
        Wd = int((x1 - x0) * W)
        yr = ridge(W, s + 50 + ord(side[0]) % 13, H * spec['base'], H * spec['amp'], rough=.22, peaks=spec.get('peaks', ()), freq=1.7, jag=1.2)
        mask = np.zeros(W, np.float32); xx = np.arange(W)
        edge_in = smooth(((xx / W) - x0) / max(.001, spec.get('ramp', .08)))
        edge_out = smooth((x1 - (xx / W)) / max(.001, spec.get('ramp', .08)))
        vis = np.minimum(edge_in, edge_out)
        yr = yr + (1 - vis) * H * .7        # 兩端沉入畫面外
        mountain(near, yr, T[4] if pal == 'light' else T[4], T[4], s + 14, fade=H * .35, soft=1.2, tex=.7, shade=.3, edge=.3, crag=1.0, cun=900 * H / 920, stip=0, dark_tone=T[4])
        tr = ridge_trees(yr, x0 * W + Wd * .05, x1 * W - Wd * .05, spec.get('n', 5), spec.get('hmin', 120) * sc, spec.get('hmax', 260) * sc, s + 60 + ord(side[0]) % 11, kinds=spec.get('kinds', ('conifer', 'pad')))
        trees_layer(near, tr, s + 61, T[4], soft=.9)
    if cfg.get('birds'):
        birds(far, [(R.uniform(.3, .7) * W, R.uniform(.12, .28) * H, R.uniform(6, 11) * sc) for _ in range(cfg['birds'])], T[3], s + 70)
    fog(near, H * cfg.get('nearfog', .94), H * .05, .55, s + 24, haze)
    return far, mid, near

def finish(layers, pal, seed, grain=True):
    """合成為不透明圖"""
    P = PAL[pal]
    base = Layer(layers[0].W, layers[0].H)
    for l in layers: base.over(l.rgb, l.a)
    img = base.rgb
    if grain: img = paper_grain(img, seed + 900, P['grain'])
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), 'RGB')

def vignette_edges(img, pal, amt=.0):
    return img

# ---------------------------------------------------------------- 設定:hero 與 8 張場景
def hero_cfg():
    W = 2000
    return dict(horizon=.58, b1=.52, a1=.34, f1=.9, p1=[(W * .36, W * .24, 340, 1.2), (W * .90, W * .12, 260, 1.2)], n_tiny2=40,
                b2=.66, a2=.36, f2=1.0, p2=[(W * .74, W * .17, 390, 1.3), (W * .14, W * .14, 240, 1.3)],
                b3=.90, a3=.56, f3=1.1, p3=[(W * .68, W * .17, 600, 1.15), (W * .84, W * .10, 450, 1.2), (W * .54, W * .09, 330, 1.3)],
                env=lambda u: .20 + .80 * np.clip((u - .10) / .42, 0, 1) ** 1.3,
                tx0=.5, tx1=.95, n_pine3=30, t3=(26, 62), fy3=.05,
                b4=1.0, a4=.20, p4=[(W * .93, W * .11, 170, 1.3), (W * .40, W * .10, 120, 1.3)], n_pine4=18, t4=(40, 86), f4=1.4,
                fg=dict(L=dict(x=(-.03, .22), base=1.04, amp=.30, peaks=[(W * .04, W * .085, 430, 1.2)], n=3, hmin=330, hmax=520, ramp=.05, kinds=('conifer', 'pad')),
                        R=dict(x=(.76, 1.03), base=1.04, amp=.30, peaks=[(W * .955, W * .10, 440, 1.2)], n=4, hmin=260, hmax=470, ramp=.06, kinds=('conifer', 'pad'))),
                birds=7, nearfog=.97)

def scene_cfgs():
    W = 1280
    cs = []
    # 8 種構圖:峰位、松的位置、霧的高度各不相同
    base = dict(horizon=.60, tx0=.04, tx1=.96)
    cs.append(dict(base, b1=.52, a1=.30, p1=[(W * .3, W * .2, 250, 1.2)], b2=.66, a2=.30, p2=[(W * .7, W * .16, 280, 1.3)], b3=.86, a3=.44, p3=[(W * .62, W * .18, 400, 1.15)], n_pine3=10, b4=1.0, a4=.16, p4=[(W * .9, W * .12, 140, 1.3)], n_pine4=7,
                   fg=dict(L=dict(x=(-.02, .26), base=1.02, amp=.16, peaks=[(W * .05, W * .08, 200, 1.2)], n=3, hmin=150, hmax=250)), birds=4))
    cs.append(dict(base, b1=.5, a1=.34, p1=[(W * .7, W * .2, 280, 1.2)], b2=.64, a2=.32, p2=[(W * .25, W * .15, 250, 1.3)], b3=.88, a3=.46, p3=[(W * .32, W * .17, 420, 1.15), (W * .5, W * .1, 300, 1.2)], n_pine3=9, b4=1.0, a4=.18, p4=[(W * .12, W * .12, 160, 1.3)], n_pine4=6,
                   fg=dict(R=dict(x=(.66, 1.02), base=1.02, amp=.17, peaks=[(W * .95, W * .1, 220, 1.2)], n=3, hmin=150, hmax=270)), birds=3))
    cs.append(dict(base, b1=.55, a1=.28, p1=[(W * .5, W * .22, 230, 1.2)], b2=.70, a2=.30, p2=[(W * .2, W * .15, 260, 1.3), (W * .8, W * .14, 240, 1.3)], b3=.9, a3=.40, p3=[(W * .5, W * .2, 380, 1.1)], n_pine3=8, b4=1.0, a4=.14, n_pine4=6,
                   fg=dict(L=dict(x=(-.02, .2), base=1.02, amp=.15, peaks=[(W * .04, W * .08, 190, 1.2)], n=2, hmin=140, hmax=230), R=dict(x=(.8, 1.02), base=1.02, amp=.15, peaks=[(W * .96, W * .08, 190, 1.2)], n=2, hmin=140, hmax=230)), birds=0))
    cs.append(dict(base, b1=.50, a1=.36, p1=[(W * .8, W * .22, 300, 1.2)], b2=.65, a2=.34, p2=[(W * .4, W * .17, 300, 1.3)], b3=.86, a3=.48, p3=[(W * .22, W * .15, 430, 1.15), (W * .78, W * .1, 300, 1.2)], n_pine3=11, b4=1.0, a4=.16, p4=[(W * .6, W * .1, 130, 1.3)], n_pine4=6,
                   fg=dict(), birds=5))
    cs.append(dict(base, b1=.54, a1=.30, p1=[(W * .25, W * .2, 240, 1.2)], b2=.68, a2=.30, p2=[(W * .62, W * .16, 280, 1.3)], b3=.88, a3=.42, p3=[(W * .8, W * .15, 390, 1.15)], n_pine3=9, b4=1.0, a4=.18, p4=[(W * .2, W * .11, 150, 1.3)], n_pine4=8,
                   fg=dict(L=dict(x=(-.02, .3), base=1.02, amp=.16, peaks=[(W * .08, W * .1, 210, 1.2)], n=4, hmin=140, hmax=260)), birds=2))
    cs.append(dict(base, b1=.50, a1=.32, p1=[(W * .55, W * .2, 270, 1.2)], b2=.64, a2=.34, p2=[(W * .85, W * .13, 260, 1.3), (W * .15, W * .12, 230, 1.3)], b3=.86, a3=.44, p3=[(W * .4, W * .17, 410, 1.15)], n_pine3=10, b4=1.0, a4=.15, n_pine4=6,
                   fg=dict(R=dict(x=(.7, 1.02), base=1.02, amp=.17, peaks=[(W * .92, W * .1, 230, 1.2)], n=4, hmin=150, hmax=270)), birds=3))
    cs.append(dict(base, b1=.56, a1=.26, p1=[(W * .7, W * .2, 220, 1.2)], b2=.70, a2=.28, p2=[(W * .3, W * .16, 250, 1.3)], b3=.90, a3=.38, p3=[(W * .55, W * .16, 350, 1.15)], n_pine3=7, b4=1.0, a4=.14, n_pine4=5,
                   fg=dict(L=dict(x=(-.02, .22), base=1.02, amp=.14, peaks=[(W * .05, W * .07, 180, 1.2)], n=3, hmin=130, hmax=220)), birds=4))
    cs.append(dict(base, b1=.50, a1=.34, p1=[(W * .4, W * .22, 290, 1.2)], b2=.64, a2=.34, p2=[(W * .78, W * .15, 290, 1.3)], b3=.86, a3=.46, p3=[(W * .15, W * .14, 400, 1.15), (W * .62, W * .12, 330, 1.2)], n_pine3=10, b4=1.0, a4=.17, p4=[(W * .85, W * .1, 150, 1.3)], n_pine4=7,
                   fg=dict(R=dict(x=(.72, 1.02), base=1.02, amp=.16, peaks=[(W * .93, W * .09, 200, 1.2)], n=3, hmin=140, hmax=250)), birds=3))
    return cs

def main(which='all'):
    os.makedirs(OUT, exist_ok=True)
    if which in ('all', 'hero'):
        for pal in ('light', 'dark'):
            W, H = 2000, 920
            far, mid, near = build_scene(pal, W, H, 7, hero_cfg())
            # 分層輸出(視差):遠層不透明、中近層帶透明
            P = PAL[pal]
            finish([far], pal, 7).save(f'{OUT}/hero-{pal}-0.webp', quality=80, method=6)
            mid.image().save(f'{OUT}/hero-{pal}-1.webp', quality=80, method=6)
            near.image().save(f'{OUT}/hero-{pal}-2.webp', quality=82, method=6)
            finish([far, mid, near], pal, 7).save(f'{OUT}/hero-{pal}-flat.jpg', quality=88)
            print('hero', pal)
    if which in ('all', 'scenes'):
        for i, cfg in enumerate(scene_cfgs()):
            for pal in ('light', 'dark'):
                W, H = 1280, 800
                lay = build_scene(pal, W, H, 100 + i * 17, cfg)
                finish(list(lay), pal, 100 + i).save(f'{OUT}/s{i}-{pal}.webp', quality=74, method=6)
            print('scene', i)

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'all')
