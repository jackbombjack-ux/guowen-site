網站原始碼(產生器)。修改內容或前端後,在這個資料夾放好 images/ 與原型 HTML 後執行:
GW_PROD=1 python3 build_site.py
(完整建置環境在原專案資料夾;一般情況只需要改 docs/config.js 與用老師後台管理內容。)
