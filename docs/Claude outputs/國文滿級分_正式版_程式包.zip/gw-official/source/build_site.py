# -*- coding: utf-8 -*-
"""國文滿級分 多頁網站產生器 -> site/"""
import json, html, os, re, shutil
from content import *

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
PROD = os.environ.get('GW_PROD') == '1'
OUT = os.environ.get('GW_OUT', 'repo/docs' if PROD else 'site')
E = lambda s: html.escape(str(s), quote=True)
ORIG = '/root/.claude/uploads/ce5e1614-8ec9-591c-b6d2-0acf51a89bd7/7bb92225-___.html'
L = open(ORIG, encoding='utf-8').read().split('\n')

SITE = BRAND
NAV = [('materials', '自學教材'), ('courses', '線上課程'), ('live', '直播專區'), ('membership', '付費會員'), ('essay', '作文批改'),
       ('resources', '免費資源'), ('about', '關於我們'), ('contact', '聯繫我們')]
IG = 'https://www.instagram.com/chinese.win/'
TH = 'https://www.threads.com/@chinese.win'
FONTS = 'https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;500;700&family=Noto+Serif+TC:wght@400;600;700;900&family=LXGW+WenKai+TC:wght@400;700&display=swap'

for p in PRODUCTS:
    p['url'] = 'product-%s.html' % p['id']
for c in COURSES:
    c['url'] = 'course-%s.html' % c['id']
    c['learn'] = 'learn-%s.html' % c['id']
PBY = {p['id']: p for p in PRODUCTS}
CBY = {c['id']: c for c in COURSES}

# ------------------------------------------------------------------ 共用片段
def svgdefs():
    defs = '\n'.join(L[391:432])
    extra = '''    <symbol id="i-pen" viewBox="0 0 24 24"><path d="M4 20l1-4L16.5 4.5a2 2 0 0 1 3 0l0 0a2 2 0 0 1 0 3L8 19l-4 1ZM14.5 6.5l3 3"/></symbol>
    <symbol id="i-live" viewBox="0 0 24 24"><circle cx="12" cy="12" r="2.2"/><path d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 7.8a6 6 0 0 1 0 8.4M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/></symbol>
    <symbol id="i-lock" viewBox="0 0 24 24"><rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/></symbol>
    <symbol id="i-upload" viewBox="0 0 24 24"><path d="M12 16V5M7 9l5-5 5 5M5 20h14"/></symbol>
    <symbol id="i-link" viewBox="0 0 24 24"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></symbol>
'''
    extra += '''    <filter id="dry" x="-2%" y="-2%" width="104%" height="104%" color-interpolation-filters="sRGB"><feTurbulence type="fractalNoise" baseFrequency="0.85 0.3" numOctaves="2" seed="8" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -2.4 2.05" result="m"/><feComposite in="SourceGraphic" in2="m" operator="in"/></filter>
    <radialGradient id="fogG" cx="50%" cy="50%" r="50%"><stop offset="0" style="stop-color:var(--mist)" stop-opacity="1"/><stop offset=".55" style="stop-color:var(--mist)" stop-opacity=".55"/><stop offset="1" style="stop-color:var(--mist)" stop-opacity="0"/></radialGradient>
    <radialGradient id="vigG" cx="50%" cy="50%" r="75%"><stop offset=".55" style="stop-color:var(--vig)" stop-opacity="0"/><stop offset="1" style="stop-color:var(--vig)" stop-opacity="1"/></radialGradient>
    <filter id="sealRough" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="5" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="2.2" xChannelSelector="R" yChannelSelector="G"/></filter>
'''
    return defs.replace('  </defs>', extra + '  </defs>')

SVGDEFS = svgdefs()

def ico(i, st=''):
    return '<svg class="ico"%s><use href="#%s"/></svg>' % (' style="%s"' % st if st else '', i)

def logo_html(cls='logo'):
    return ('<a class="%s" href="index.html" aria-label="%s 首頁">'
            '<img class="emb on-light" src="images/emblem-light.png" alt="" width="87" height="48">'
            '<img class="emb on-dark" src="images/emblem-dark.png" alt="" width="87" height="48">'
            '<img class="wm on-light" src="images/wordmark-light.png" alt="" width="173" height="36">'
            '<img class="wm on-dark" src="images/wordmark-dark.png" alt="" width="173" height="36"></a>') % (cls, SITE)

def header(active):
    nav = ''.join('<a href="%s.html"%s>%s</a>' % (k, ' aria-current="page"' if k == active else '', v) for k, v in NAV)
    dr = '<a href="index.html">首頁</a>' + ''.join('<a href="%s.html">%s</a>' % (k, v) for k, v in NAV) + '<a href="faq.html">常見問題</a><a href="member.html">會員專區</a>'
    return f'''<header class="site-header" id="siteHeader">
  <div class="wrap bar">
    {logo_html()}
    <nav class="nav" aria-label="主選單">{nav}</nav>
    <div class="tools">
      <a class="ibtn" id="cartBtn" href="cart.html" aria-label="購物車">{ico('i-cart')}<span class="badge" id="cartBadge">0</span></a>
      <button class="ibtn" id="userBtn" type="button" aria-label="會員登入">{ico('i-user')}</button>
      <button class="ibtn" id="searchBtn" type="button" aria-label="搜尋">{ico('i-search')}</button>
      <span class="sep"></span>
      <div class="socials">
        <a class="soc ig" href="{IG}" target="_blank" rel="noopener" aria-label="Instagram"><svg><use href="#i-ig"/></svg></a>
        <a class="soc th" href="{TH}" target="_blank" rel="noopener" aria-label="Threads"><svg><use href="#i-th"/></svg></a>
        <a class="soc ln" href="contact.html" data-ext="lineUrl" aria-label="LINE"><svg><use href="#i-ln"/></svg></a>
        <a class="soc yt" href="live.html" data-ext="youtubeUrl" aria-label="YouTube"><svg><use href="#i-yt"/></svg></a>
      </div>
      <button class="ibtn" id="themeBtn" type="button" aria-label="切換深色模式">{ico('i-moon').replace('<use ', '<use id="themeUse" ')}</button>
      <button class="ibtn hamb" id="hambBtn" type="button" aria-label="開啟選單" aria-expanded="false" aria-controls="mnav">{ico('i-menu')}</button>
    </div>
  </div>
  <nav class="drawer-nav" id="mnav" aria-label="手機選單">{dr}</nav>
</header>'''

def footer():
    fn = ''.join('<a href="%s">%s</a>' % (u, t) for u, t in [
        ('about.html', '關於我們'), ('materials.html', '自學教材'), ('courses.html', '線上課程'), ('live.html', '直播專區'), ('membership.html', '付費會員'),
        ('essay.html', '作文批改'), ('resources.html', '免費資源'), ('faq.html', '常見問題'), ('contact.html', '聯繫我們'), ('member.html', '會員專區')])
    return f'''<footer class="footer">
  <div class="wrap">
    <div class="f-in">
      <div>
        <a href="index.html" aria-label="{SITE} 首頁"><img class="f-logo" src="images/logo-dark.png" alt="{SITE} {BRAND_EN}" width="210" height="144"></a>
        <p class="f-tag">{TAGLINE}</p>
      </div>
      <nav class="f-nav" aria-label="頁尾選單">{fn}</nav>
      <div class="socials">
        <a class="soc ig" href="{IG}" target="_blank" rel="noopener" aria-label="Instagram"><svg><use href="#i-ig"/></svg></a>
        <a class="soc th" href="{TH}" target="_blank" rel="noopener" aria-label="Threads"><svg><use href="#i-th"/></svg></a>
        <a class="soc ln" href="contact.html" data-ext="lineUrl" aria-label="LINE"><svg><use href="#i-ln"/></svg></a>
        <a class="soc yt" href="live.html" data-ext="youtubeUrl" aria-label="YouTube"><svg><use href="#i-yt"/></svg></a>
      </div>
    </div>
    <div class="f-bot">
      <span>© 2026 {SITE} All Rights Reserved.</span>
      <nav aria-label="法律文件與管理"><a href="privacy.html">隱私權政策</a><a href="terms.html">服務條款</a><a class="adm" href="admin.html">老師後台</a></nav>
    </div>
  </div>
</footer>'''

DIALOGS = f'''<dialog id="modal" aria-labelledby="mTitle"><div class="modal-box"><button class="x" type="button" data-close aria-label="關閉">{ico('i-x')}</button><div id="mBody"></div></div></dialog>
<dialog id="searchDlg" aria-label="搜尋"><div class="modal-box">
  <button class="x" type="button" data-close aria-label="關閉搜尋">{ico('i-x')}</button>
  <div class="sinput" style="margin-right:40px">{ico('i-search')}<input id="sInput" type="text" enterkeyhint="search" placeholder="搜尋教材、課程、資源…" autocomplete="off" aria-label="搜尋關鍵字"></div>
  <div class="sres" id="sRes"></div>
  <p class="hint">試試輸入「古文」、「屠龍」或「學測」。</p>
</div></dialog>
<div class="toast" id="toast" role="status" aria-live="polite"></div>'''

def sopt(**k):
    return E(json.dumps(k, separators=(',', ':')))

def phero(crumb, h1, sub, seed, **opt):
    o = dict(amp=.6, lift=16)
    o.update(opt)
    return f'''<section class="phero" aria-label="頁首">
  <div class="art" data-scene="{seed}" data-sopt="{sopt(**o)}" aria-hidden="true"></div>
  <div class="wrap phero-in">
    <nav class="crumb" aria-label="導覽路徑"><a href="index.html">首頁</a>{crumb}</nav>
    <h1>{h1}</h1>
    {'<p>%s</p>' % sub if sub else ''}
  </div>
</section>'''

def crumb(*items):
    out = ''
    for t, u in items:
        out += '<i>/</i>' + ('<a href="%s">%s</a>' % (u, t) if u else '<span aria-current="page">%s</span>' % t)
    return out

def sechead(title, sub='', more=None):
    m = '<a class="more" href="%s">%s %s</a>' % (more[0], more[1], ico('i-arrow', 'width:15px;height:15px')) if more else ''
    return '<div class="sec-head"><div><h2>%s</h2>%s</div>%s</div>' % (title, '<p class="sub">%s</p>' % sub if sub else '', m)

def band(title, text, btns):
    return f'<div class="wrap"><section class="band" aria-label="{E(title)}"><div><h2>{title}</h2><p>{text}</p></div><div class="mact" style="margin:0">{btns}</div></section></div>'

def pcard(p, i):
    return f'''<article class="pcard" id="card-{p['id']}">
  <div class="pcover" data-scene="{40+i}" data-sopt="{sopt(amp=.5, lift=36)}"><a class="cvlink" href="{p['url']}" tabindex="-1" aria-hidden="true"><img class="cv" src="images/{p['cover']}" alt="" width="176" height="249" loading="lazy"></a></div>
  <div class="pbody"><div class="pmeta">{E(p['meta'])}</div><h3><a href="{p['url']}">{E(p['name'])}</a></h3><p>{E(p['desc'])}</p>
    <div class="prow"><span class="price">NT$<span data-price="{p['id']}">{p['price']}</span><small class="est" data-est>暫定</small></span>
      <div class="pact"><a class="btn btn-line sm" href="{p['url']}">查看詳情</a><button type="button" class="cartbtn" data-add="{p['id']}" aria-label="加入購物車:{E(p['name'])}">{ico('i-cart', 'width:18px;height:18px')}</button></div></div></div>
</article>'''

def ccard(c, i):
    return f'''<article class="course" id="card-{c['id']}">
  <a class="c-art" href="{c['url']}" data-scene="{70+i}" data-sopt="{sopt(amp=.7, lift=4)}" aria-label="{E(c['name'])}"><img src="images/{c['art']}" alt="" loading="lazy"></a>
  <div class="c-body"><span class="cbadge">籌備中</span><h3><a href="{c['url']}">{E(c['name'])}</a></h3><p>{E(c['desc'])}</p>
    <div class="c-meta"><span>{len(c['chaps'])} 個章節</span><span>預錄影片</span><span>YouTube 平台</span></div>
    <a class="btn btn-fill" href="{c['url']}">課程資訊 {ico('i-arrow')}</a></div>
</article>'''

def rcard(r, i):
    if r['gate']:
        btn = f'<button type="button" class="btn btn-gold" data-res="{r["id"]}" data-gate="1">加入會員領取 {ico("i-gift")}</button>'
        tag = f'<i id="tag-{r["id"]}">會員限定</i>'
    else:
        btn = f'<button type="button" class="btn btn-gold" data-res="{r["id"]}" data-gate="0" data-href="{r["href"]}">前往閱讀 {ico("i-link")}</button>'
        tag = '<i>公開</i>'
    return f'''<article class="rcard" id="card-{r['id']}"><div class="r-thumb" data-thumb="{60+i}:{r['kind']}">{tag}</div><div class="r-body"><h3>{E(r['name'])}</h3><p>{E(r['desc'])}</p>{btn}</div></article>'''

def stats_html():
    return '<div class="stats" id="stats">' + ''.join('<div class="stat"><b data-n="%d" data-u="%s">%d<small style="font-size:14px;font-weight:500;margin-left:2px">%s</small></b><span>%s</span></div>' % (n, u, n, u, t) for n, u, t in STATS) + '</div>'

def faq_html(items):
    return '<div class="faq">' + ''.join('<details><summary>%s</summary><p>%s</p></details>' % (E(q), E(a)) for q, a in items) + '</div>'

def steps(items):
    return '<div class="steps">' + ''.join('<div class="step"><div class="no">%s</div><h3>%s</h3><p>%s</p></div>' % (n, t, d) for n, t, d in items) + '</div>'

LIVE_STEPS = [('壹', '加入付費會員', '選擇月繳或年繳,在綠界付款頁完成付款。'), ('貳', '自動開通', '付款成功後系統自動把你的帳號升級為付費會員。'), ('參', '開播時進入', '登入後到直播專區,按「進入會員直播」即可收看。')]
ESSAY_STEPS = [('壹', '登入並拍照上傳', '使用 Google 帳號登入,把手寫作文逐頁拍清楚後上傳。'), ('貳', '老師批改', '老師依學測國寫評分角度,逐篇給予修改與評語。'), ('參', '查看批改結果', '批改完成後,在會員專區查看評語與建議。')]

# ------------------------------------------------------------------ 頁面外殼
PAGES = {}   # file -> dict(title, desc, body, active, extra_head, noindex)

def prodify(h):
    if not PROD:
        return h
    for a, b in [
        ('<small class="est" data-est>暫定</small>', ''),
        ('<small data-est>價格暫定</small>', ''),
        ('<p class="pnote" data-est>教材價格為暫定,確認後會更新。</p>', ''),
        ('<p class="pnote" data-est>方案價格與續約規則確認後會公布於此。</p>', ''),
        ('<p class="mfoot">預覽版:按下報名後以示範帳號登入並進入學習環境,不會真的扣款或連線。</p>', ''),
        ('(金流串接後啟用)', ''),
        ('<p class="pnote">資源領取為預覽版示範,正式上線後會提供下載。</p>', ''),
        ('<p class="pnote">課程目前為籌備中,上線時間確認後會公告於此。</p>', ''),
        ('<p class="mfoot">留言表單於正式上線後啟用,目前請先使用 LINE 聯繫。</p>', ''),
        ('<span class="tag" style="margin-left:10px;vertical-align:middle">版面預覽・示範資料</span>', ''),
        ('老師後台(預覽版)', '老師後台'),
        (' data-est data-planprice=', ' data-planprice='),
        ('<div class="err" id="cErr" role="alert"></div>', '<input id="cHp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0"><div class="err" id="cErr" role="alert"></div>'),
    ]:
        h = h.replace(a, b)
    return h

def add_page(file, title, desc, body, active=None, ld=None, noindex=False, full_title=None, og='images/og.jpg'):
    PAGES[file] = dict(title=full_title or '%s｜%s' % (title, SITE), desc=desc, body=body, active=active, ld=ld, noindex=noindex, og=og)

def render(file, pg):
    ld = ''.join('<script type="application/ld+json">%s</script>\n' % json.dumps(x, ensure_ascii=False, separators=(',', ':')) for x in (pg['ld'] or []))
    robots = '<meta name="robots" content="noindex,nofollow">\n' if pg['noindex'] else ''
    SB_TAG = '<script src="vendor/supabase.js"></script>\n' if PROD else ''
    return prodify(f'''<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#F6F0E4" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0E131B" media="(prefers-color-scheme: dark)">
<title>{E(pg['title'])}</title>
<meta name="description" content="{E(pg['desc'])}">
{robots}<meta property="og:type" content="website">
<meta property="og:locale" content="zh_TW">
<meta property="og:site_name" content="{SITE}">
<meta property="og:title" content="{E(pg['title'])}">
<meta property="og:description" content="{E(pg['desc'])}">
<meta property="og:image" content="{pg['og']}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="images/favicon.png" type="image/png">
<link rel="apple-touch-icon" href="images/icon-192.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{FONTS}">
<link rel="stylesheet" href="styles.css">
{ld}</head>
<body data-page="{file[:-5]}">
<a class="skip" href="#main">跳到主要內容</a>
{SVGDEFS}
{header(pg['active'])}
<main id="main">
{pg['body']}
</main>
{footer()}
{DIALOGS}
{SB_TAG}<script src="config.js"></script>
<script src="data.js"></script>
<script src="app.js"></script>
</body>
</html>
''')

def fragment(file, pg):
    """Artifact 用:首頁以片段發佈(平台會補上外殼)"""
    full = render(file, pg)
    body = re.search(r'<body[^>]*>(.*)</body>', full, re.S).group(1)
    return '<title>%s</title>\n<link rel="stylesheet" href="%s">\n<link rel="stylesheet" href="styles.css">\n%s' % (E(pg['title']), FONTS, body)

# ================================================================== 首頁
HERO_CH = '讓國文，成為一種力量。'
def hero_h1():
    lines = ['讓國文，', '成為一種力量。']
    i = 0
    out = ''
    for ln in lines:
        out += '<span class="ln" aria-hidden="true">'
        for ch in ln:
            out += '<span class="ch" style="--i:%d">%s</span>' % (i, ch)
            i += 1
        out += '</span>'
    return '<h1 aria-label="讓國文，成為一種力量。">%s</h1>' % out

def home_body():
    plist = ''.join(pcard(p, i) for i, p in enumerate(PRODUCTS))
    clist = ''.join(ccard(c, i) for i, c in enumerate(COURSES))
    rlist = ''.join(rcard(r, i) for i, r in enumerate(RESOURCES))
    quick = [('materials', 'i-book', '自學教材', '會考、學測作文與國文攻略'), ('courses', 'i-cap', '線上課程', '系統化學習,掌握考試關鍵'),
             ('essay', 'i-pen', '作文批改', '拍照上傳,老師親自批改'), ('live', 'i-live', '直播專區', '付費會員專屬直播')]
    q = ''.join('<a class="qcard" href="%s.html" style="--q:%d">%s<h3>%s</h3><p>%s</p><span class="go">%s</span></a>' % (k, i, ico(ic), t, d, ico('i-arrow', 'width:16px;height:16px')) for i, (k, ic, t, d) in enumerate(quick))
    return f'''<section class="hero play" id="home" aria-label="品牌主視覺">
  <div class="hero-art" id="heroArt" aria-hidden="true"></div>
  <div class="hero-fade" aria-hidden="true"></div>
  <div class="wrap hero-in">
    <div>
      <p class="hero-tag">{TAGLINE}</p>
      {hero_h1()}
      <p class="sub">閱讀・思考・表達・累積一生受用的語文能力</p>
      <div class="cta">
        <a class="btn btn-fill" href="materials.html">探索教材 {ico('i-arrow')}</a>
        <a class="btn btn-line" href="resources.html">免費領取學習資源 {ico('i-arrow')}</a>
      </div>
    </div>
    <div class="quick">{q}</div>
  </div>
  <button class="replay" id="replayBtn" type="button">{ico('i-replay')}重播開場動畫</button>
  <div class="seal-stamp" aria-hidden="true">滿</div>
</section>

<section class="section">
  <div class="wrap">
    {sechead('自學教材', '由滿級分團隊自編,歷屆試題、範文與寫作技巧一書掌握', ('materials.html', '查看全部教材'))}
    <div class="pgrid">{plist}</div>
    <p class="pnote" data-est>教材價格為暫定,確認後會更新。</p>
  </div>
</section>

<section class="section">
  <div class="wrap">
    {sechead('線上課程', '預先錄製的影片課程,報名後進入學習環境,依章節自己的步調學習', ('courses.html', '查看全部課程'))}
    <div class="courses">{clist}</div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="story">
      <div>
        <img class="logo-big on-light" src="images/logo-light.png" alt="{SITE} {BRAND_EN} 標誌" width="460" height="315" loading="lazy">
        <img class="logo-big on-dark" src="images/logo-dark.png" alt="" width="460" height="315" loading="lazy">
      </div>
      <div>
        <h2 class="brandline">{TAGLINE}</h2>
        <p>{SITE}({BRAND_EN}),專注學測國文與國寫,以自編教材與課程,陪伴學生建立能長久使用的語文能力。</p>
        {stats_html()}
        <p style="margin-top:18px"><a class="btn btn-fill" href="about.html">認識我們 {ico('i-arrow')}</a></p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap duo">
    <article class="tcard scene-r" data-scene="81" data-sopt="{sopt(amp=.8, sun=True, sunx=520, suny=90)}">
      <h3>直播專區</h3>
      <p>公開直播免費觀看;會員限定直播只開放給付費會員,付款後自動開通。</p>
      <a class="btn btn-fill" href="live.html">了解直播 {ico('i-arrow')}</a>
    </article>
    <article class="tcard scene-r" data-scene="82" data-sopt="{sopt(amp=.9, glow=[470,110,80], pines=True)}">
      <h3>作文批改</h3>
      <p>寫在稿紙上,拍照上傳即可。老師逐篇批改,結果在會員專區查看。</p>
      <a class="btn btn-fill" href="essay.html">了解作文批改 {ico('i-arrow')}</a>
    </article>
  </div>
</section>

<section class="section">
  <div class="wrap">
    {sechead('免費資源', '加入會員即可領取試讀與目錄;學習貼文可直接追蹤', ('resources.html', '查看全部資源'))}
    <div class="res">{rlist}</div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    {sechead('常見問題', '', ('faq.html', '更多問題'))}
    {faq_html(FAQ[:4])}
  </div>
</section>

{band('先從免費資源開始', '加入會員,領取學測國寫全攻略試讀與教材完整目錄。', '<button type="button" class="btn btn-gold" data-login>使用 Google 帳號加入</button><a class="btn btn-line" style="color:var(--dark-text);border-color:var(--dark-line)" href="contact.html">聯繫我們</a>')}
'''

add_page('index.html', '', '國文滿級分專業工作室(Perfect Score Chinese Studio)專為國高中生打造的國文學習品牌:學測國文與國寫教材、歷屆試題解析、線上課程、付費會員直播與作文批改。',
         home_body(), active=None, full_title='%s｜專為國高中生打造的國文學習品牌' % SITE,
         ld=[{"@context": "https://schema.org", "@type": "EducationalOrganization", "name": SITE, "alternateName": BRAND_EN, "description": TAGLINE + ',專注會考與學測國文、作文的教材、線上課程與作文批改。', "areaServed": "TW", "logo": "images/logo-light.png", "sameAs": [IG, TH]}])

# ================================================================== 教材
def materials_body():
    def grp(lv):
        return ''.join(pcard(p, PRODUCTS.index(p)) for p in PRODUCTS if p['lvl'] == lv)
    return f'''{phero(crumb(('自學教材', None)), '自學教材', '由滿級分團隊自編。歷屆試題解析、範文精讀、寫作方法與核心古文,一本一本把國文讀成自己的能力。', 5)}
<div class="pg"><div class="wrap">
  <p class="lead-p">目前共有 {len(PRODUCTS)} 本教材,每一本都附完整目錄,選書前可以先看內容。</p>
  <div class="section first" style="padding-top:20px">
  {sechead('高中', '學測國文、國寫與古文')}<div class="pgrid">{grp('高中')}</div>
  <div style="margin-top:40px">{sechead('國中', '會考作文:功法篇與素材篇')}<div class="pgrid">{grp('國中')}</div></div>
  <p class="pnote" data-est>教材價格為暫定,確認後會更新。</p></div>
  <div class="sets" style="margin-top:44px">
    {sechead('國寫雙書組', '屠龍寶刀講方法,倚天神劍給素材,兩本搭配使用')}
    <div class="gal"><figure><img src="images/set-zuowen.jpg" alt="屠龍寶刀與倚天神劍國寫雙書組" width="1000" height="802" loading="lazy"><figcaption>《高中國寫之屠龍寶刀》與《高中國寫之倚天神劍》</figcaption></figure></div>
  </div>
  <div class="sets" style="margin-top:44px">
    {sechead('國中雙書組', '功法篇教方法,素材篇給素材,兩本搭配使用')}
    <div class="gal"><figure><img src="images/poster-jh.jpg" alt="國中作文高分秘笈功法篇與素材篇雙書組" width="1200" height="873" loading="lazy"><figcaption>《國中作文高分秘笈・功法篇》與《國中作文高分秘笈・素材篇》</figcaption></figure></div>
  </div>
</div></div>
{band('不確定從哪一本開始?', '先加入會員領取教材完整目錄與學測國寫全攻略試讀,再決定也不遲。', '<a class="btn btn-gold" href="resources.html">前往免費資源</a><a class="btn btn-line" style="color:var(--dark-text);border-color:var(--dark-line)" href="contact.html">詢問老師</a>')}
'''
add_page('materials.html', '自學教材', '國文滿級分自編教材:高中國寫之屠龍寶刀、倚天神劍、國文學霸筆記、學測國寫全攻略,以及國中作文高分秘笈功法篇與素材篇,附完整目錄。', materials_body(), active='materials')

def product_body(p):
    i = PRODUCTS.index(p)
    feats = '<ul class="ticks">' + ''.join('<li>%s</li>' % E(f) for f in p['feats']) + '</ul>'
    two = ''
    if p.get('who'):
        two = '<div class="twocol"><div class="box"><h3>適用對象</h3><ul class="ticks">%s</ul></div><div class="box"><h3>使用方式</h3><ul class="ticks">%s</ul></div></div>' % (
            ''.join('<li>%s</li>' % E(x) for x in p['who']), ''.join('<li>%s</li>' % E(x) for x in p['how']))
    toc = '<ul class="toc">' + ''.join(('<li class="grp">%s</li>' % E(a)) if not b else ('<li><span>%s</span><i>%s</i></li>' % (E(a), E(b))) for a, b in p['toc']) + '</ul>'
    gal = ''.join('<figure><img src="images/%s" alt="%s" loading="lazy"><figcaption>%s</figcaption></figure>' % (f, E(c), E(c)) for f, c in p['extra'])
    rel = sorted([q for q in PRODUCTS if q is not p], key=lambda q: q['lvl'] != p['lvl'])[:4]
    relh = ''.join(pcard(q, PRODUCTS.index(q)) for q in rel)
    return f'''{phero(crumb(('自學教材', 'materials.html'), (p['name'], None)), E(p['title']), E(p['desc']), 10 + i, amp=.5)}
<div class="pg"><div class="wrap">
  <div class="pd">
    <div class="pd-cover" data-scene="{40+i}" data-sopt="{sopt(amp=.5, lift=30)}"><img class="cv" src="images/{p['cover']}" alt="{E(p['title'])} 封面" width="340" height="481"></div>
    <div class="pd-info">
      <div class="pd-meta">{E(p['meta'])}</div>
      <p class="pd-tag">{E(p['tag'])}</p>
      <div class="pd-price">NT$<span data-price="{p['id']}">{p['price']}</span><small data-est>價格暫定</small></div>
      <div class="pd-actions">
        <button type="button" class="btn btn-fill" data-add="{p['id']}">加入購物車</button>
        <button type="button" class="btn btn-line" data-add="{p['id']}" data-go="cart.html">立即購買</button>
      </div>
      <p class="mfoot">結帳由綠界科技的付款頁面處理,支援信用卡、超商繳費等方式(金流串接後啟用)。</p>
      <h2 class="sub">內容簡介</h2>
      <p style="color:var(--text-soft)">{E(p['intro'])}</p>
      <h2 class="sub">本書特色</h2>
      {feats}
      {two}
      <h2 class="sub">內容目錄</h2>
      {toc}
      {'<h2 class="sub">內頁與介紹</h2><div class="gal">%s</div>' % gal if gal else ''}
    </div>
  </div>
  <div class="rel">{sechead('其他教材', '', ('materials.html', '全部教材'))}<div class="pgrid">{relh}</div></div>
</div></div>
'''
for p in PRODUCTS:
    add_page(p['url'], p['name'], '%s。%s' % (p['title'], p['desc']), product_body(p), active='materials', og='images/' + p['cover'])

# ================================================================== 課程
def courses_body():
    clist = ''.join(ccard(c, i) for i, c in enumerate(COURSES))
    flow = steps([('壹', '登入並報名', '使用 Google 帳號登入,按「報名課程」。'), ('貳', '進入學習環境', '左側播放影片,右側選擇章節與字幕。'), ('參', '依自己的步調學習', '系統會記錄你學到哪一章,下次接著上。')])
    return f'''{phero(crumb(('線上課程', None)), '線上課程', '預先錄製的影片課程。報名後進入學習環境,依章節用自己的步調學習。', 6, sun=True, sunx=500, suny=84)}
<div class="pg"><div class="wrap">
  <div class="courses" style="margin-top:6px">{clist}</div>
  <div class="section">{sechead('上課方式', '影片在 YouTube 平台播放,章節暫依教材目錄規劃,正式內容確認後公告')}{flow}</div>
  <p class="pnote">課程目前為籌備中,上線時間確認後會公告於此。</p>
</div></div>
{band('想搭配教材一起學?', '課程與教材搭配使用,效果最好。', '<a class="btn btn-gold" href="materials.html">看看教材</a>')}
'''
add_page('courses.html', '線上課程', '國文滿級分線上課程:學測國寫衝刺班、十五核心古文總複習。預錄影片,依章節自己的步調學習。', courses_body(), active='courses')

def course_body(c):
    i = COURSES.index(c)
    b = PBY[c['book']]
    tags = ''.join('<span>#%s</span>' % E(t) for t in c['tags'])
    chl = '<ol class="chlist">' + ''.join('<li>%s</li>' % E(t) for t in c['chaps']) + '</ol>'
    flow = steps([('壹', '登入並報名', '使用 Google 帳號登入,按「報名課程」。'), ('貳', '進入學習環境', '左側播放影片,右側選擇章節與字幕。'), ('參', '依自己的步調學習', '系統會記錄你學到哪一章,下次接著上。')])
    return f'''{phero(crumb(('線上課程', 'courses.html'), (c['name'], None)), E(c['name']), E(c['desc']), 20 + i, sun=True, sunx=520, suny=84)}
<div class="pg"><div class="wrap">
  <div class="pd">
    <div class="cd-art" data-scene="{70+i}" data-sopt="{sopt(amp=.7, lift=4)}"><img src="images/{c['art']}" alt="{E(c['name'])}" loading="lazy"></div>
    <div class="pd-info">
      <span class="cbadge">籌備中</span>
      <p class="pd-tag">{E(c['intro'])}</p>
      <div class="tagrow">{tags}</div>
      <dl class="cinfo">
        <div><dt>章節數</dt><dd>{len(c['chaps'])} 個章節</dd></div>
        <div><dt>授課形式</dt><dd>預錄影片</dd></div>
        <div><dt>播放平台</dt><dd>YouTube</dd></div>
        <div><dt>適合對象</dt><dd>{E(c['who'])}</dd></div>
        <div class="wide"><dt>搭配教材</dt><dd><a href="{b['url']}" style="text-decoration:underline;text-underline-offset:3px">{E(b['title'])}</a></dd></div>
      </dl>
      <div class="pd-actions">
        <button type="button" class="btn btn-fill" id="enrollBtn" data-course="{c['id']}">報名課程</button>
        <button type="button" class="btn btn-line" id="shareBtn">{ico('i-link')}複製課程連結</button>
      </div>
      <p class="mfoot">預覽版:按下報名後以示範帳號登入並進入學習環境,不會真的扣款或連線。</p>
      <h2 class="sub">課程章節</h2>
      {chl}
    </div>
  </div>
  <div class="section" style="margin-top:20px">{sechead('如何上課')}{flow}</div>
</div></div>
'''
for c in COURSES:
    add_page(c['url'], c['name'], c['desc'], course_body(c), active='courses', og='images/' + c['art'] if c['art'].startswith('cover') else 'images/og.jpg')

def learn_body(c):
    return f'''{phero(crumb(('線上課程', 'courses.html'), (c['name'], c['url']), ('學習環境', None)), '學習環境', E(c['name']), 30, amp=.5)}
<div class="pg"><div class="wrap"><div id="learnApp" data-course="{c['id']}"></div></div></div>
'''
for c in COURSES:
    add_page(c['learn'], '學習環境:' + c['name'], '%s 學習環境。' % c['name'], learn_body(c), active='courses', noindex=True)

# ================================================================== 直播
def live_body():
    return f'''{phero(crumb(('直播專區', None)), '直播專區', '公開直播免費觀看。會員限定直播只開放給付費會員。', 7, sun=True, sunx=500, suny=80)}
<div class="pg"><div class="wrap">
  <div class="live" style="margin-top:6px">
    <article class="lcard">
      <div class="l-art" data-scene="91" data-sopt="{sopt(amp=.8, sun=True, sunx=500, suny=80)}" aria-hidden="true"><span class="lab">{ico('i-live')}公開直播</span></div>
      <div class="l-body"><h3>公開直播</h3><p>免費開放給所有人觀看,包含考試說明、學習方法分享與精選問答。</p>
        <button class="btn btn-fill" type="button" data-ext="youtubeUrl">前往 YouTube 頻道 {ico('i-arrow')}</button>
        <p class="note">開播時間以 YouTube 頻道公告為準。</p></div>
    </article>
    <article class="lcard">
      <div class="l-art locked" data-scene="92" data-sopt="{sopt(amp=.9, glow=[470,110,80], pines=True)}" aria-hidden="true"><span class="lab">{ico('i-lock')}會員限定</span></div>
      <div class="l-body" id="liveMember"><h3>會員限定直播</h3><p>只開放給付費會員。尚未加入的人看不到直播連結。</p>
        <a class="btn btn-gold" href="membership.html">了解付費會員 {ico('i-arrow')}</a>
        <p class="note">在本網站付款,付款成功後自動開通。</p></div>
    </article>
  </div>
  <div class="section">{sechead('如何收看會員直播')}{steps(LIVE_STEPS)}</div>
  <div class="section">{sechead('直播常見問題')}{faq_html([FAQ[1], FAQ[2]])}</div>
</div></div>
'''
add_page('live.html', '直播專區', '國文滿級分直播專區:公開直播免費觀看,會員限定直播只開放給付費會員,在網站付款後自動開通。', live_body(), active='live')

# ================================================================== 付費會員
def membership_body():
    def plan(pid, name, sub, pts, btn):
        return (f'<article class="plan" id="plan-{pid}"><h3>{name}</h3><p class="pl-sub">{sub}</p>'
                f'<div class="pp">NT$ <b data-est data-planprice="{pid}">價格待確認</b></div>'
                f'<ul class="ticks">' + ''.join('<li>%s</li>' % t for t in pts) + '</ul>'
                f'<button type="button" class="btn btn-fill" data-plan="{pid}">{btn}</button></article>')
    plans = plan('monthly', '月繳', '每月付款,彈性加入', ['觀看會員限定直播', '付款成功,系統自動開通', '每月自動續約,可隨時取消'], '加入月繳會員') + \
            plan('yearly', '年繳', '一次付一年,省去每月扣款', ['觀看會員限定直播', '付款成功,系統自動開通', '到期前提醒續約'], '加入年繳會員')
    flow = steps([('壹', '選擇方案', '登入後選月繳或年繳。'), ('貳', '綠界付款', '轉到綠界科技的付款頁,可用信用卡等方式。'), ('參', '自動開通', '付款成功後立即成為付費會員,到直播專區收看。')])
    return f'''{phero(crumb(('付費會員', None)), '付費會員', '在網站用綠界付款,付完自動成為會員,觀看會員限定直播。', 13, sun=True, sunx=520, suny=88)}
<div class="pg"><div class="wrap">
  <div id="memStatus"></div>
  <div class="plans">{plans}</div>
  <p class="pnote" data-est>方案價格與續約規則確認後會公布於此。</p>
  <div class="section">{sechead('開通流程')}{flow}</div>
  <div class="section">{sechead('常見問題')}{faq_html([FAQ[1], FAQ[2], FAQ[5]])}</div>
</div></div>
'''
add_page('membership.html', '付費會員', '加入國文滿級分付費會員:在網站用綠界付款,付款成功自動開通,觀看會員限定直播。月繳與年繳方案。', membership_body(), active='membership')

# ================================================================== 作文批改
def essay_body():
    return f'''{phero(crumb(('作文批改', None)), '作文批改', '寫在稿紙上,拍照上傳即可,不需要另外繕打。老師逐篇批改,評語在會員專區查看。', 8, sun=True, sunx=520, suny=90)}
<div class="pg"><div class="wrap">
  <div class="essay" style="margin-top:6px">
    <div>{steps(ESSAY_STEPS).replace('class="steps"', 'class="steps" style="margin-top:0"')}
      <div class="twocol" style="grid-template-columns:1fr;margin-top:16px"><div class="box"><h3>拍照小提醒</h3><ul class="ticks"><li>光線充足,避免反光與陰影</li><li>整頁入鏡,四邊都拍到</li><li>依頁碼順序上傳</li><li>每次最多 6 張,每張 10 MB 以內</li></ul></div></div>
    </div>
    <div><div class="upanel" id="uPanel"></div><div class="panel" style="margin-top:16px"><h2>我的上傳紀錄</h2><ul class="mlist" id="myEssays"></ul></div></div>
  </div>
  <div class="section">{sechead('作文批改常見問題')}{faq_html([FAQ[3], FAQ[4]])}</div>
</div></div>
'''
add_page('essay.html', '作文批改', '國文滿級分作文批改:手寫稿紙拍照上傳,老師逐篇批改,評語在會員專區查看。', essay_body(), active='essay')

# ================================================================== 免費資源
def resources_body():
    rlist = ''.join(rcard(r, i) for i, r in enumerate(RESOURCES))
    return f'''{phero(crumb(('免費資源', None)), '免費資源', '加入會員即可領取試讀與目錄;Instagram 與 Threads 的學習貼文可直接追蹤閱讀。', 9)}
<div class="pg"><div class="wrap">
  <div class="res" style="margin-top:6px">{rlist}</div>
  <p class="pnote">資源領取為預覽版示範,正式上線後會提供下載。</p>
</div></div>
{band('想要更完整的內容?', '自編教材與線上課程,幫你把國文一步步練穩。', '<a class="btn btn-gold" href="materials.html">看看教材</a><a class="btn btn-line" style="color:var(--dark-text);border-color:var(--dark-line)" href="courses.html">線上課程</a>')}
'''
add_page('resources.html', '免費資源', '國文滿級分免費資源:學測國寫全攻略試讀、教材完整目錄、Instagram 學習貼文與 Threads 國文短講。', resources_body(), active='resources')

# ================================================================== 關於
def about_body():
    return f'''{phero(crumb(('關於我們', None)), '關於我們', TAGLINE, 12)}
<div class="pg"><div class="wrap">
  <div class="story" style="margin-top:6px">
    <div>
      <img class="logo-big on-light" src="images/logo-light.png" alt="{SITE} {BRAND_EN} 標誌" width="460" height="315">
      <img class="logo-big on-dark" src="images/logo-dark.png" alt="" width="460" height="315">
    </div>
    <div>
      <h2 class="brandline">讓國文,成為一種力量。</h2>
      <p>{SITE}({BRAND_EN}),是專為國高中生打造的國文學習品牌。我們專注會考與學測的國文、作文,以自編教材與課程,陪伴學生建立能長久使用的語文能力。</p>
      <p>金色的毛筆、書卷與祥雲,是品牌的標誌;朱紅的「滿」字印,是我們對每一位學生的期待。</p>
    </div>
  </div>
  <div class="section">{sechead('我們提供什麼')}
    <div class="trio">
      <article class="tcard"><h3>自編教材</h3><p>歷屆試題解析、範文精讀、寫作方法與核心古文,由滿級分團隊自編。</p><a class="btn btn-line" href="materials.html">看教材</a></article>
      <article class="tcard"><h3>線上課程與直播</h3><p>預錄影片課程搭配 YouTube 直播,會員限定場次只開放給付費會員。</p><a class="btn btn-line" href="courses.html">看課程</a></article>
      <article class="tcard"><h3>作文批改</h3><p>拍照上傳手寫作文,老師依學測國寫評分角度逐篇批改。</p><a class="btn btn-line" href="essay.html">作文批改</a></article>
    </div>
  </div>
  <div class="section">{sechead('教材特色')}
    <div class="twocol"><div class="box"><ul class="ticks"><li>歷屆學測國寫試題完整解析</li><li>審題、立意與作答方向逐題拆解</li></ul></div><div class="box"><ul class="ticks"><li>大考中心公布範文打字整理、逐篇賞析</li><li>寫法拆解,一書掌握</li></ul></div></div>
    <div style="margin-top:24px">{stats_html()}</div>
  </div>
  <div class="section">{sechead('品牌標誌', '淺色與深色版本,依背景自動切換')}
    <div class="brandbox"><div class="bb l"><img src="images/logo-light.png" alt="標誌淺色版" width="380" height="260" loading="lazy"></div><div class="bb d"><img src="images/logo-dark.png" alt="標誌深色版" width="380" height="260" loading="lazy"></div></div>
  </div>
  <div class="section">{sechead('追蹤我們')}
    <div class="mact" style="margin-top:0"><a class="btn btn-line" href="{IG}" target="_blank" rel="noopener">Instagram @chinese.win</a><a class="btn btn-line" href="{TH}" target="_blank" rel="noopener">Threads @chinese.win</a></div>
  </div>
</div></div>
{band('有問題想問?', '作文批改、課程與教材諮詢,都可以直接留言。', '<a class="btn btn-gold" href="contact.html">聯繫我們</a>')}
'''
add_page('about.html', '關於我們', '國文滿級分專業工作室(Perfect Score Chinese Studio):專為國高中生打造的國文學習品牌,專注會考與學測的國文、作文。', about_body(), active='about')

# ================================================================== FAQ / 聯絡
add_page('faq.html', '常見問題', '會員、直播、作文批改、付款與課程的常見問題。', f'''{phero(crumb(('常見問題', None)), '常見問題', '會員、直播、作文批改、付款與課程。找不到答案,歡迎直接問我們。', 14)}
<div class="pg"><div class="wrap">{faq_html(FAQ)}</div></div>
{band('還有其他問題?', '直接留言或加入 LINE,最快收到回覆。', '<a class="btn btn-gold" href="contact.html">聯繫我們</a>')}
''', active=None, ld=[{"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in FAQ]}])

add_page('contact.html', '聯繫我們', '作文批改、課程與教材諮詢,可透過 LINE、Instagram、Threads 或留言表單聯繫國文滿級分專業工作室。', f'''{phero(crumb(('聯繫我們', None)), '聯繫我們', '作文批改、課程與教材諮詢,都可以直接留言。也歡迎先加入 LINE 官方帳號,最快收到回覆。', 15)}
<div class="pg"><div class="wrap">
  <div class="contact-cards">
    <article class="ccard"><h3>LINE 官方帳號</h3><p>最快收到回覆,教材與課程諮詢首選。</p><button class="btn btn-line-green" type="button" data-ext="lineUrl">{ico('i-ln', 'fill:currentColor;stroke:none')}加入 LINE</button></article>
    <article class="ccard"><h3>Instagram</h3><p>國文學習重點與考前提醒。</p><a class="btn btn-line" href="{IG}" target="_blank" rel="noopener">@chinese.win</a></article>
    <article class="ccard"><h3>Threads</h3><p>閱讀、寫作與文學的短篇分享。</p><a class="btn btn-line" href="{TH}" target="_blank" rel="noopener">@chinese.win</a></article>
  </div>
  <div class="contact">
    <div><h2>留言給我們</h2><p class="lead">請簡單描述需求或目前年級,我們會盡快回覆。</p><p class="mfoot">留言表單於正式上線後啟用,目前請先使用 LINE 聯繫。</p></div>
    <form class="fm" id="contactForm" novalidate>
      <label class="fld" for="cName">姓名<input id="cName" autocomplete="name" placeholder="王小明"></label>
      <label class="fld" for="cMail">Email<input id="cMail" type="email" autocomplete="email" placeholder="you@example.com"></label>
      <label class="fld" for="cTopic">想詢問的項目<select id="cTopic"><option>自學教材</option><option>線上課程</option><option>作文批改</option><option>直播與會員</option><option>其他</option></select></label>
      <label class="fld" for="cMsg">留言<textarea id="cMsg" placeholder="請簡單描述需求或目前年級"></textarea></label>
      <div class="err" id="cErr" role="alert"></div>
      <button class="btn btn-fill" type="submit" style="align-self:flex-start">送出留言</button>
    </form>
  </div>
</div></div>
''', active='contact')

# ================================================================== 購物車 / 會員 / 後台
add_page('cart.html', '購物車', '檢視購物車並前往付款。', f'''{phero(crumb(('購物車', None)), '購物車', '確認教材與數量,再前往付款。', 16, amp=.5)}
<div class="pg"><div class="wrap"><div id="cartApp"></div></div></div>
''', noindex=True)
add_page('member.html', '會員專區', '查看我的課程、作文批改與資源。', f'''{phero(crumb(('會員專區', None)), '會員專區', '我的課程、作文批改與資源。', 17, amp=.5)}
<div class="pg"><div class="wrap"><div id="memberApp"></div></div></div>
''', noindex=True)
add_page('admin.html', '老師後台', '老師後台(預覽版)。', f'''{phero(crumb(('老師後台', None)), '老師後台<span class="tag" style="margin-left:10px;vertical-align:middle">版面預覽・示範資料</span>', '批改作文、管理會員、教材與課程。', 18, amp=.5)}
<div class="pg"><div class="wrap"><div id="adminApp"></div></div></div>
''', noindex=True)

# ================================================================== 法律
LEGAL_NOTE = '<p class="legal-note">本文件為網站上線前的草案,正式內容將由工作室確認後更新。最後更新:2026 年 10 月。</p>'
add_page('privacy.html', '隱私權政策', '國文滿級分專業工作室隱私權政策(草案)。', f'''{phero(crumb(('隱私權政策', None)), '隱私權政策', '', 19, amp=.4)}
<div class="pg"><div class="wrap legal">
<h2>我們蒐集哪些資料</h2><p>使用 Google 帳號登入時,我們會取得你的姓名與 Email。上傳作文批改時,會儲存你上傳的作文照片、題目與年級。我們不會取得你的 Google 密碼。</p>
<h2>如何使用這些資料</h2><p>資料只用於提供會員服務:顯示你的課程與資源、讓老師批改作文並回覆評語,以及回覆你的詢問。上傳的作文僅供本人與老師查看。</p>
<h2>作文自動辨識</h2><p>為了把手寫作文轉成文字,你上傳的作文照片可能會傳送到 Google Cloud Vision 進行文字辨識,僅用於轉出文字,不用於其他用途。每月額度用完時,改在你的瀏覽器內辨識,照片不會傳給第三方辨識服務。辨識結果可能有誤字,老師會視情況校正,仍以照片為準。</p>
<h2>第三方服務</h2><p>網站會使用 Google(登入)、YouTube(影片與直播)、綠界科技(付款)等第三方服務。這些服務各有其隱私權政策,請參閱其官方說明。</p>
<h2>資料保存與刪除</h2><p>你可以隨時來信或透過 LINE 要求查詢、更正或刪除你的資料。</p>
<h2>聯絡方式</h2><p>如有任何疑問,請透過<a href="contact.html" style="text-decoration:underline">聯繫我們</a>頁面與工作室聯繫。</p>
{LEGAL_NOTE}
</div></div>
''', active=None)
add_page('terms.html', '服務條款', '國文滿級分專業工作室服務條款(草案)。', f'''{phero(crumb(('服務條款', None)), '服務條款', '', 19, amp=.4)}
<div class="pg"><div class="wrap legal">
<h2>服務內容</h2><p>本網站提供自編教材、線上課程、作文批改與免費學習資源。各項服務的內容與價格以網站公告為準。</p>
<h2>著作權</h2><p>網站上的教材、課程影片、圖文與標誌,著作權屬國文滿級分專業工作室所有。未經許可,請勿重製、轉售或公開散布。</p>
<h2>會員與帳號</h2><p>會員以 Google 帳號登入。請妥善保管你的帳號,並勿與他人共用課程與會員權益。</p>
<h2>付款與退換</h2><p>付款由綠界科技的付款頁面處理。退換貨與退費方式將於正式上線前公告。</p>
<h2>條款修改</h2><p>工作室可能視需要修改本條款,修改後會公告於本頁。</p>
{LEGAL_NOTE}
</div></div>
''', active=None)

# ================================================================== 資料檔 data.js / config.js
def index_entries():
    ix = []
    for p in PRODUCTS:
        ix.append(dict(kind='教材', name=p['name'], desc=p['desc'], text=p['title'] + ' ' + ' '.join(a for a, b in p['toc']) + ' ' + ' '.join(p['feats']), url=p['url']))
    for c in COURSES:
        ix.append(dict(kind='課程', name=c['name'], desc=c['desc'], text=' '.join(c['chaps']) + ' ' + ' '.join(c['tags']), url=c['url']))
    for r in RESOURCES:
        ix.append(dict(kind='資源', name=r['name'], desc=r['desc'], text='', url='resources.html'))
    for n, d, u in [('直播專區', '公開直播與付費會員限定直播', 'live.html'), ('付費會員', '月繳與年繳方案,付款後自動開通,觀看會員限定直播', 'membership.html'), ('作文批改', '拍照上傳手寫作文,老師逐篇批改', 'essay.html'),
                    ('關於我們', TAGLINE, 'about.html'), ('聯繫我們', 'LINE、Instagram、Threads 與留言', 'contact.html'), ('常見問題', '會員、直播、作文、付款', 'faq.html')]:
        ix.append(dict(kind='頁面', name=n, desc=d, text='', url=u))
    return ix

CONFIG_JS = '''/* ===== 站台設定:上線前請在這裡填入 =====
 * gaId            Google Analytics 4 代碼,例如 G-XXXXXXXXXX
 * lineUrl         LINE 官方帳號加好友連結
 * youtubeUrl      YouTube 頻道網址
 * liveMemberUrl  會員限定直播的連結(只有付費會員看得到;開播前由老師更換)
 * priceConfirmed  教材價格確認後改為 true(會隱藏「暫定」字樣)
 */
window.GW = window.GW || {};
window.GW.config = {
  gaId: '',
  lineUrl: '',
  youtubeUrl: '',
  liveMemberUrl: '',
  priceConfirmed: false
};
'''

CONFIG_JS_PROD = '''/* ===== 站台設定:上線前請在這裡填入(都是可以公開的值) =====
 * supabaseUrl       Supabase 專案網址,例如 https://abcdxyz.supabase.co
 * supabaseAnonKey   Supabase 的 anon public key(可公開,權限由資料庫規則控管)
 * gaId              Google Analytics 4 代碼,例如 G-XXXXXXXXXX(可留空)
 * LINE 與 YouTube 連結不用寫在這裡,老師可在後台「設定」自行修改
 * 注意:絕對不要把 service_role 金鑰或綠界的 HashKey / HashIV 放在這裡。
 */
window.GW = window.GW || {};
window.GW.config = {
  supabaseUrl: 'https://tnzzsxftjekxevkzhadc.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRuenpzeGZ0amVreGV2a3poYWRjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI2NDgyNDcsImV4cCI6MjEwODIyNDI0N30.wP8VcLKhM5H-u79M51Ii9R8TnInaJcjyLEQK7zQM46E',
  gaId: '',
  lineUrl: '',
  youtubeUrl: ''
};
'''

def data_js():
    prods = [dict(id=p['id'], name=p['name'], title=p['title'], price=p['price'], cover=p['cover'], url=p['url']) for p in PRODUCTS]
    cs = [dict(id=c['id'], name=c['name'], url=c['url'], learn=c['learn'], chaps=c['chaps']) for c in COURSES]
    rs = [dict(id=r['id'], name=r['name'], gate=r['gate']) for r in RESOURCES]
    return '/* 教材、課程、資源與搜尋索引資料 */\nwindow.GW = window.GW || {};\nObject.assign(window.GW, %s);\n' % json.dumps(dict(products=prods, courses=cs, resources=rs, index=index_entries()), ensure_ascii=False, separators=(',', ':'))

# ================================================================== 輸出
def build_css():
    css = '\n'.join(L[11:388])
    css += '\n' + open('add.css', encoding='utf-8').read()
    css += '\n' + open('css_pages.css', encoding='utf-8').read()
    css += '\n' + open('css_ink2.css', encoding='utf-8').read()
    css += '\n' + open('css_ink4.css', encoding='utf-8').read()
    if PROD:
        css += '\n' + open('css_live.css', encoding='utf-8').read()
    css += '''
/* 多頁補充 */
.hero-tag{font-family:var(--font-serif);font-weight:600;font-size:clamp(14px,1.6vw,17px);letter-spacing:.3em;color:var(--bronze-text);margin-bottom:14px}
.sit{display:flex;gap:12px;align-items:center;text-align:left;padding:10px;border-radius:10px}
.sit:hover,.sit:focus-visible{background:var(--paper-2)}
.sit em{font-style:normal;font-size:11px;letter-spacing:.12em;padding:2px 8px;border-radius:999px;background:var(--paper-2);color:var(--bronze-text);flex-shrink:0}
.sit b{font-family:var(--font-serif);font-size:15.5px;display:block}
.sit small{color:var(--text-soft);font-size:13px}
.pcover .cvlink{position:relative;z-index:1;display:grid;place-items:center}
@media (max-width:1500px){.tools .socials,.tools .sep{display:none}}
.nav a{white-space:nowrap}
.plans{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;max-width:880px;margin-top:6px}
.plan{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:26px 26px 24px;box-shadow:var(--shadow-sm);display:flex;flex-direction:column;gap:10px}
.plan h3{font-family:var(--font-serif);font-weight:900;font-size:22px;letter-spacing:.08em}
.plan .pl-sub{color:var(--text-soft);font-size:14px}
.plan .pp{font-size:15px;color:var(--bronze-text);font-weight:700}
.plan .pp b{font-size:22px;font-weight:700}
.plan .btn{margin-top:auto;align-self:flex-start}
.plan.cur{border-color:var(--bronze-b);box-shadow:0 0 0 2px var(--bronze-b) inset}
.memstat{display:flex;gap:14px 20px;flex-wrap:wrap;align-items:center;justify-content:space-between;background:var(--card);border:1px solid var(--bronze-b);border-radius:14px;padding:18px 22px;margin-bottom:20px}
.memstat b{font-family:var(--font-serif);font-size:19px;letter-spacing:.06em}
.memstat span{display:block;font-size:13.5px;color:var(--text-soft)}
@media (max-width:700px){.plans{grid-template-columns:1fr}}
.more{white-space:nowrap}
#tThumbs{grid-template-columns:repeat(6,minmax(0,1fr))}
@media (max-width:560px){#tThumbs{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:560px){
  .logo{gap:6px}
  .logo .emb{height:34px}
  .logo .wm{height:23px}
  .sec-head{flex-wrap:wrap;gap:6px 16px}
    .c-art{padding:18px 0}
  .c-art img{width:min(64%,240px)}
}
@media (max-width:440px){#userBtn{display:none}}
.twocol{margin-top:18px}
.footer .socials{display:flex}
.crumb span[aria-current]{color:var(--text)}
.footer .f-logo{display:block}
.f-bot nav a{color:var(--dark-soft);text-decoration:underline;text-underline-offset:3px}
.f-bot nav a:hover{color:var(--dark-text)}
.story .logo-big{display:block}
.story img.logo-big.on-dark{display:none}
.band .mact{flex-wrap:wrap}
.lnote{padding:12px 18px}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) .story img.logo-big.on-light{display:none}:root:not([data-theme="light"]) .story img.logo-big.on-dark{display:block}}
:root[data-theme="dark"] .story img.logo-big.on-light{display:none}
:root[data-theme="dark"] .story img.logo-big.on-dark{display:block}
'''
    return css

def build_js():
    js = open('app_core.js', encoding='utf-8').read()
    ink = '\n'.join(L[632:703])
    if PROD:
        live = open('live_b.js', encoding='utf-8').read()
        js = re.sub(r'/\*@@DEMO1_BEGIN@@\*/.*?/\*@@DEMO1_END@@\*/', lambda m: live, js, flags=re.S)
        js = re.sub(r'/\*@@DEMO2_BEGIN@@\*/.*?/\*@@DEMO2_END@@\*/', '', js, flags=re.S)
        js = js.replace('/*@@PROD@@*/false', 'true')
    # 移除原型中已不需要的 SVG 全域 var 衝突:helpers 內容為純函式與 INK_N
    ink += '\n' + open('ink2.js', encoding='utf-8').read() + '\n' + open('ink3.js', encoding='utf-8').read() + '\n' + open('ink4.js', encoding='utf-8').read()
    js = js.replace('/*@@FX@@*/', open('fx.js', encoding='utf-8').read())
    return js.replace('/*@@INK@@*/', ink)

def main():
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT):
        if f.endswith('.html'):
            os.remove(os.path.join(OUT, f))
    for f, pg in PAGES.items():
        open(os.path.join(OUT, f), 'w', encoding='utf-8').write(render(f, pg))
    open(os.path.join(OUT, 'styles.css'), 'w', encoding='utf-8').write(build_css())
    open(os.path.join(OUT, 'app.js'), 'w', encoding='utf-8').write(build_js())
    open(os.path.join(OUT, 'data.js'), 'w', encoding='utf-8').write(data_js())
    open(os.path.join(OUT, 'config.js'), 'w', encoding='utf-8').write(CONFIG_JS_PROD if PROD else CONFIG_JS)
    os.makedirs(os.path.join(OUT, 'images', 'ink'), exist_ok=True)
    if os.path.isdir('ink_out'):
        for f in os.listdir('ink_out'):
            if f.endswith('.webp'): shutil.copy(os.path.join('ink_out', f), os.path.join(OUT, 'images', 'ink', f))
    if PROD:
        os.makedirs(os.path.join(OUT, 'vendor'), exist_ok=True)
        shutil.copy('vendor/supabase.js', os.path.join(OUT, 'vendor', 'supabase.js'))
        open(os.path.join(OUT, '.nojekyll'), 'w').close()
        shutil.copytree('site/images', os.path.join(OUT, 'images'), dirs_exist_ok=True)
    open(os.path.join(OUT, '404.html'), 'w', encoding='utf-8').write(render('404.html', dict(
        title='找不到頁面｜' + SITE, desc='找不到這個頁面', active=None, ld=None, noindex=True, og='images/og.jpg',
        body=phero('', '找不到這個頁面', '網址可能已變更。', 99, amp=.4) + '<div class="pg"><div class="wrap"><p><a class="btn btn-fill" href="index.html">回首頁</a></p></div></div>')))
    # sitemap / robots
    DOMAIN = os.environ.get('GW_DOMAIN', 'chineses.win')
    urls = [f for f in PAGES if not PAGES[f]['noindex']]
    open(os.path.join(OUT, 'sitemap.xml'), 'w', encoding='utf-8').write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + ''.join('  <url><loc>https://%s/%s</loc></url>\n' % (DOMAIN, '' if f == 'index.html' else f) for f in urls) + '</urlset>\n')
    open(os.path.join(OUT, 'robots.txt'), 'w').write('User-agent: *\nAllow: /\nDisallow: /admin.html\nSitemap: https://%s/sitemap.xml\n' % DOMAIN)
    open(os.path.join(OUT, 'CNAME'), 'w').write(DOMAIN + '\n')
    # artifact 首頁片段
    open('artifact_index.html', 'w', encoding='utf-8').write(fragment('index.html', PAGES['index.html']))
    print(len(PAGES), 'pages')

main()
