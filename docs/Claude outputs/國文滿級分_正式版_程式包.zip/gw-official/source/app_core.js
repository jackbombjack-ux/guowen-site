(function(){
'use strict';
var GW=window.GW||{products:[],courses:[],index:[],config:{}};
var CONFIG=GW.config||{};
var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var money=function(n){return 'NT$'+n.toLocaleString('en-US')};
var ico=function(id,st){return '<svg class="ico"'+(st?' style="'+st+'"':'')+'><use href="#'+id+'"/></svg>'};
var esc=function(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var byId=function(list,id){for(var i=0;i<list.length;i++)if(list[i].id===id)return list[i]};
var PAGE=document.body.getAttribute('data-page')||'';

/*@@INK@@*/

/* ---------- 狀態(預覽版存在瀏覽器本機) ---------- */
var PROD=/*@@PROD@@*/false;
var KEY=PROD?'gw-cart-v1':'gw-demo-v2';
function loadS(){try{var o=JSON.parse(localStorage.getItem(KEY))||{};return PROD?{cart:(o&&typeof o.cart==='object'&&o.cart)||{}}:o}catch(e){return {}}}
var S=Object.assign({user:null,cart:{},enrolled:{},claimed:{},essays:[],tessays:[],progress:{},admin:false,tmember:{},sub:null},loadS());
function save(){try{localStorage.setItem(KEY,JSON.stringify(PROD?{cart:S.cart}:S))}catch(e){}}
var onAuth=[];

/* ---------- Toast / 對話框 ---------- */
var toastEl=$('#toast'),toastT;
function toast(msg){if(!toastEl)return;toastEl.textContent=msg;toastEl.classList.add('on');clearTimeout(toastT);toastT=setTimeout(function(){toastEl.classList.remove('on')},2800)}
function showDlg(d){if(!d||d.open)return;if(d.showModal){try{d.showModal();return}catch(e){}}d.setAttribute('open','')}
function closeDlg(d){if(!d)return;if(d.close){try{d.close();return}catch(e){}}d.removeAttribute('open')}
$$('dialog').forEach(function(d){
  d.addEventListener('click',function(e){if(e.target===d)closeDlg(d)});
  $$('[data-close]',d).forEach(function(b){b.addEventListener('click',function(){closeDlg(d)})});
});
var modal=$('#modal'),mBody=$('#mBody');
function openModal(html,mount){mBody.innerHTML=html;if(mount)mount(mBody);showDlg(modal)}
function ext(key){if(CONFIG[key]){window.open(CONFIG[key],'_blank','noopener')}else{toast('此連結將於正式上線前設定')}}
$$('[data-ext]').forEach(function(a){a.addEventListener('click',function(e){var k=a.getAttribute('data-ext');if(CONFIG[k]){e.preventDefault();window.open(CONFIG[k],'_blank','noopener')}else{e.preventDefault();toast('此連結將於正式上線前設定')}})});

/* ---------- 分析(填入代碼後才載入) ---------- */
if(CONFIG.gaId){var gs=document.createElement('script');gs.async=true;gs.src='https://www.googletagmanager.com/gtag/js?id='+encodeURIComponent(CONFIG.gaId);document.head.appendChild(gs);
  window.dataLayer=window.dataLayer||[];window.gtag=function(){window.dataLayer.push(arguments)};gtag('js',new Date());gtag('config',CONFIG.gaId)}

/* ---------- 主題 ---------- */
var root=document.documentElement,themeBtn=$('#themeBtn');
function isDark(){var a=root.getAttribute('data-theme');if(a)return a==='dark';return window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches}
function syncTheme(){var d=isDark();var u=$('#themeUse');if(u)u.setAttribute('href',d?'#i-sun':'#i-moon');if(themeBtn)themeBtn.setAttribute('aria-label',d?'切換為淺色模式':'切換為深色模式')}
try{var saved=localStorage.getItem('gw-theme');if(saved==='dark'||saved==='light')root.setAttribute('data-theme',saved)}catch(e){}
if(themeBtn)themeBtn.addEventListener('click',function(){
  var next=isDark()?'light':'dark';
  document.body.classList.add('theme-anim');
  root.setAttribute('data-theme',next);
  try{localStorage.setItem('gw-theme',next)}catch(e){}
  syncTheme();setTimeout(function(){document.body.classList.remove('theme-anim')},450);
});
new MutationObserver(syncTheme).observe(root,{attributes:true,attributeFilter:['data-theme']});
if(window.matchMedia)try{window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',syncTheme)}catch(e){}
syncTheme();

/* ---------- 導覽 ---------- */
var header=$('#siteHeader');
function onScroll(){if(header)header.classList.toggle('scrolled',window.scrollY>8)}
window.addEventListener('scroll',onScroll,{passive:true});onScroll();
var hamb=$('#hambBtn'),mnav=$('#mnav');
if(hamb)hamb.addEventListener('click',function(){var o=mnav.classList.toggle('open');hamb.setAttribute('aria-expanded',o?'true':'false');hamb.querySelector('use').setAttribute('href',o?'#i-x':'#i-menu')});

/* ---------- 水墨插圖 ---------- */
$$('[data-scene]').forEach(function(el){
  var seed=+el.getAttribute('data-scene'),o={};try{o=JSON.parse(el.getAttribute('data-sopt')||'{}')}catch(e){}
  if(el.classList.contains('art')||el.classList.contains('l-art'))o.hd=1;
  el.insertAdjacentHTML('afterbegin',scene(seed,o));
});
$$('[data-thumb]').forEach(function(el){var p=el.getAttribute('data-thumb').split(':');el.insertAdjacentHTML('afterbegin',thumb(+p[0],p[1]))});
var heroArt=$('#heroArt');if(heroArt)heroArt.innerHTML=heroSVG();
var rb=$('#replayBtn');if(rb)rb.addEventListener('click',function(){var h=$('#home');h.classList.remove('play');void h.offsetWidth;h.classList.add('play')});

/* ---------- 購物車(狀態) ---------- */
function cartCount(){var n=0;for(var k in S.cart)n+=S.cart[k];return n}
function cartSum(){var s=0;for(var k in S.cart){var p=byId(GW.products,k);if(p)s+=S.cart[k]*p.price}return s}
function refreshBadge(bump){
  var b=$('#cartBadge');if(!b)return;var n=cartCount();b.textContent=n;b.classList.toggle('on',n>0);
  if(bump){b.classList.remove('bump');void b.offsetWidth;b.classList.add('bump')}
}
function syncAddBtns(){$$('[data-add]').forEach(function(b){var id=b.getAttribute('data-add');if(b.classList.contains('cartbtn')){var on=!!S.cart[id];b.classList.toggle('added',on);b.innerHTML=ico(on?'i-check':'i-cart','width:18px;height:18px')}})}
function addToCart(id,quiet){
  var p=byId(GW.products,id);if(!p)return;
  if(typeof canAdd==='function'&&!canAdd(id))return;
  S.cart[id]=(S.cart[id]||0)+1;save();refreshBadge(true);syncAddBtns();
  if(!quiet)toast('已加入購物車:'+p.name);
}
$$('[data-add]').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();addToCart(b.getAttribute('data-add'),b.hasAttribute('data-go'));if(b.hasAttribute('data-go'))location.href=b.getAttribute('data-go')})});

/*@@DEMO1_BEGIN@@*/
/* ---------- 會員(Google 登入示範) ---------- */
var userBtn=$('#userBtn');
function renderUserBtn(){
  if(!userBtn)return;
  var u=S.user;
  userBtn.innerHTML=u?'<span style="width:30px;height:30px;border-radius:50%;background:var(--bronze-b);color:var(--on-bronze);display:grid;place-items:center;font-weight:700;font-size:14px">'+esc(u.name.charAt(0).toUpperCase())+'</span>':ico('i-user');
  userBtn.setAttribute('aria-label',u?'會員專區:'+u.name:'會員登入');
}
function setUser(u){S.user=u;if(!u){S.admin=false}save();renderUserBtn();onAuth.forEach(function(f){f()})}
function askLogin(reason,after){
  openModal('<h3 id="mTitle">登入會員</h3><p class="lead">'+esc(reason||'使用 Google 帳號登入,即可領取免費資源、報名課程與上傳作文。')+'</p><button type="button" class="gbtn" id="gLogin"><span class="g" aria-hidden="true">G</span>使用 Google 帳號登入</button><p class="mfoot">不需要另外設定密碼,我們只會取得你的姓名與 Email。目前為版面預覽,按下後以示範帳號登入,不會連線到 Google。</p>',function(){
    $('#gLogin').addEventListener('click',function(){setUser({name:'示範同學',email:'student@example.com'});closeDlg(modal);toast('歡迎,'+S.user.name);if(after)after()});
  });
}
if(userBtn)userBtn.addEventListener('click',function(){if(S.user){location.href='member.html'}else{askLogin()}});
$$('[data-login]').forEach(function(b){b.addEventListener('click',function(){if(S.user){location.href='member.html'}else{askLogin(null,function(){})}})});
if(CONFIG.priceConfirmed)$$('[data-est]').forEach(function(e){e.parentNode.removeChild(e)});
renderUserBtn();refreshBadge();syncAddBtns();

/* ---------- 付費會員(預覽:模擬付款成功後自動開通) ---------- */
function isMember(){return !!(S.user&&S.sub&&S.sub.end>Date.now())}
function fmtDate(t){var d=new Date(t);return d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate()}
var PLAN_NAME={monthly:'月繳',yearly:'年繳'};
function initMembership(){
  var st=$('#memStatus');if(!st)return;
  function render(){
    var on=isMember();
    st.innerHTML=on?'<div class="memstat"><div><b>你目前是付費會員</b><span>方案:'+PLAN_NAME[S.sub.plan]+'・有效至 '+fmtDate(S.sub.end)+'</span></div><div><a class="btn btn-fill sm" href="live.html">前往直播專區</a> <button type="button" class="btn btn-line sm" id="cancelSub">取消訂閱(示範)</button></div></div>':'';
    $$('[data-plan]').forEach(function(b){var p=b.getAttribute('data-plan'),cur=on&&S.sub.plan===p;b.disabled=on;b.textContent=cur?'目前方案':(on?'已是會員':'加入'+PLAN_NAME[p]+'會員');$('#plan-'+p).classList.toggle('cur',cur)});
    var c=$('#cancelSub');if(c)c.addEventListener('click',function(){S.sub=null;save();render();onAuth.forEach(function(f){f!==render&&f()});toast('已取消訂閱(示範)')});
  }
  function confirmPlan(plan){
    openModal('<h3 id="mTitle">確認加入付費會員</h3><p class="lead">方案:'+PLAN_NAME[plan]+'</p><ul><li>正式版會轉到綠界科技的付款頁,可用信用卡等方式付款。</li><li>付款成功後,系統會自動把你的帳號升級為付費會員。</li></ul><p class="mfoot" style="margin-top:0">預覽版沒有真的連線綠界。按下「模擬付款成功」,就能看到開通後的畫面。</p><button type="button" class="btn btn-fill" id="paySim" style="width:100%;margin-top:12px">模擬付款成功</button>',function(){
      $('#paySim').addEventListener('click',function(){
        var now=Date.now();S.sub={plan:plan,start:now,end:now+(plan==='yearly'?365:30)*864e5};save();closeDlg(modal);render();onAuth.forEach(function(f){f!==render&&f()});toast('付款成功,已自動開通付費會員');
      });
    });
  }
  $$('[data-plan]').forEach(function(b){b.addEventListener('click',function(){
    var plan=b.getAttribute('data-plan');
    if(!S.user){askLogin('登入後即可加入付費會員',function(){confirmPlan(plan)});return}
    confirmPlan(plan);
  })});
  onAuth.push(render);render();
}
function initLive(){
  var box=$('#liveMember');if(!box)return;
  function render(){
    if(isMember()){
      box.innerHTML='<h3>會員限定直播</h3><p>你是付費會員,可以進入會員直播。</p><button type="button" class="btn btn-gold" id="enterLive">進入會員直播 '+ico('i-arrow')+'</button><p class="note">方案:'+PLAN_NAME[S.sub.plan]+'・有效至 '+fmtDate(S.sub.end)+'。開播前,老師會在這裡放上直播連結。</p>';
      $('#enterLive').addEventListener('click',function(){if(CONFIG.liveMemberUrl){window.open(CONFIG.liveMemberUrl,'_blank','noopener')}else{toast('預覽版:直播連結將由老師於開播前設定')}});
    }else{
      box.innerHTML='<h3>會員限定直播</h3><p>只開放給付費會員。尚未加入的人看不到直播連結。</p><a class="btn btn-gold" href="membership.html">了解付費會員 '+ico('i-arrow')+'</a><p class="note">在本網站付款,付款成功後自動開通。</p>';
    }
  }
  onAuth.push(render);render();
}

/*@@DEMO1_END@@*/
/* ---------- 搜尋 ---------- */
var sDlg=$('#searchDlg'),sInput=$('#sInput'),sRes=$('#sRes');
function doSearch(){
  var q=sInput.value.trim().toLowerCase();
  var hits=GW.index.filter(function(x){return !q||(x.name+x.desc+x.text).toLowerCase().indexOf(q)>-1}).slice(0,9);
  sRes.innerHTML=hits.length?hits.map(function(h){return '<a class="sit" href="'+h.url+'"><em>'+h.kind+'</em><span><b>'+esc(h.name)+'</b><small>'+esc(h.desc)+'</small></span></a>'}).join(''):'<div class="empty">找不到相關內容,換個關鍵字試試。</div>';
}
var searchBtn=$('#searchBtn');
if(searchBtn&&sDlg){searchBtn.addEventListener('click',function(){showDlg(sDlg);sInput.value='';doSearch();setTimeout(function(){sInput.focus()},30)});sInput.addEventListener('input',doSearch)}

/* ---------- 成果數字 ---------- */
var statsEl=$('#stats');
if(statsEl){
  var statHTML=function(n,u){return n+'<small style="font-size:14px;font-weight:500;margin-left:2px">'+u+'</small>'};
  if('IntersectionObserver' in window&&!reduce){
    var counted=false;
    $$('b',statsEl).forEach(function(b){b.innerHTML=statHTML(0,b.getAttribute('data-u'))});
    new IntersectionObserver(function(es,ob){es.forEach(function(e){
      if(e.isIntersecting&&!counted){counted=true;ob.disconnect();
        $$('b',statsEl).forEach(function(b){var n=+b.getAttribute('data-n'),u=b.getAttribute('data-u'),t0=performance.now();
          (function step(t){var p=Math.min(1,(t-t0)/1200),v=Math.round(n*(1-Math.pow(1-p,3)));b.innerHTML=statHTML(v,u);if(p<1)requestAnimationFrame(step)})(t0)});
      }})},{threshold:.5}).observe(statsEl);
  }
}

/*@@DEMO2_BEGIN@@*/
/* ---------- 頁面:課程資訊 ---------- */
function initCourse(){
  var btn=$('#enrollBtn');if(!btn)return;var cid=btn.getAttribute('data-course'),c=byId(GW.courses,cid);
  function render(){
    var en=!!S.enrolled[cid]&&!!S.user;
    btn.textContent=en?'已報名(前往學習環境)':'報名課程';
    btn.setAttribute('data-state',en?'in':'out');
  }
  btn.addEventListener('click',function(){
    function doEnroll(){S.enrolled[cid]=true;save();render();toast('已報名「'+c.name+'」');setTimeout(function(){location.href=c.learn},500)}
    if(S.enrolled[cid]&&S.user){location.href=c.learn;return}
    if(!S.user){askLogin('登入後即可報名「'+c.name+'」',doEnroll);return}
    doEnroll();
  });
  var sh=$('#shareBtn');
  if(sh)sh.addEventListener('click',function(){
    var url=location.href.split('#')[0];
    if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(url).then(function(){toast('已複製課程連結')},function(){toast('請手動複製網址列連結')})}
    else toast('請手動複製網址列連結');
  });
  onAuth.push(render);render();
}

/* ---------- 頁面:學習環境 ---------- */
function initLearn(){
  var app=$('#learnApp');if(!app)return;var cid=app.getAttribute('data-course'),c=byId(GW.courses,cid);
  var cur=Math.min(S.progress[cid]||0,c.chaps.length-1),panelOn=true,tab=1;
  function gate(){
    var loggedIn=!!S.user;
    app.innerHTML='<div class="gate"><svg class="ico" style="width:34px;height:34px;color:var(--bronze-text);margin:0 auto 8px"><use href="#i-lock"/></svg><h2>'+(loggedIn?'報名後即可進入學習環境':'請先登入並報名課程')+'</h2><p>「'+esc(c.name)+'」為預錄影片課程,報名後在這裡依章節學習。</p><button type="button" class="btn btn-fill" id="gateBtn">'+(loggedIn?'報名課程':'使用 Google 帳號登入並報名')+'</button> <a class="btn btn-line" href="'+c.url+'">回課程資訊</a></div>';
    $('#gateBtn').addEventListener('click',function(){
      function doE(){S.enrolled[cid]=true;save();render()}
      if(!S.user)askLogin('登入後即可報名「'+c.name+'」',doE);else doE();
    });
  }
  function player(){
    app.innerHTML='<div class="lp-bar"><h2>'+esc(c.name)+'</h2><div><button type="button" class="btn btn-line sm" id="lToggle" aria-expanded="'+panelOn+'">章節清單</button> <a class="btn btn-line sm" href="'+c.url+'">課程資訊</a></div></div>'+
     '<div class="lp-grid'+(panelOn?'':' nopanel')+'" id="lpg"><div><div class="vid" id="vid"></div><div class="lp-nav"><button type="button" class="btn btn-line sm" id="lPrev">上一章</button><span id="lPos" style="font-size:13px;color:var(--text-soft)"></span><button type="button" class="btn btn-fill sm" id="lNext">下一章</button></div><p class="lnote">版面預覽:課程上線後,此處會播放 YouTube 影片,並自動記錄你學到哪一章。</p></div>'+
     '<aside class="lpanel" aria-label="章節與字幕"><div class="tabs" role="tablist"><button type="button" role="tab" id="lt1">課程章節</button><button type="button" role="tab" id="lt2">字幕</button></div><div class="chaps" id="chaps"></div><div class="subs" id="subs" hidden>字幕會隨影片提供,可點選段落跳到對應畫面。</div></aside></div>';
    function draw(){
      S.progress[cid]=cur;save();
      $('#chaps').innerHTML=c.chaps.map(function(t,i){return '<button type="button" class="chap" data-ch="'+i+'" aria-current="'+(i===cur)+'"><i>'+String(i+1).padStart(2,'0')+'</i><span>'+esc(t)+'</span></button>'}).join('');
      $$('[data-ch]',app).forEach(function(b){b.addEventListener('click',function(){cur=+b.getAttribute('data-ch');draw()})});
      $('#vid').innerHTML=scene(80+(cid==='guoxie'?0:1),{amp:.8,sun:true,sunx:520,suny:90})+'<button type="button" class="play" aria-label="播放"><svg viewBox="0 0 24 24"><path d="M7 4.5v15l13-7.5z"/></svg></button><div class="cap"><small>第 '+(cur+1)+' 章</small>'+esc(c.chaps[cur])+'</div>';
      $('.play',app).addEventListener('click',function(){toast('影片將於課程上線後播放')});
      $('#lPos').textContent='第 '+(cur+1)+' / '+c.chaps.length+' 章';
      $('#lPrev').disabled=cur===0;$('#lNext').disabled=cur===c.chaps.length-1;
    }
    function selTab(n){tab=n;$('#lt1').setAttribute('aria-selected',n===1);$('#lt2').setAttribute('aria-selected',n===2);$('#chaps').hidden=n!==1;$('#subs').hidden=n!==2}
    $('#lt1').addEventListener('click',function(){selTab(1)});$('#lt2').addEventListener('click',function(){selTab(2)});
    $('#lPrev').addEventListener('click',function(){if(cur>0){cur--;draw()}});
    $('#lNext').addEventListener('click',function(){if(cur<c.chaps.length-1){cur++;draw()}});
    $('#lToggle').addEventListener('click',function(){panelOn=!panelOn;$('#lpg').classList.toggle('nopanel',!panelOn);this.setAttribute('aria-expanded',panelOn)});
    selTab(tab);draw();
  }
  function render(){(S.user&&S.enrolled[cid])?player():gate()}
  onAuth.push(render);render();
}

/* ---------- 頁面:購物車 ---------- */
function initCart(){
  var app=$('#cartApp');if(!app)return;
  function render(){
    var ids=Object.keys(S.cart).filter(function(id){return byId(GW.products,id)});
    if(!ids.length){app.innerHTML='<div class="empty" style="max-width:520px;margin:20px auto"><b>卷</b>購物車還是空的<br><a class="btn btn-fill" style="margin-top:16px" href="materials.html">逛逛自學教材</a></div>';return}
    app.innerHTML='<div class="cp"><div class="cp-list" id="cpl">'+ids.map(function(id){var p=byId(GW.products,id);
      return '<div class="ci"><a href="'+p.url+'"><img src="images/'+p.cover+'" alt="'+esc(p.title)+' 封面"></a><div><b>'+esc(p.name)+'</b><small>'+money(p.price)+'</small><div class="qty"><button type="button" data-dec="'+id+'" aria-label="減少數量">−</button><span>'+S.cart[id]+'</span><button type="button" data-inc="'+id+'" aria-label="增加數量">+</button></div></div><button type="button" class="rm" data-rm="'+id+'">移除</button></div>'}).join('')+
      '</div><aside class="cp-sum"><h2>訂單摘要</h2>'+ids.map(function(id){var p=byId(GW.products,id);return '<div class="row"><span>'+esc(p.name)+' × '+S.cart[id]+'</span><span>'+money(p.price*S.cart[id])+'</span></div>'}).join('')+'<div class="row total"><span>合計</span><span>'+money(cartSum())+'</span></div><button type="button" class="btn btn-fill" disabled>前往付款(金流串接後啟用)</button><div class="pay"><span>信用卡</span><span>超商繳費</span><span>ATM 轉帳</span></div><p class="mfoot">按下「前往付款」後,會轉到綠界科技的付款頁面,可用方式以該頁顯示為準。</p></aside></div>';
    $$('[data-inc]',app).forEach(function(b){b.addEventListener('click',function(){S.cart[b.getAttribute('data-inc')]++;save();refreshBadge();render()})});
    $$('[data-dec]',app).forEach(function(b){b.addEventListener('click',function(){var id=b.getAttribute('data-dec');S.cart[id]--;if(S.cart[id]<1)delete S.cart[id];save();refreshBadge();render()})});
    $$('[data-rm]',app).forEach(function(b){b.addEventListener('click',function(){delete S.cart[b.getAttribute('data-rm')];save();refreshBadge();render()})});
  }
  render();
}

/* ---------- 頁面:免費資源 ---------- */
function initRes(){
  var btns=$$('[data-res]');if(!btns.length)return;
  function render(){btns.forEach(function(b){
    var id=b.getAttribute('data-res'),gated=b.getAttribute('data-gate')==='1',tagEl=$('#tag-'+id);
    if(!gated)return;
    var done=!!S.claimed[id];
    b.firstChild.nodeValue=done?'已領取 ':(S.user?'立即領取 ':'加入會員領取 ');
    b.classList.toggle('done',done);
    if(tagEl)tagEl.textContent=S.user?'已解鎖':'會員限定';
  })}
  btns.forEach(function(b){b.addEventListener('click',function(){
    var id=b.getAttribute('data-res');
    if(b.getAttribute('data-gate')!=='1'){window.open(b.getAttribute('data-href'),'_blank','noopener');return}
    function claim(){S.claimed[id]=true;save();render();toast('已加入你的資源(下載功能於正式上線後啟用)')}
    if(!S.user){askLogin('登入後即可領取這份資源',claim);return}
    claim();
  })});
  onAuth.push(render);render();
}

/* ---------- 頁面:作文批改 ---------- */
var upFiles=[],upUrls=[],MAXF=6,MAXMB=10;
function clearThumbs(){upUrls.forEach(function(u){URL.revokeObjectURL(u)});upUrls=[];upFiles=[]}
function initEssay(){
  var p=$('#uPanel');if(!p)return;
  function listMine(){
    var box=$('#myEssays');if(!box)return;
    box.innerHTML=S.essays.length?S.essays.map(function(e){return '<li><span>'+esc(e.title)+'('+esc(e.grade)+'・'+e.n+' 張・'+esc(e.date)+')</span><em>'+esc(e.status)+'</em></li>'}).join(''):'<li class="none">還沒有上傳紀錄</li>';
  }
  function render(){
    if(!S.user){
      clearThumbs();
      p.innerHTML='<h3>上傳作文</h3><p class="lead">登入後即可上傳,上傳的作文僅供本人與老師查看。</p><div class="lockmask"><svg class="ico" style="width:32px;height:32px;color:var(--bronze-text)"><use href="#i-lock"/></svg><p>請先使用 Google 帳號登入</p><button type="button" class="btn btn-fill" id="upLogin">使用 Google 帳號登入</button></div>';
      $('#upLogin').addEventListener('click',function(){askLogin('登入後即可上傳作文')});
      listMine();return;
    }
    p.innerHTML='<h3>上傳作文</h3><p class="lead">上傳的作文僅供本人與老師查看。</p>'+
     '<form id="upForm" novalidate><div class="row2"><label class="fld" for="upTitle">作文題目<input id="upTitle" placeholder="例如:溫暖的心" maxlength="60"></label><label class="fld" for="upGrade">年級<select id="upGrade"><option>國一</option><option>國二</option><option>國三</option><option>高一</option><option>高二</option><option selected>高三</option><option>其他</option></select></label></div>'+
     '<label class="drop" id="drop" for="upFile">'+ico('i-upload')+'<span><b>點選選擇照片</b>,或把照片拖曳到這裡</span><span style="font-size:12.5px">最多 '+MAXF+' 張・每張 '+MAXMB+' MB 以內・JPG / PNG / HEIC</span><input id="upFile" type="file" accept="image/*" multiple></label>'+
     '<div class="thumbs" id="thumbs"></div>'+
     '<div class="tips"><span>光線充足</span><span>整頁入鏡</span><span>避免反光與陰影</span><span>依頁碼順序上傳</span></div>'+
     '<label class="fld" for="upNote" style="margin-top:8px">給老師的話(選填)<textarea id="upNote" placeholder="例如:想加強結尾的收束"></textarea></label>'+
     '<div class="err" id="upErr" role="alert"></div><button class="btn btn-fill" type="submit">送出批改</button></form>';
    var inp=$('#upFile'),drop=$('#drop');
    function drawThumbs(){
      $('#thumbs').innerHTML=upUrls.map(function(u,i){return '<div class="th"><img src="'+u+'" alt="作文第 '+(i+1)+' 頁"><button type="button" data-rmf="'+i+'" aria-label="移除第 '+(i+1)+' 張">×</button></div>'}).join('');
      $$('[data-rmf]',p).forEach(function(b){b.addEventListener('click',function(){var i=+b.getAttribute('data-rmf');URL.revokeObjectURL(upUrls[i]);upUrls.splice(i,1);upFiles.splice(i,1);drawThumbs()})});
    }
    function addFiles(list){
      var err=$('#upErr');err.textContent='';
      Array.prototype.forEach.call(list,function(f){
        if(!/^image\//.test(f.type)&&!/\.(heic|heif)$/i.test(f.name)){err.textContent='只能上傳圖片檔。';return}
        if(f.size>MAXMB*1024*1024){err.textContent='「'+f.name+'」超過 '+MAXMB+' MB,請縮小後再上傳。';return}
        if(upFiles.length>=MAXF){err.textContent='最多上傳 '+MAXF+' 張。';return}
        upFiles.push(f);upUrls.push(URL.createObjectURL(f));
      });
      drawThumbs();
    }
    inp.addEventListener('change',function(){addFiles(inp.files);inp.value=''});
    ['dragenter','dragover'].forEach(function(ev){drop.addEventListener(ev,function(e){e.preventDefault();drop.classList.add('over')})});
    ['dragleave','drop'].forEach(function(ev){drop.addEventListener(ev,function(e){e.preventDefault();drop.classList.remove('over')})});
    drop.addEventListener('drop',function(e){if(e.dataTransfer)addFiles(e.dataTransfer.files)});
    drawThumbs();
    $('#upForm').addEventListener('submit',function(e){
      e.preventDefault();var err=$('#upErr'),t=$('#upTitle').value.trim();
      if(!t){err.textContent='請填寫作文題目。';return}
      if(!upFiles.length){err.textContent='請至少上傳一張作文照片。';return}
      S.essays.unshift({id:Date.now(),title:t,grade:$('#upGrade').value,n:upFiles.length,status:'待批改',date:new Date().toLocaleDateString('zh-TW',{month:'numeric',day:'numeric'})});save();
      var n=upFiles.length;clearThumbs();render();toast('已收到「'+t+'」共 '+n+' 張。預覽版不會真的上傳');
    });
    listMine();
  }
  onAuth.push(render);render();
}

/* ---------- 頁面:會員專區 ---------- */
function initMember(){
  var app=$('#memberApp');if(!app)return;
  var tab='c';
  function render(){
    if(!S.user){
      app.innerHTML='<div class="gate"><h2>登入會員</h2><p>使用 Google 帳號登入,即可查看你的課程、作文批改與資源。</p><button type="button" class="gbtn" id="gLogin2" style="max-width:340px;margin:0 auto"><span class="g" aria-hidden="true">G</span>使用 Google 帳號登入</button><p class="mfoot">不需要另外設定密碼。目前為版面預覽,按下後以示範帳號登入。</p></div>';
      $('#gLogin2').addEventListener('click',function(){askLogin()});return;
    }
    var courses=Object.keys(S.enrolled).map(function(id){var c=byId(GW.courses,id);return c?'<li><a href="'+c.learn+'">'+esc(c.name)+'</a><em>前往學習</em></li>':''}).join('')||'<li class="none">尚未報名課程。<a href="courses.html" style="text-decoration:underline;margin-left:6px">看看線上課程</a></li>';
    var es=S.essays.map(function(e){return '<li><span>'+esc(e.title)+'('+esc(e.grade)+'・'+e.n+' 張・'+esc(e.date)+')</span><em>'+esc(e.status)+'</em></li>'}).join('')||'<li class="none">尚未上傳作文。<a href="essay.html" style="text-decoration:underline;margin-left:6px">前往作文批改</a></li>';
    var rs=(GW.resources||[]).filter(function(r){return r.gate&&S.claimed[r.id]}).map(function(r){return '<li><span>'+esc(r.name)+'</span><em>已領取</em></li>'}).join('')||'<li class="none">尚未領取資源。<a href="resources.html" style="text-decoration:underline;margin-left:6px">免費資源</a></li>';
    app.innerHTML='<div class="profile"><span class="av">'+esc(S.user.name.charAt(0).toUpperCase())+'</span><div><b>'+esc(S.user.name)+'</b><small>'+esc(S.user.email)+'</small></div></div>'+
     '<div class="tabs mtabs" role="tablist"><button type="button" role="tab" data-t="c" aria-selected="'+(tab==='c')+'">我的課程</button><button type="button" role="tab" data-t="e" aria-selected="'+(tab==='e')+'">我的作文</button><button type="button" role="tab" data-t="r" aria-selected="'+(tab==='r')+'">我的資源</button><button type="button" role="tab" data-t="a" aria-selected="'+(tab==='a')+'">帳號</button></div>'+
     '<div class="panel">'+
     (tab==='c'?'<h2>我的課程</h2><ul class="mlist">'+courses+'</ul>':'')+
     (tab==='e'?'<h2>我的作文</h2><ul class="mlist">'+es+'</ul>':'')+
     (tab==='r'?'<h2>我的資源</h2><ul class="mlist">'+rs+'</ul>':'')+
     (tab==='a'?'<h2>帳號</h2><ul class="mlist"><li><span>登入方式</span><em>Google 帳號</em></li><li><span>會員等級</span><em>'+(isMember()?'付費會員':'免費會員')+'</em></li>'+(isMember()?'<li><span>方案</span><em>'+PLAN_NAME[S.sub.plan]+'・有效至 '+fmtDate(S.sub.end)+'</em></li>':'')+'</ul><p style="color:var(--text-soft);font-size:14px;margin-bottom:14px">'+(isMember()?'你可以到直播專區進入會員限定直播。':'付費會員可觀看會員限定直播,在網站付款後自動開通。<a href="membership.html" style="text-decoration:underline;margin-left:4px">了解付費會員</a>')+'</p><button type="button" class="btn btn-line" id="logoutBtn">登出</button>':'')+
     '</div>';
    $$('[data-t]',app).forEach(function(b){b.addEventListener('click',function(){tab=b.getAttribute('data-t');render()})});
    var lo=$('#logoutBtn');if(lo)lo.addEventListener('click',function(){setUser(null);toast('已登出')});
  }
  onAuth.push(render);render();
}

/* ---------- 頁面:老師後台(預覽) ---------- */
var DEMO_ESSAYS=[{who:'示範學生 A',title:'溫暖的心',grade:'高三',date:'10/17',status:'待批改',src:'學生上傳'},{who:'示範學生 B',title:'靜夜情懷',grade:'高二',date:'10/16',status:'已批改',src:'學生上傳'},{who:'示範學生 C',title:'縫隙的聯想',grade:'國三',date:'10/15',status:'已批改',src:'學生上傳'}];
var tFiles=[],tUrls=[],tf={who:'',title:'',grade:'國三',open:false};
function clearT(){tUrls.forEach(function(u){URL.revokeObjectURL(u)});tUrls=[];tFiles=[]}
var DEMO_MEMBERS=[{name:'示範學員 A',email:'a@example.com',joined:'10/12',plan:'月繳'},{name:'示範學員 B',email:'b@example.com',joined:'10/14',plan:''},{name:'示範學員 C',email:'c@example.com',joined:'10/16',plan:'年繳'},{name:'示範學員 D',email:'d@example.com',joined:'10/18',plan:''}];
function initAdmin(){
  var app=$('#adminApp');if(!app)return;
  var aTab='e',rows=DEMO_ESSAYS.map(function(r){return Object.assign({},r)}),prodOn={},courseSt={};
  GW.products.forEach(function(p){prodOn[p.id]=true});GW.courses.forEach(function(c){courseSt[c.id]='籌備中'});
  function render(){
    if(!S.admin){
      app.innerHTML='<div class="gate"><h2>老師後台</h2><p>正式版只有老師的 Google 帳號可以進入。這是版面預覽,按下後以示範資料開啟。</p><button type="button" class="btn btn-fill" id="admLogin">以老師帳號進入(預覽)</button></div>';
      $('#admLogin').addEventListener('click',function(){S.admin=true;save();render()});return;
    }
    var mine=S.essays.map(function(e){return {who:(S.user?S.user.name:'示範同學'),title:e.title,grade:e.grade,date:e.date,status:e.status,src:'學生上傳',live:e}});
    var mineT=S.tessays.map(function(e){return {who:e.who||'(老師自行上傳)',title:e.title,grade:e.grade,date:e.date,status:e.status,src:'老師上傳',live:e}});
    var all=mineT.concat(mine,rows);var pending=all.filter(function(r){return r.status==='待批改'}).length;
    var enrolledN=Object.keys(S.enrolled).length;
    var h='<div class="tiles"><div class="tile"><b>'+pending+'</b><span>待批改作文</span></div><div class="tile"><b>'+(DEMO_MEMBERS.length+(S.user?1:0))+'</b><span>會員人數</span></div><div class="tile"><b>'+GW.products.filter(function(p){return prodOn[p.id]}).length+'</b><span>上架中教材</span></div></div>'+
     '<div class="tabs" role="tablist" style="max-width:640px"><button type="button" role="tab" data-at="e" aria-selected="'+(aTab==='e')+'">作文批改</button><button type="button" role="tab" data-at="m" aria-selected="'+(aTab==='m')+'">會員</button><button type="button" role="tab" data-at="p" aria-selected="'+(aTab==='p')+'">教材上架</button><button type="button" role="tab" data-at="c" aria-selected="'+(aTab==='c')+'">課程</button></div><div class="panel">';
    if(aTab==='e'){
      h+='<div class="upanel" id="tPanel" style="margin-bottom:18px"><div style="display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap"><div><h3>老師自行上傳作文</h3><p class="lead" style="margin-bottom:0">手邊額外需要批閱的作文,可以直接在這裡上傳,和學生送來的作文一起排進待批改。</p></div><button type="button" class="btn btn-line sm" id="tToggle" aria-expanded="'+tf.open+'">'+(tf.open?'收合':'＋ 上傳作文')+'</button></div>';
      if(tf.open){
        h+='<form id="tForm" novalidate style="margin-top:16px"><div class="row2"><label class="fld" for="tWho">學生或來源備註(選填)<input id="tWho" placeholder="例如:王同學、班級作業" maxlength="40" value="'+esc(tf.who)+'"></label><label class="fld" for="tGrade">年級<select id="tGrade">'+['國一','國二','國三','高一','高二','高三','其他'].map(function(g){return '<option'+(g===tf.grade?' selected':'')+'>'+g+'</option>'}).join('')+'</select></label></div>'+
         '<label class="fld" for="tTitle" style="margin-bottom:12px">作文題目<input id="tTitle" placeholder="例如:溫暖的心" maxlength="60" value="'+esc(tf.title)+'"></label>'+
         '<label class="drop" id="tDrop" for="tFile">'+ico('i-upload')+'<span><b>點選選擇照片</b>,或把照片拖曳到這裡</span><span style="font-size:12.5px">最多 '+MAXF+' 張・每張 '+MAXMB+' MB 以內・JPG / PNG / HEIC</span><input id="tFile" type="file" accept="image/*" multiple></label>'+
         '<div class="thumbs" id="tThumbs">'+tUrls.map(function(u,i){return '<div class="th"><img src="'+u+'" alt="作文第 '+(i+1)+' 頁"><button type="button" data-trm="'+i+'" aria-label="移除第 '+(i+1)+' 張">×</button></div>'}).join('')+'</div>'+
         '<div class="err" id="tErr" role="alert" style="margin-top:8px"></div><button class="btn btn-fill" type="submit">加入待批改</button></form>';
      }
      h+='</div>';
      h+='<div class="twrap"><table class="tbl"><thead><tr><th>學生</th><th>題目</th><th>年級</th><th>來源</th><th>日期</th><th>狀態</th><th></th></tr></thead><tbody>'+all.map(function(r,i){
        return '<tr><td>'+esc(r.who)+'</td><td>'+esc(r.title)+'</td><td>'+esc(r.grade)+'</td><td><span class="pill'+(r.src==='老師上傳'?' ok':'')+'">'+r.src+'</span></td><td>'+esc(r.date)+'</td><td><span class="pill '+(r.status==='待批改'?'warn':'ok')+'">'+r.status+'</span></td><td>'+(r.status==='待批改'?'<button type="button" class="btn btn-line sm" data-done="'+i+'">標為已批改</button>':'')+'</td></tr>'}).join('')+'</tbody></table></div>';
      h+='<p class="mfoot">正式版:老師上傳的照片同樣存進 Supabase Storage,只是不綁學生帳號;批改流程與學生送來的作文相同。</p>';
      app._all=all;
    }else if(aTab==='m'){
      var mem=(S.user?[{name:S.user.name,email:S.user.email,joined:'今天',plan:isMember()?PLAN_NAME[S.sub.plan]:'',self:1}]:[]).concat(DEMO_MEMBERS);
      h+='<div class="twrap"><table class="tbl"><thead><tr><th>姓名</th><th>Email</th><th>加入日</th><th>付費會員</th><th></th></tr></thead><tbody>'+mem.map(function(m){var has=Object.prototype.hasOwnProperty.call(S.tmember,m.email),on=has?!!S.tmember[m.email]:!!m.plan;
        return '<tr><td>'+esc(m.name)+'</td><td>'+esc(m.email)+'</td><td>'+esc(m.joined)+'</td><td><span class="pill '+(on?'ok':'')+'">'+(on?(has?'手動開通':(m.plan||'付費')):'免費')+'</span></td><td>'+(m.self?'':'<button type="button" class="btn btn-line sm" data-ym="'+esc(m.email)+'" data-on="'+(on?1:0)+'">'+(on?'停用':'手動開通')+'</button>')+'</td></tr>'}).join('')+'</tbody></table></div><p class="mfoot">正式版:客人在網站付款成功後,系統會自動開通,這裡不用處理。手動開通 / 停用只用在退款、補開或贈送的情況。</p>';
    }else if(aTab==='p'){
      h+='<div class="twrap"><table class="tbl"><thead><tr><th>教材</th><th>售價</th><th>狀態</th><th></th></tr></thead><tbody>'+GW.products.map(function(p){
        return '<tr><td>'+esc(p.title)+'</td><td>'+money(p.price)+'</td><td><span class="pill '+(prodOn[p.id]?'ok':'')+'">'+(prodOn[p.id]?'上架中':'已下架')+'</span></td><td><button type="button" class="btn btn-line sm" data-tg="'+p.id+'">'+(prodOn[p.id]?'下架':'上架')+'</button></td></tr>'}).join('')+'</tbody></table></div>';
    }else{
      h+='<div class="twrap"><table class="tbl"><thead><tr><th>課程</th><th>章節數</th><th>狀態</th><th></th></tr></thead><tbody>'+GW.courses.map(function(c){
        return '<tr><td>'+esc(c.name)+'</td><td>'+c.chaps.length+'</td><td><span class="pill">'+courseSt[c.id]+'</span></td><td><button type="button" class="btn btn-line sm" data-cs="'+c.id+'">'+(courseSt[c.id]==='開放報名'?'改為籌備中':'開放報名')+'</button></td></tr>'}).join('')+'</tbody></table></div>';
    }
    h+='</div><p class="mfoot">此為版面預覽,以示範資料呈現管理介面的樣子,變更不會儲存到伺服器。<button type="button" class="more" id="admOut" style="margin-left:10px">登出後台</button></p>';
    app.innerHTML=h;
    $$('[data-at]',app).forEach(function(b){b.addEventListener('click',function(){aTab=b.getAttribute('data-at');render()})});
    var tt=$('#tToggle');if(tt)tt.addEventListener('click',function(){tf.open=!tf.open;render()});
    var tForm=$('#tForm');
    if(tForm){
      ['tWho','tTitle'].forEach(function(id){$('#'+id).addEventListener('input',function(){tf[id==='tWho'?'who':'title']=this.value})});
      $('#tGrade').addEventListener('change',function(){tf.grade=this.value});
      var tfi=$('#tFile'),td=$('#tDrop');
      function tAdd(list){var er=$('#tErr');er.textContent='';
        Array.prototype.forEach.call(list,function(f){
          if(!/^image\//.test(f.type)&&!/\.(heic|heif)$/i.test(f.name)){er.textContent='只能上傳圖片檔。';return}
          if(f.size>MAXMB*1024*1024){er.textContent='「'+f.name+'」超過 '+MAXMB+' MB,請縮小後再上傳。';return}
          if(tFiles.length>=MAXF){er.textContent='最多上傳 '+MAXF+' 張。';return}
          tFiles.push(f);tUrls.push(URL.createObjectURL(f));
        });render();
      }
      tfi.addEventListener('change',function(){tAdd(tfi.files);tfi.value=''});
      ['dragenter','dragover'].forEach(function(ev){td.addEventListener(ev,function(e){e.preventDefault();td.classList.add('over')})});
      ['dragleave','drop'].forEach(function(ev){td.addEventListener(ev,function(e){e.preventDefault();td.classList.remove('over')})});
      td.addEventListener('drop',function(e){if(e.dataTransfer)tAdd(e.dataTransfer.files)});
      $$('[data-trm]',app).forEach(function(b){b.addEventListener('click',function(){var i=+b.getAttribute('data-trm');URL.revokeObjectURL(tUrls[i]);tUrls.splice(i,1);tFiles.splice(i,1);render()})});
      tForm.addEventListener('submit',function(e){
        e.preventDefault();var er=$('#tErr'),t=$('#tTitle').value.trim();
        if(!t){er.textContent='請填寫作文題目。';return}
        if(!tFiles.length){er.textContent='請至少上傳一張作文照片。';return}
        var n=tFiles.length;
        S.tessays.unshift({id:Date.now(),who:$('#tWho').value.trim(),title:t,grade:$('#tGrade').value,n:n,status:'待批改',date:new Date().toLocaleDateString('zh-TW',{month:'numeric',day:'numeric'})});save();
        clearT();tf.who='';tf.title='';tf.open=false;render();toast('已加入「'+t+'」共 '+n+' 張,列在待批改。預覽版不會真的上傳');
      });
    }
    $$('[data-done]',app).forEach(function(b){b.addEventListener('click',function(){var r=app._all[+b.getAttribute('data-done')];r.status='已批改';if(r.live){r.live.status='已批改';save()}render();toast('已標記為已批改')})});
    $$('[data-ym]',app).forEach(function(b){b.addEventListener('click',function(){var k=b.getAttribute('data-ym');S.tmember[k]=b.getAttribute('data-on')!=='1';save();render()})});
    $$('[data-tg]',app).forEach(function(b){b.addEventListener('click',function(){var id=b.getAttribute('data-tg');prodOn[id]=!prodOn[id];render()})});
    $$('[data-cs]',app).forEach(function(b){b.addEventListener('click',function(){var id=b.getAttribute('data-cs');courseSt[id]=courseSt[id]==='開放報名'?'籌備中':'開放報名';render()})});
    $('#admOut').addEventListener('click',function(){S.admin=false;save();render()});
  }
  render();
}

/* ---------- 頁面:聯絡 ---------- */
var cf=$('#contactForm');
if(cf)cf.addEventListener('submit',function(e){
  e.preventDefault();var err=$('#cErr');
  if(!$('#cName').value.trim()){err.textContent='請輸入姓名。';return}
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test($('#cMail').value.trim())){err.textContent='請輸入正確的 Email。';return}
  if(!$('#cMsg').value.trim()){err.textContent='請簡單寫下想詢問的內容。';return}
  err.textContent='';this.reset();toast('留言表單於正式上線後啟用,目前請先用 LINE 聯繫我們');
});

initMembership();initLive();initCourse();initLearn();initCart();initRes();initEssay();initMember();initAdmin();
/*@@DEMO2_END@@*/
/*@@FX@@*/
})();
