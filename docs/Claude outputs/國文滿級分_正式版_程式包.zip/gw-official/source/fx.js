/* ---------- 質感與動態(尊重「減少動態效果」設定) ---------- */
(function(){
  var reducedFx=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var ft=$('.footer');if(ft&&typeof footerMtn==='function')ft.insertAdjacentHTML('afterbegin',footerMtn());
  // 捲動進度:頁首底部一條細墨線
  var hd=$('#siteHeader'),ticking=false;
  function prog(){ticking=false;var h=document.documentElement,m=h.scrollHeight-h.clientHeight;if(hd)hd.style.setProperty('--p',(m>0?h.scrollTop/m:0).toFixed(4))}
  window.addEventListener('scroll',function(){if(!ticking){ticking=true;requestAnimationFrame(prog)}},{passive:true});prog();
  if(reducedFx)return;
  document.documentElement.classList.add('fx');
  // 區塊進場:墨暈般由模糊轉清晰
  if('IntersectionObserver' in window){
    var sel='.sec-head,.pcard,.course,.rcard,.plan,.flow .step,.twocol .box,.band,.ccard,.panel,.tile,.faq details,.pd-cover,.pd-info>*';
    var els=$$(sel).filter(function(e){return !e.closest('.hero')&&!e.closest('dialog')});
    var seen=new Map();
    els.forEach(function(e){var p=e.parentNode,i=seen.get(p)||0;seen.set(p,i+1);e.classList.add('rv');e.style.setProperty('--rd',Math.min(i,7)*70+'ms')});
    var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){var t=x.target;t.classList.add('in');io.unobserve(t);setTimeout(function(){t.classList.remove('rv','in');t.style.removeProperty('--rd')},1700)}})},{rootMargin:'0px 0px -6% 0px',threshold:.08});
    els.forEach(function(e){io.observe(e)});
    // 保險:3 秒後仍未顯示的一律顯示
    setTimeout(function(){els.forEach(function(e){if(e.classList.contains('rv'))e.classList.add('in')})},3500);
  }
  // 視差:首頁山水隨滑鼠與捲動,頁首橫幅隨捲動
  var home=$('#home'),px=$$('.px',home||document),tx=0,ty=0,cx=0,cy=0,raf=0;
  function loop(){raf=0;cx+=(tx-cx)*.08;cy+=(ty-cy)*.08;
    var sy=Math.min(window.scrollY,700)/700;
    px.forEach(function(g){var k=+g.getAttribute('data-k')||0;g.style.transform='translate('+(cx*k).toFixed(2)+'px,'+(cy*k*.5+sy*k*1.6).toFixed(2)+'px)'});
    if(Math.abs(tx-cx)>.002||Math.abs(ty-cy)>.002)raf=requestAnimationFrame(loop)}
  if(home&&px.length){
    home.addEventListener('pointermove',function(e){var b=home.getBoundingClientRect();tx=((e.clientX-b.left)/b.width-.5)*2;ty=((e.clientY-b.top)/b.height-.5)*2;if(!raf)raf=requestAnimationFrame(loop)},{passive:true});
    home.addEventListener('pointerleave',function(){tx=0;ty=0;if(!raf)raf=requestAnimationFrame(loop)});
    window.addEventListener('scroll',function(){if(!raf)raf=requestAnimationFrame(loop)},{passive:true});
  }
  var arts=$$('.phero .art');
  if(arts.length){var t2=false;window.addEventListener('scroll',function(){if(t2)return;t2=true;requestAnimationFrame(function(){t2=false;var y=Math.min(window.scrollY,420)*.1;arts.forEach(function(a){a.style.transform='translateY('+y.toFixed(1)+'px)'})})},{passive:true})}
})();
