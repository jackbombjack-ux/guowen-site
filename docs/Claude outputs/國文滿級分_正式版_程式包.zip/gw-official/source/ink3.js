/* ---------- 水墨 3.0:寫實山水(覆寫 ink2 的 ridge2 / mountain / ridgePines) ----------
   - 山形更嶙峋(加入高頻起伏),向右下的山坡畫成「陰面」:濃墨由山稜向下暈開
   - 陰面內用斧劈皴(短而下斜的筆觸)與飛白(乾筆留白)
   - 山稜線斷續、山頭點苔、松樹成叢(松針團 + 彎曲樹幹)
   - 雲霧用放射漸層,前景有山石 */
function ridge2(r,o){
  var terms=[];for(var i=0;i<3;i++)terms.push({f:o.fr*(1+i*1.9+r()*.7),p:r()*6.283,w:1/(1+i*1.1)});
  var hf=[{f:o.fr*9.3,p:r()*6.283},{f:o.fr*17.1,p:r()*6.283}];
  var cr=o.crag===undefined?.10:o.crag;
  var pts=[];
  for(var x=-10;x<=o.W+10;x+=(o.step||8)){
    var v=0,t=0;terms.forEach(function(q){v+=q.w*(1-Math.abs(Math.sin(x*q.f+q.p)));t+=q.w});
    v=Math.pow(v/t,o.sharp||1.6);
    v+=cr*(.55*Math.sin(x*hf[0].f+hf[0].p)+.45*Math.sin(x*hf[1].f+hf[1].p))*(.35+v);
    var e=o.env?o.env(x/o.W):1;
    pts.push([x,o.base-o.amp*Math.max(v,0)*e]);
  }
  var seg=pts.map(function(p){return p[0]+' '+p[1].toFixed(1)}).join(' L');
  return {pts:pts,line:'M'+seg,d:'M-10 '+(o.H+10)+' L'+seg+' L'+(o.W+10)+' '+(o.H+10)+'Z'};
}
function mountain(r,id,o,l){
  var R=ridge2(r,{W:o.W,H:o.H,base:l.b+(o.lift||0),amp:l.a*(o.amp||1),fr:l.f,sharp:l.sh,env:o.env,step:o.step,crag:l.crag});
  var P=R.pts,big=o.W>800,sc=big?1.6:1,c='var(--'+l.c+')';
  var s='<defs><linearGradient id="'+id+'f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:'+c+'" stop-opacity="'+l.top+'"/><stop offset="1" style="stop-color:'+c+'" stop-opacity="'+l.bot+'"/></linearGradient>'+
    '<linearGradient id="'+id+'s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:'+c+'" stop-opacity="'+l.shade+'"/><stop offset="1" style="stop-color:'+c+'" stop-opacity="0"/></linearGradient>'+
    '<clipPath id="'+id+'c"><path d="'+R.d+'"/></clipPath></defs>';
  // 找出向右下傾斜的連續山坡(陰面)
  var runs=[],cur=null;
  for(var i=0;i<P.length-1;i++){
    var down=P[i+1][1]-P[i][1]>.35;
    if(down){if(!cur)cur=[P[i]];cur.push(P[i+1])}else if(cur){if(cur.length>=3)runs.push(cur);cur=null}
  }
  if(cur&&cur.length>=3)runs.push(cur);
  var shade='',cun1='',cun2='';
  runs.forEach(function(run){
    var span=run[run.length-1][1]-run[0][1];
    if(span<4*sc*.5)return;
    var d=Math.min(l.a*(.55+r()*.3),span*2.4+26*sc);
    var top=run.map(function(p){return p[0].toFixed(1)+' '+p[1].toFixed(1)}).join(' L');
    var bot=run.slice().reverse().map(function(p,k){return p[0].toFixed(1)+' '+(p[1]+d*(.65+.35*Math.sin(k*1.3+run.length))).toFixed(1)}).join(' L');
    shade+='<path fill="url(#'+id+'s)" d="M'+top+' L'+bot+'Z"/>';
    var n=Math.round(run.length*1.8*l.dens);
    for(var k=0;k<n;k++){
      var q=run[Math.floor(r()*run.length)],x=q[0]+(r()-.5)*8*sc,y=q[1]+3+r()*d*.8,len=(10+r()*28)*sc*(.6+l.dens*.4),lean=(2+r()*5)*sc;
      var stroke='M'+x.toFixed(1)+' '+y.toFixed(1)+' q'+(lean*.4).toFixed(1)+' '+(len*.5).toFixed(1)+' '+lean.toFixed(1)+' '+len.toFixed(1)+' ';
      if(r()<.35)cun2+=stroke;else cun1+=stroke;
    }
  });
  // 山頭點苔 + 少量陽面細皴
  var dots='',light='';
  var nd=Math.round(P.length*.22*l.dens);
  for(var k=0;k<nd;k++){var q=P[Math.floor(r()*P.length)],rr=(.7+r()*1.2)*sc,x=q[0]+(r()-.5)*5,y=q[1]+1+r()*4;dots+='M'+(x-rr).toFixed(1)+' '+y.toFixed(1)+' a'+rr.toFixed(1)+' '+(rr*.8).toFixed(1)+' 0 1 0 '+(2*rr).toFixed(1)+' 0 a'+rr.toFixed(1)+' '+(rr*.8).toFixed(1)+' 0 1 0 '+(-2*rr).toFixed(1)+' 0 '}
  for(var k=0;k<Math.round(P.length*.5*l.dens);k++){var q=P[Math.floor(r()*P.length)],x=q[0]+(r()-.5)*10,y=q[1]+6+r()*l.a*.4,len=(6+r()*14)*sc;light+='M'+x.toFixed(1)+' '+y.toFixed(1)+' l'+((r()-.5)*3).toFixed(1)+' '+len.toFixed(1)+' '}
  s+='<g filter="url(#'+l.fl+')"><path fill="url(#'+id+'f)" d="'+R.d+'"/>'+
     '<g clip-path="url(#'+id+'c)">'+shade+
     '<g filter="url(#dry)"><path fill="none" stroke="'+c+'" stroke-width="'+(1.05*sc).toFixed(2)+'" stroke-linecap="round" opacity="'+l.cun+'" d="'+cun1+'"/>'+
     '<path fill="none" stroke="'+c+'" stroke-width="'+(1.9*sc).toFixed(2)+'" stroke-linecap="round" opacity="'+(l.cun*.55).toFixed(2)+'" d="'+cun2+'"/>'+
     '<path fill="none" stroke="'+c+'" stroke-width="'+(.7*sc).toFixed(2)+'" stroke-linecap="round" opacity="'+(l.cun*.55).toFixed(2)+'" d="'+light+'"/></g></g>'+
     '<path fill="none" stroke="'+c+'" stroke-width="'+(1.2*sc).toFixed(2)+'" stroke-linejoin="round" opacity="'+(l.edge*.55).toFixed(2)+'" d="'+R.line+'"/>'+
     '<path fill="none" stroke="'+c+'" stroke-width="'+(1.7*sc).toFixed(2)+'" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="'+(9*sc).toFixed(0)+' '+(4*sc).toFixed(0)+' '+(22*sc).toFixed(0)+' '+(6*sc).toFixed(0)+'" opacity="'+l.edge+'" d="'+R.line+'"/>'+
     '<path fill="'+c+'" opacity="'+(l.edge+.15).toFixed(2)+'" d="'+dots+'"/></g>';
  return {svg:s,pts:P};
}
/* 一叢松:彎曲樹幹 + 幾團松針 */
function pineTree(r,x,y,s){
  var h=(34+r()*22)*s,lean=(r()-.5)*10*s,d='M'+x.toFixed(1)+' '+y.toFixed(1)+' q'+(lean).toFixed(1)+' '+(-h*.5).toFixed(1)+' '+(lean*.4).toFixed(1)+' '+(-h).toFixed(1);
  var f='';
  for(var k=0;k<4;k++){
    var t=(.38+k*.2)+r()*.06,cx=x+lean*t*.9+(r()-.5)*5*s,cy=y-h*t,rx=(13-k*2.2+r()*3)*s,ry=(3.6+r()*1.6)*s;
    f+='M'+(cx-rx).toFixed(1)+' '+cy.toFixed(1)+' q'+rx.toFixed(1)+' '+(-ry*2.2).toFixed(1)+' '+(rx*2).toFixed(1)+' 0 q'+(-rx).toFixed(1)+' '+(ry*1.1).toFixed(1)+' '+(-rx*2).toFixed(1)+' 0Z ';
  }
  return {trunk:d,foliage:f};
}
function ridgePines(r,pts,count,s0,lo,hi){
  var tr='',fo='';
  for(var i=0;i<count;i++){
    var base=pts[Math.floor(lo+r()*(hi-lo))];if(!base)continue;
    var n=1+Math.floor(r()*3);
    for(var k=0;k<n;k++){var t=pineTree(r,base[0]+k*(7+r()*9)*s0,base[1]+4+r()*3,s0*(.6+r()*.6));tr+=t.trunk+' ';fo+=t.foliage}
  }
  return '<path fill="none" stroke="var(--ik3)" stroke-width="'+(1.5*s0).toFixed(2)+'" stroke-linecap="round" opacity=".8" d="'+tr+'"/><path fill="var(--ik3)" opacity=".78" d="'+fo+'"/>';
}
/* 前景山石 */
function rock(r,x,y,w,h){
  var n=7,p=[];
  for(var i=0;i<=n;i++){var u=i/n,yy=y-h*Math.pow(Math.sin(Math.PI*u),.7)*(.72+r()*.45);p.push([x+w*u+(r()-.5)*w*.04,yy])}
  var d='M'+x+' '+(y+4)+' L'+p.map(function(q){return q[0].toFixed(1)+' '+q[1].toFixed(1)}).join(' L')+' L'+(x+w)+' '+(y+4)+'Z';
  var hl='M'+p.slice(1,4).map(function(q){return (q[0]+2).toFixed(1)+' '+(q[1]+3).toFixed(1)}).join(' L');
  return '<path d="'+d+'" fill="var(--ik3)" opacity=".94"/><path d="'+hl+'" fill="none" stroke="var(--ik1)" stroke-width="1.2" opacity=".45" stroke-linecap="round"/>';
}
