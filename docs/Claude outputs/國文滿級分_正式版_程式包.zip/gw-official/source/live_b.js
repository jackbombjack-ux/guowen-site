/* ================= 正式版:接上 Supabase(登入、報名、付款、作文、後台) ================= */
var sb=null,U=null,MEM=null,ENR={},CLAIMED={},ready=false;
var PUB={products:{},courses:{},plans:{},resources:{},pay:false};
var INTENT={};
var sleep=function(ms){return new Promise(function(r){setTimeout(r,ms)})};
var isAdmin=function(){return !!(U&&U.role==='admin')};
function isMember(){return !!(U&&MEM&&new Date(MEM.valid_until).getTime()+3*864e5>Date.now())}
function fmtDate(t){var d=new Date(t);return d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate()}
function fmtDT(t){var d=new Date(t);return fmtDate(t)+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}
function planName(id){return (PUB.plans[id]&&PUB.plans[id].name)||({monthly:'月繳',yearly:'年繳'}[id])||'付費會員'}
function canAdd(id){var p=PUB.products[id];if(p&&!p.active){toast('這本教材暫時無法購買');return false}return true}

var CAN_EMAIL=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function niceErr(e){
  var m=(e&&e.message)||'';
  if(/Failed to fetch|NetworkError|network/i.test(m))return '網路連線不穩,請稍後再試。';
  if(/row-level security|permission denied/i.test(m))return '沒有權限執行這個動作。';
  if(/duplicate key/i.test(m))return '資料已存在。';
  return m||'系統忙碌,請稍後再試。';
}
async function callFn(name,body){
  var r=await sb.functions.invoke(name,{body:body});
  if(r.error){
    var m='系統忙碌,請稍後再試';
    try{if(r.error.context&&r.error.context.json){var j=await r.error.context.json();if(j&&j.error)m=j.error}}catch(_){}
    throw new Error(m);
  }
  if(r.data&&r.data.error)throw new Error(r.data.error);
  return r.data;
}
function postForm(url,fields){
  var f=document.createElement('form');f.method='POST';f.action=url;f.acceptCharset='UTF-8';
  Object.keys(fields).forEach(function(k){var i=document.createElement('input');i.type='hidden';i.name=k;i.value=fields[k];f.appendChild(i)});
  document.body.appendChild(f);f.submit();
}
async function checkout(body,btn,errEl){
  var label=btn&&btn.textContent;
  if(btn){btn.disabled=true;btn.textContent='正在前往綠界…'}
  if(errEl)errEl.textContent='';
  try{
    var r=await callFn('create-order',body);
    if(!r||!r.url||!r.fields)throw new Error('系統忙碌,請稍後再試');
    postForm(r.url,r.fields);
  }catch(e){
    if(btn){btn.disabled=false;btn.textContent=label}
    if(errEl)errEl.textContent=niceErr(e);else toast(niceErr(e));
  }
}

/* ---------- 登入 ---------- */
var userBtn=$('#userBtn');
function renderUserBtn(){
  if(!userBtn)return;
  userBtn.innerHTML=U?'<span style="width:30px;height:30px;border-radius:50%;background:var(--bronze-b);color:var(--on-bronze);display:grid;place-items:center;font-weight:700;font-size:14px">'+esc((U.name||'?').charAt(0).toUpperCase())+'</span>':ico('i-user');
  userBtn.setAttribute('aria-label',U?'會員專區:'+U.name:'會員登入');
}
function signIn(intent){
  if(!sb){toast('網站尚未完成設定,請稍後再試');return}
  try{sessionStorage.setItem('gw-after',JSON.stringify(Object.assign({page:PAGE},intent||{})))}catch(e){}
  sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin+location.pathname,queryParams:{prompt:'select_account'}}}).then(function(r){if(r&&r.error)toast('登入失敗:'+niceErr(r.error))});
}
function askLogin(reason,intent){
  openModal('<h3 id="mTitle">登入會員</h3><p class="lead">'+esc(reason||'使用 Google 帳號登入,即可領取免費資源、報名課程與上傳作文。')+'</p><button type="button" class="gbtn" id="gLogin"><span class="g" aria-hidden="true">G</span>使用 Google 帳號登入</button><p class="mfoot">不需要另外設定密碼,我們只會取得你的姓名與 Email。登入即表示同意<a href="terms.html" style="text-decoration:underline">服務條款</a>與<a href="privacy.html" style="text-decoration:underline">隱私權政策</a>。</p>',function(){
    $('#gLogin').addEventListener('click',function(){signIn(intent)});
  });
}
if(userBtn)userBtn.addEventListener('click',function(){if(U){location.href='member.html'}else{askLogin()}});
$$('[data-login]').forEach(function(b){b.addEventListener('click',function(){if(U){location.href='member.html'}else{askLogin()}})});
async function signOut(){try{await sb.auth.signOut()}catch(e){}U=null;MEM=null;ENR={};CLAIMED={};renderUserBtn();fire();toast('已登出')}

/* ---------- 載入使用者與公開資料 ---------- */
async function loadUser(session){
  if(!session||!session.user){U=null;MEM=null;ENR={};CLAIMED={};return}
  var au=session.user,prof=null;
  for(var i=0;i<4&&!prof;i++){var r=await sb.from('profiles').select('id,email,name,role').eq('id',au.id).maybeSingle();prof=r.data;if(!prof)await sleep(500)}
  var meta=au.user_metadata||{};
  U={id:au.id,email:(prof&&prof.email)||au.email||'',name:(prof&&prof.name)||meta.full_name||meta.name||(au.email||'會員').split('@')[0],role:prof?prof.role:'student'};
  await loadMine();
}
async function loadMine(){
  if(!U)return;
  var rs=await Promise.all([
    sb.from('memberships').select('plan,status,valid_until').eq('user_id',U.id).maybeSingle(),
    sb.from('enrollments').select('course_id').eq('user_id',U.id),
    sb.from('resource_claims').select('resource_id').eq('user_id',U.id)]);
  MEM=rs[0].data||null;ENR={};CLAIMED={};
  (rs[1].data||[]).forEach(function(x){ENR[x.course_id]=true});
  (rs[2].data||[]).forEach(function(x){CLAIMED[x.resource_id]=true});
}
function tagPrice(){
  $$('[data-price]').forEach(function(el){var p=byId(GW.products,el.getAttribute('data-price'));if(p)el.textContent=p.price.toLocaleString('en-US')});
}
async function loadPublic(){
  try{
    var rs=await Promise.all([
      sb.from('products').select('id,price,active,kind'),sb.from('courses').select('id,price,status'),
      sb.from('plans').select('id,name,amount,period_type,frequency,active'),sb.from('site_settings').select('key,value'),
      sb.from('resources').select('id,name,gate,storage_path,href')]);
    (rs[0].data||[]).forEach(function(r){PUB.products[r.id]=r;var p=byId(GW.products,r.id);if(p)p.price=r.price});
    (rs[1].data||[]).forEach(function(r){PUB.courses[r.id]=r});
    (rs[2].data||[]).forEach(function(r){PUB.plans[r.id]=r});
    (rs[4].data||[]).forEach(function(r){PUB.resources[r.id]=r});
    (rs[3].data||[]).forEach(function(r){
      if(r.key==='payments_enabled')PUB.pay=(r.value===true);
      if(r.key==='line_url'&&r.value)CONFIG.lineUrl=r.value;
      if(r.key==='youtube_url'&&r.value)CONFIG.youtubeUrl=r.value;
    });
  }catch(e){}
  tagPrice();
  Object.keys(PUB.products).forEach(function(id){
    if(!PUB.products[id].active)$$('[data-add="'+id+'"]').forEach(function(b){b.classList.add('off');b.setAttribute('title','暫時無法購買')});
  });
  Object.keys(PUB.courses).forEach(function(id){
    if(PUB.courses[id].status==='open')$$('#card-'+id+' .cbadge').forEach(function(b){b.textContent='開放報名'});
  });
  $$('#enrollBtn').forEach(function(b){var c=PUB.courses[b.getAttribute('data-course')];if(c&&c.status==='open'){var bd=$('.pd-info .cbadge');if(bd)bd.textContent='開放報名'}});
  Object.keys(PUB.plans).forEach(function(id){
    var pl=PUB.plans[id],el=$('[data-planprice="'+id+'"]');
    if(el&&pl.active)el.textContent=pl.amount.toLocaleString('en-US')+(pl.period_type==='Y'?' / 年':' / 月');
  });
}
function fire(){renderUserBtn();onAuth.forEach(function(f){try{f()}catch(e){console.error(e)}})}
function takeIntent(){
  try{var j=JSON.parse(sessionStorage.getItem('gw-after')||'null');sessionStorage.removeItem('gw-after');return j&&j.page===PAGE?j:null}catch(e){return null}
}
async function boot(){
  var url=CONFIG.supabaseUrl,key=CONFIG.supabaseAnonKey;
  if(url&&key&&window.supabase&&window.supabase.createClient){
    sb=window.supabase.createClient(url,key,{auth:{flowType:'pkce',detectSessionInUrl:true,persistSession:true,autoRefreshToken:true}});
    sb.auth.onAuthStateChange(function(ev,session){
      if(!ready)return;
      setTimeout(async function(){
        if(ev==='SIGNED_OUT'){if(U){U=null;MEM=null;ENR={};CLAIMED={};fire()}}
        else if(ev==='SIGNED_IN'&&session&&(!U||U.id!==session.user.id)){await loadUser(session);fire()}
      },0);
    });
    try{var g=await sb.auth.getSession();await loadUser(g.data&&g.data.session)}catch(e){console.error(e)}
    await loadPublic();
  }
  ready=true;
  fire();
  var it=takeIntent();
  if(it&&U&&it.act&&INTENT[it.act])INTENT[it.act](it.arg);
}

/* ---------- 付費會員 ---------- */
function initMembership(){
  var st=$('#memStatus');if(!st)return;
  function render(){
    var on=isMember();
    var cancelled=MEM&&MEM.status==='cancelled';
    st.innerHTML=on?'<div class="memstat"><div><b>你目前是付費會員</b><span>'+(MEM.plan?'方案:'+esc(planName(MEM.plan))+'・':'')+(cancelled?'已取消續約,':'')+'有效至 '+fmtDate(MEM.valid_until)+'</span></div><div><a class="btn btn-fill sm" href="live.html">前往直播專區</a> <a class="btn btn-line sm" href="member.html">管理訂閱</a></div></div>':'';
    $$('[data-plan]').forEach(function(b){
      var p=b.getAttribute('data-plan'),pl=PUB.plans[p],cur=on&&!cancelled&&MEM.plan===p,avail=!!(pl&&pl.active&&PUB.pay);
      b.disabled=!ready||!avail||(on&&!cancelled);
      b.textContent=!avail?'即將開放':(cur?'目前方案':(on&&!cancelled?'已是會員':'加入'+planName(p)+'會員'));
      var card=$('#plan-'+p);if(card)card.classList.toggle('cur',cur);
    });
  }
  function confirmPlan(plan){
    var pl=PUB.plans[plan];if(!pl||!pl.active||!PUB.pay){toast('這個方案尚未開放');return}
    var every=pl.period_type==='Y'?'每年':'每月';
    openModal('<h3 id="mTitle">確認加入付費會員</h3><p class="lead">方案:'+esc(pl.name)+'・NT$'+pl.amount.toLocaleString('en-US')+' / '+(pl.period_type==='Y'?'年':'月')+'</p><ul><li>以信用卡定期定額付款,'+every+'自動扣款 NT$'+pl.amount.toLocaleString('en-US')+'。</li><li>卡號只會輸入在綠界科技的付款頁,本站不會經手。</li><li>付款成功後,系統會自動開通付費會員。</li><li>可隨時到「會員專區」取消續約,已付款的期間仍可使用到期。</li></ul><div class="err" id="payErr" role="alert"></div><button type="button" class="btn btn-fill" id="payGo" style="width:100%;margin-top:12px">前往綠界付款</button>',function(){
      $('#payGo').addEventListener('click',function(){checkout({type:'membership',plan:plan},this,$('#payErr'))});
    });
  }
  INTENT.plan=confirmPlan;
  $$('[data-plan]').forEach(function(b){b.addEventListener('click',function(){
    var plan=b.getAttribute('data-plan');
    if(!U){askLogin('登入後即可加入付費會員',{act:'plan',arg:plan});return}
    confirmPlan(plan);
  })});
  onAuth.push(render);render();
}

/* ---------- 直播專區 ---------- */
function initLive(){
  var box=$('#liveMember');if(!box)return;
  async function render(){
    if(!ready)return;
    if(!(isMember()||isAdmin())){
      box.innerHTML='<h3>會員限定直播</h3><p>只開放給付費會員。尚未加入的人看不到直播連結。</p><a class="btn btn-gold" href="membership.html">了解付費會員 '+ico('i-arrow')+'</a><p class="note">在本網站付款,付款成功後自動開通。</p>';return;
    }
    box.innerHTML='<h3>會員限定直播</h3><p>讀取中…</p>';
    var ev=await sb.from('live_events').select('id,title,starts_at').order('starts_at',{ascending:false,nullsFirst:false}).limit(5);
    var ids=(ev.data||[]).map(function(x){return x.id});
    var lk=ids.length?await sb.from('live_links').select('event_id,url').in('event_id',ids):{data:[]};
    var map={};(lk.data||[]).forEach(function(x){map[x.event_id]=x.url});
    var cur=(ev.data||[]).filter(function(x){return map[x.id]})[0];
    if(!cur){box.innerHTML='<h3>會員限定直播</h3><p>你可以收看會員直播。目前老師還沒有放上直播連結,開播前會在這裡更新。</p>';return}
    box.innerHTML='<h3>會員限定直播</h3><p>'+esc(cur.title)+(cur.starts_at?'・'+esc(fmtDT(cur.starts_at)):'')+'</p><a class="btn btn-gold" id="enterLive" target="_blank" rel="noopener noreferrer">進入會員直播 '+ico('i-arrow')+'</a><p class="note">請不要把直播連結轉傳給他人。</p>';
    var a=$('#enterLive');try{var u=new URL(map[cur.id]);if(/^https?:$/.test(u.protocol))a.href=u.href}catch(e){a.removeAttribute('target')}
  }
  onAuth.push(render);render();
}

/* ---------- 課程資訊 ---------- */
async function enrollCourse(cid){
  var c=PUB.courses[cid];if(!c)return false;
  if(c.price>0){await checkout({type:'course',course:cid});return false}
  var r=await sb.rpc('enroll_free',{p_course:cid});
  if(r.error){toast(niceErr(r.error));return false}
  ENR[cid]=true;return true;
}
function initCourse(){
  var btn=$('#enrollBtn');if(!btn)return;var cid=btn.getAttribute('data-course'),c=byId(GW.courses,cid);
  function render(){
    var db=PUB.courses[cid],en=!!ENR[cid]&&!!U;
    if(!ready){btn.disabled=true;btn.textContent='載入中…';return}
    if(en){btn.disabled=false;btn.textContent='已報名(前往學習環境)';return}
    if(!db||(db.status!=='open'&&!isAdmin())){btn.disabled=true;btn.textContent='課程籌備中';return}
    if(db.price>0&&!PUB.pay){btn.disabled=true;btn.textContent='課程付款尚未開放';return}
    btn.disabled=false;btn.textContent=db.price>0?'購買課程 NT$'+db.price.toLocaleString('en-US'):'免費報名';
  }
  INTENT.enroll=async function(){if(await enrollCourse(cid)){toast('已報名「'+c.name+'」');setTimeout(function(){location.href=c.learn},500)}};
  btn.addEventListener('click',async function(){
    if(ENR[cid]&&U){location.href=c.learn;return}
    if(!U){askLogin('登入後即可報名「'+c.name+'」',{act:'enroll',arg:cid});return}
    btn.disabled=true;
    if(await enrollCourse(cid)){toast('已報名「'+c.name+'」');setTimeout(function(){location.href=c.learn},500)}
    render();
  });
  var sh=$('#shareBtn');
  if(sh)sh.addEventListener('click',function(){
    var url=location.href.split('#')[0];
    if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(url).then(function(){toast('已複製課程連結')},function(){toast('請手動複製網址列連結')})}
    else toast('請手動複製網址列連結');
  });
  onAuth.push(render);render();
}

/* ---------- 學習環境 ---------- */
function ytId(v){
  v=String(v||'').trim();
  var m=v.match(/(?:v=|youtu\.be\/|embed\/|live\/|shorts\/)([A-Za-z0-9_-]{6,20})/);
  if(m)return m[1];
  return /^[A-Za-z0-9_-]{6,20}$/.test(v)?v:'';
}
function initLearn(){
  var app=$('#learnApp');if(!app)return;var cid=app.getAttribute('data-course'),c=byId(GW.courses,cid);
  var cur=0,panelOn=true,chapters=null,vids={},progT=null,drawn=false;
  function gate(kind){
    var db=PUB.courses[cid],open=db&&db.status==='open';
    var t,b,btnTxt;
    if(!ready){app.innerHTML='<div class="gate"><p>載入中…</p></div>';return}
    if(!U){t='請先登入並報名課程';btnTxt='使用 Google 帳號登入'}
    else if(!open){t='課程籌備中';btnTxt=''}
    else if(db.price>0&&!PUB.pay){t='課程付款尚未開放';btnTxt=''}
    else{t='報名後即可進入學習環境';btnTxt=db.price>0?'購買課程 NT$'+db.price.toLocaleString('en-US'):'免費報名'}
    app.innerHTML='<div class="gate"><svg class="ico" style="width:34px;height:34px;color:var(--bronze-text);margin:0 auto 8px"><use href="#i-lock"/></svg><h2>'+t+'</h2><p>「'+esc(c.name)+'」為預錄影片課程,報名後在這裡依章節學習。</p>'+(btnTxt?'<button type="button" class="btn btn-fill" id="gateBtn">'+btnTxt+'</button> ':'')+'<a class="btn btn-line" href="'+c.url+'">回課程資訊</a></div>';
    var g=$('#gateBtn');
    if(g)g.addEventListener('click',async function(){
      if(!U){askLogin('登入後即可報名「'+c.name+'」',{act:'enroll',arg:cid});return}
      g.disabled=true;
      if(await enrollCourse(cid)){drawn=false;render()}else g.disabled=false;
    });
  }
  async function load(){
    var ch=await sb.from('course_chapters').select('id,position,title,is_preview').eq('course_id',cid).order('position');
    chapters=(ch.data||[]).map(function(x){return {id:x.id,title:x.title}});
    if(!chapters.length)chapters=c.chaps.map(function(t){return {id:null,title:t}});
    var ids=chapters.map(function(x){return x.id}).filter(Boolean);
    vids={};
    if(ids.length){var v=await sb.from('chapter_videos').select('chapter_id,youtube_id').in('chapter_id',ids);(v.data||[]).forEach(function(x){vids[x.chapter_id]=x.youtube_id})}
    var p=await sb.from('progress').select('position').eq('user_id',U.id).eq('course_id',cid).maybeSingle();
    cur=Math.max(0,Math.min((p.data&&p.data.position)||0,chapters.length-1));
  }
  function saveProg(){
    clearTimeout(progT);
    progT=setTimeout(function(){sb.from('progress').upsert({user_id:U.id,course_id:cid,position:cur,updated_at:new Date().toISOString()},{onConflict:'user_id,course_id'}).then(function(){},function(){})},600);
  }
  function player(){
    app.innerHTML='<div class="lp-bar"><h2>'+esc(c.name)+'</h2><div><button type="button" class="btn btn-line sm" id="lToggle" aria-expanded="'+panelOn+'">章節清單</button> <a class="btn btn-line sm" href="'+c.url+'">課程資訊</a></div></div>'+
     '<div class="lp-grid'+(panelOn?'':' nopanel')+'" id="lpg"><div><div class="vid" id="vid"></div><div class="lp-nav"><button type="button" class="btn btn-line sm" id="lPrev">上一章</button><span id="lPos" style="font-size:13px;color:var(--text-soft)"></span><button type="button" class="btn btn-fill sm" id="lNext">下一章</button></div></div>'+
     '<aside class="lpanel" aria-label="章節與字幕"><div class="tabs" role="tablist"><button type="button" role="tab" id="lt1">課程章節</button><button type="button" role="tab" id="lt2">字幕</button></div><div class="chaps" id="chaps"></div><div class="subs" id="subs" hidden>字幕請在影片播放器右下角的「CC」按鈕開啟。</div></aside></div>';
    function draw(){
      $('#chaps').innerHTML=chapters.map(function(t,i){return '<button type="button" class="chap" data-ch="'+i+'" aria-current="'+(i===cur)+'"><i>'+String(i+1).padStart(2,'0')+'</i><span>'+esc(t.title)+'</span></button>'}).join('');
      $$('[data-ch]',app).forEach(function(b){b.addEventListener('click',function(){cur=+b.getAttribute('data-ch');saveProg();draw()})});
      var yid=chapters[cur].id&&vids[chapters[cur].id];
      $('#vid').innerHTML=yid?'<iframe src="https://www.youtube-nocookie.com/embed/'+encodeURIComponent(yid)+'?rel=0&modestbranding=1&playsinline=1" title="'+esc(chapters[cur].title)+'" allow="accelerometer; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" style="position:absolute;inset:0;width:100%;height:100%;border:0"></iframe>':
        scene(80+(cid==='guoxie'?0:1),{amp:.8,sun:true,sunx:520,suny:90})+'<div class="cap"><small>第 '+(cur+1)+' 章</small>'+esc(chapters[cur].title)+'・影片準備中</div>';
      $('#lPos').textContent='第 '+(cur+1)+' / '+chapters.length+' 章';
      $('#lPrev').disabled=cur===0;$('#lNext').disabled=cur===chapters.length-1;
    }
    function selTab(n){$('#lt1').setAttribute('aria-selected',n===1);$('#lt2').setAttribute('aria-selected',n===2);$('#chaps').hidden=n!==1;$('#subs').hidden=n!==2}
    $('#lt1').addEventListener('click',function(){selTab(1)});$('#lt2').addEventListener('click',function(){selTab(2)});
    $('#lPrev').addEventListener('click',function(){if(cur>0){cur--;saveProg();draw()}});
    $('#lNext').addEventListener('click',function(){if(cur<chapters.length-1){cur++;saveProg();draw()}});
    $('#lToggle').addEventListener('click',function(){panelOn=!panelOn;$('#lpg').classList.toggle('nopanel',!panelOn);this.setAttribute('aria-expanded',panelOn)});
    selTab(1);draw();
  }
  async function render(){
    if(!ready){gate();return}
    if(!U||!(ENR[cid]||isAdmin())){drawn=false;gate();return}
    if(drawn)return;
    app.innerHTML='<div class="gate"><p>載入課程…</p></div>';
    try{await load();drawn=true;player()}catch(e){app.innerHTML='<div class="gate"><p>讀取失敗,請重新整理頁面。</p></div>'}
  }
  onAuth.push(render);render();
}

/* ---------- 購物車與結帳 ---------- */
var RC_KEY='gw-rcpt';
function loadRc(){try{return JSON.parse(localStorage.getItem(RC_KEY))||{}}catch(e){return {}}}
function saveRc(o){try{localStorage.setItem(RC_KEY,JSON.stringify(o))}catch(e){}}
function initCart(){
  var app=$('#cartApp');if(!app)return;
  function render(){
    var ids=Object.keys(S.cart).filter(function(id){return byId(GW.products,id)});
    if(!ids.length){app.innerHTML='<div class="empty" style="max-width:520px;margin:20px auto"><b>卷</b>購物車還是空的<br><a class="btn btn-fill" style="margin-top:16px" href="materials.html">逛逛自學教材</a></div>';return}
    var rc=loadRc();
    var gone=ids.filter(function(id){return PUB.products[id]&&!PUB.products[id].active});
    var needShip=ids.some(function(id){return !PUB.products[id]||PUB.products[id].kind==='physical'});
    app.innerHTML='<div class="cp"><div class="cp-list" id="cpl">'+ids.map(function(id){var p=byId(GW.products,id);
      return '<div class="ci"><a href="'+p.url+'"><img src="images/'+p.cover+'" alt="'+esc(p.title)+' 封面"></a><div><b>'+esc(p.name)+'</b><small>'+money(p.price)+'</small><div class="qty"><button type="button" data-dec="'+id+'" aria-label="減少數量">−</button><span>'+S.cart[id]+'</span><button type="button" data-inc="'+id+'" aria-label="增加數量">+</button></div></div><button type="button" class="rm" data-rm="'+id+'">移除</button></div>'}).join('')+
      '</div><aside class="cp-sum"><h2>訂單摘要</h2>'+ids.map(function(id){var p=byId(GW.products,id);return '<div class="row"><span>'+esc(p.name)+' × '+S.cart[id]+'</span><span>'+money(p.price*S.cart[id])+'</span></div>'}).join('')+'<div class="row total"><span>合計</span><span>'+money(cartSum())+'</span></div>'+
      (needShip&&PUB.pay?'<div class="rcpt"><h3>收件資料</h3><label class="fld" for="rName">收件人<input id="rName" autocomplete="name" maxlength="30" value="'+esc(rc.name||'')+'"></label><label class="fld" for="rPhone">手機<input id="rPhone" type="tel" autocomplete="tel" inputmode="tel" maxlength="20" value="'+esc(rc.phone||'')+'"></label><label class="fld" for="rAddr">收件地址<input id="rAddr" autocomplete="street-address" maxlength="120" value="'+esc(rc.address||'')+'"></label></div>':'')+
      (PUB.pay?'<label class="fld" for="rNote">備註(選填)<input id="rNote" maxlength="100" value="'+esc(rc.note||'')+'"></label>':'')+
      (gone.length?'<p class="err">購物車內有已下架的教材,請先移除。</p>':'')+
      '<div class="err" id="cartErr" role="alert"></div>'+(PUB.pay?'<button type="button" class="btn btn-fill" id="goPay"'+(gone.length?' disabled':'')+'>前往付款</button>':'<p class="paynote" id="noPay">線上付款即將開放。現在想訂購,請先透過 LINE 聯繫我們,我們會協助你完成。</p><button type="button" class="btn btn-fill" data-ext="lineUrl" id="lineOrder">用 LINE 聯繫訂購</button>')+(PUB.pay?'<div class="pay"><span>信用卡</span><span>超商繳費</span><span>ATM 轉帳</span></div><p class="mfoot">按下「前往付款」後,會轉到綠界科技的付款頁面,可用方式以該頁顯示為準。教材為實體書籍,付款成功後會寄到上方地址。</p>':'')+'</aside></div>';
    $$('[data-inc]',app).forEach(function(b){b.addEventListener('click',function(){var id=b.getAttribute('data-inc');if(S.cart[id]<20)S.cart[id]++;save();refreshBadge();render()})});
    $$('[data-dec]',app).forEach(function(b){b.addEventListener('click',function(){var id=b.getAttribute('data-dec');S.cart[id]--;if(S.cart[id]<1)delete S.cart[id];save();refreshBadge();render()})});
    $$('[data-rm]',app).forEach(function(b){b.addEventListener('click',function(){delete S.cart[b.getAttribute('data-rm')];save();refreshBadge();render()})});
    function readRc(){return {name:($('#rName')||{}).value||'',phone:($('#rPhone')||{}).value||'',address:($('#rAddr')||{}).value||'',note:($('#rNote')||{}).value||''}}
    ['rName','rPhone','rAddr','rNote'].forEach(function(id){var el=$('#'+id);if(el)el.addEventListener('input',function(){saveRc(readRc())})});
    var lo=$('#lineOrder');if(lo)lo.addEventListener('click',function(){ext('lineUrl')});
    var gp=$('#goPay');if(gp)gp.addEventListener('click',function(){
      var r=readRc(),err=$('#cartErr');err.textContent='';
      if(!U){askLogin('登入後即可結帳(購物車與收件資料會保留)');return}
      if(needShip){
        if(r.name.trim().length<2){err.textContent='請填寫收件人姓名。';return}
        if(!/^[0-9+\-\s()]{8,20}$/.test(r.phone.trim())){err.textContent='請填寫正確的手機號碼。';return}
        if(r.address.trim().length<6){err.textContent='請填寫完整的收件地址。';return}
      }
      checkout({type:'cart',items:ids.map(function(id){return {id:id,qty:S.cart[id]}}),recipient:needShip?{name:r.name.trim(),phone:r.phone.trim(),address:r.address.trim()}:undefined,note:r.note.trim()||undefined},this,err);
    });
  }
  onAuth.push(render);render();
}

/* ---------- 免費資源 ---------- */
function initRes(){
  var btns=$$('[data-res]');if(!btns.length)return;
  function render(){btns.forEach(function(b){
    var id=b.getAttribute('data-res'),gated=b.getAttribute('data-gate')==='1',tagEl=$('#tag-'+id);
    if(!gated)return;
    var done=!!CLAIMED[id];
    b.firstChild.nodeValue=done?'下載 ':(U?'立即領取 ':'加入會員領取 ');
    b.classList.toggle('done',done);
    if(tagEl)tagEl.textContent=U?(done?'已領取':'已解鎖'):'會員限定';
  })}
  async function download(id){
    var r=PUB.resources[id];
    if(!r||!r.storage_path){toast('檔案還在準備中,上傳後會在這裡提供下載');return}
    var s=await sb.storage.from('resources').createSignedUrl(r.storage_path,120);
    if(s.error||!s.data){toast('下載失敗,請稍後再試');return}
    window.open(s.data.signedUrl,'_blank','noopener');
  }
  async function claim(id){
    if(!CLAIMED[id]){
      var r=await sb.from('resource_claims').insert({user_id:U.id,resource_id:id});
      if(r.error&&!/duplicate/i.test(r.error.message||'')){toast(niceErr(r.error));return}
      CLAIMED[id]=true;render();toast('已加入你的資源');
    }
    await download(id);
  }
  INTENT.claim=claim;
  btns.forEach(function(b){b.addEventListener('click',function(){
    var id=b.getAttribute('data-res');
    if(b.getAttribute('data-gate')!=='1'){window.open(b.getAttribute('data-href'),'_blank','noopener');return}
    if(!U){askLogin('登入後即可領取這份資源',{act:'claim',arg:id});return}
    claim(id);
  })});
  onAuth.push(render);render();
}

/* ---------- 作文:共用 ---------- */
var upFiles=[],upUrls=[],MAXF=6,MAXMB=10;
var OK_MIME={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
function clearThumbs(){upUrls.forEach(function(u){URL.revokeObjectURL(u)});upUrls=[];upFiles=[]}
function checkFile(f,list){
  if(!OK_MIME[f.type])return /\.(heic|heif)$/i.test(f.name)||/heic|heif/.test(f.type)?'「'+f.name+'」是 HEIC 格式,請改用 JPG 或 PNG(iPhone 可從相簿直接選取,系統會自動轉成 JPG)。':'只能上傳 JPG、PNG 或 WebP 圖片。';
  if(f.size>MAXMB*1024*1024)return '「'+f.name+'」超過 '+MAXMB+' MB,請縮小後再上傳。';
  if(list.length>=MAXF)return '最多上傳 '+MAXF+' 張。';
  return '';
}
var uuid=function(){return (window.crypto&&crypto.randomUUID)?crypto.randomUUID():'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){var r=Math.random()*16|0;return (c==='x'?r:(r&3|8)).toString(16)})};
/* 建立作文 + 上傳照片。失敗會自動清除半成品 */
async function submitEssay(row,files,kindPrefix){
  var id=uuid();
  var ins=await sb.from('essays').insert(Object.assign({id:id},row));
  if(ins.error)throw ins.error;
  var paths=[];
  try{
    for(var i=0;i<files.length;i++){
      var path=id+'/submission-'+(i+1)+'.'+OK_MIME[files[i].type];
      var up=await sb.storage.from('essays').upload(path,files[i],{contentType:files[i].type,upsert:false});
      if(up.error)throw up.error;
      paths.push(path);
    }
    var fr=await sb.from('essay_files').insert(paths.map(function(p,i){return {essay_id:id,path:p,page_no:i+1,kind:'submission'}}));
    if(fr.error)throw fr.error;
  }catch(e){
    try{if(paths.length)await sb.storage.from('essays').remove(paths)}catch(_){}
    try{await sb.from('essays').delete().eq('id',id)}catch(_){}
    throw e;
  }
  return id;
}
async function signedMap(paths){
  var out={};if(!paths.length)return out;
  var r=await sb.storage.from('essays').createSignedUrls(paths,3600);
  (r.data||[]).forEach(function(x){if(x&&x.signedUrl)out[x.path]=x.signedUrl});
  return out;
}
var STATUS_ES={pending:'待批改',graded:'已批改'};
/* 作文自動辨識:先交給後端(Google 辨識,每月有額度);額度用完或失敗時,改用瀏覽器內的免費辨識(Tesseract.js) */
var TESS_URL='https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
function loadTess(){
  if(window.Tesseract)return Promise.resolve(window.Tesseract);
  return new Promise(function(res,rej){var s=document.createElement('script');s.src=TESS_URL;s.onload=function(){window.Tesseract?res(window.Tesseract):rej(new Error('tess'))};s.onerror=function(){rej(new Error('tess'))};document.head.appendChild(s)});
}
function cleanOcr(t){
  var C='[\\u3400-\\u9fff\\uf900-\\ufaff\\u3000-\\u303f\\uff00-\\uffef\\u2014\\u2026,.;:!?]';
  t=String(t||'').replace(/\r/g,'').replace(/[ \t]+\n/g,'\n').replace(/\n[ \t]+/g,'\n');
  t=t.replace(new RegExp('('+C+')[ \\t]+(?='+C+')','g'),'$1');
  t=t.replace(new RegExp('('+C+')[ \\t]*\\n(?='+C+')','g'),'$1');
  return t.replace(/\n[ \t]+/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
}
async function clientOcr(id,say){
  var f=await sb.from('essay_files').select('path,page_no').eq('essay_id',id).eq('kind','submission').order('page_no');
  var rows=(f.data||[]).filter(function(r){return /\.(jpe?g|png|webp)$/i.test(r.path)}).slice(0,8);
  if(!rows.length)return '';
  var sm=await signedMap(rows.map(function(r){return r.path}));
  if(say)say('載入辨識工具…');
  var T=await loadTess(),w=await T.createWorker('chi_tra'),out=[];
  try{
    for(var i=0;i<rows.length;i++){
      if(!sm[rows[i].path])continue;
      if(say)say('簡易辨識中('+(i+1)+'/'+rows.length+')…');
      var r=await w.recognize(sm[rows[i].path]);
      out.push(cleanOcr(r&&r.data&&r.data.text));
    }
  }finally{try{await w.terminate()}catch(_){}}
  return out.filter(Boolean).join('\n');
}
function transcribeEssay(id,say){
  return (async function(){
    try{
      var r=await sb.functions.invoke('transcribe-essay',{body:{essay_id:id}});
      if(r&&r.error)return false;
      var d=r&&r.data;
      if(d&&d.fallback==='client'){
        var txt=await clientOcr(id,say);
        if(!txt)return false;
        var r2=await sb.functions.invoke('transcribe-essay',{body:{essay_id:id,save_text:txt}});
        return !(r2&&r2.error);
      }
      return true;
    }catch(_){return false}
  })();
}
var TX_NOTE={vision:'由 Google 文字辨識自動轉出,可能有誤字,以照片為準。',tesseract:'由瀏覽器簡易辨識轉出,錯字會比較多,以照片為準,老師會再校正。',manual:'老師已校正。'};
var UNSEEN=0;
async function fetchMyEssays(){
  var r=await sb.from('essays').select('id,title,grade,status,feedback,created_at,graded_at,score,score_max,student_seen_at,transcript,transcript_status,transcript_engine,essay_files(path,kind,page_no)').eq('student_id',U.id).order('created_at',{ascending:false});
  return r.data||[];
}
function scoreTx(e){return e&&e.score!=null&&e.score_max!=null?(+e.score)+' / '+(+e.score_max):''}
function dateShort(t){var d=new Date(t);return (d.getMonth()+1)+'/'+d.getDate()}

function initEssay(){
  var p=$('#uPanel');if(!p)return;
  var seq=0;
  async function listMine(){
    var box=$('#myEssays');if(!box)return;
    if(!U){box.innerHTML='<li class="none">登入後可以看到你的上傳紀錄</li>';return}
    var my=++seq,es=await fetchMyEssays();if(my!==seq)return;
    box.innerHTML=es.length?es.map(function(e){var n=e.essay_files.filter(function(f){return f.kind==='submission'}).length;return '<li><span>'+esc(e.title)+'('+esc(e.grade||'')+'・'+n+' 張・'+dateShort(e.created_at)+')</span><em>'+STATUS_ES[e.status]+(scoreTx(e)?'・'+scoreTx(e)+' 分':'')+'</em></li>'}).join(''):'<li class="none">還沒有上傳紀錄</li>';
  }
  function render(){
    if(!ready){p.innerHTML='<h3>上傳作文</h3><p class="lead">載入中…</p>';return}
    if(!U){
      clearThumbs();
      p.innerHTML='<h3>上傳作文</h3><p class="lead">登入後即可上傳,上傳的作文僅供本人與老師查看。</p><div class="lockmask"><svg class="ico" style="width:32px;height:32px;color:var(--bronze-text)"><use href="#i-lock"/></svg><p>請先使用 Google 帳號登入</p><button type="button" class="btn btn-fill" id="upLogin">使用 Google 帳號登入</button></div>';
      $('#upLogin').addEventListener('click',function(){askLogin('登入後即可上傳作文')});
      listMine();return;
    }
    p.innerHTML='<h3>上傳作文</h3><p class="lead">上傳的作文僅供本人與老師查看。</p>'+
     '<form id="upForm" novalidate><div class="row2"><label class="fld" for="upTitle">作文題目<input id="upTitle" placeholder="例如:溫暖的心" maxlength="60"></label><label class="fld" for="upGrade">年級<select id="upGrade"><option>國一</option><option>國二</option><option>國三</option><option>高一</option><option>高二</option><option selected>高三</option><option>其他</option></select></label></div>'+
     '<label class="drop" id="drop" for="upFile">'+ico('i-upload')+'<span><b>點選選擇照片</b>,或把照片拖曳到這裡</span><span style="font-size:12.5px">最多 '+MAXF+' 張・每張 '+MAXMB+' MB 以內・JPG / PNG / WebP</span><input id="upFile" type="file" accept="image/jpeg,image/png,image/webp" multiple></label>'+
     '<div class="thumbs" id="thumbs"></div>'+
     '<div class="tips"><span>光線充足</span><span>整頁入鏡</span><span>避免反光與陰影</span><span>依頁碼順序上傳</span></div>'+
     '<label class="fld" for="upNote" style="margin-top:8px">給老師的話(選填)<textarea id="upNote" maxlength="500" placeholder="例如:想加強結尾的收束"></textarea></label>'+
     '<div class="err" id="upErr" role="alert"></div><button class="btn btn-fill" type="submit" id="upGo">送出批改</button></form>';
    var inp=$('#upFile'),drop=$('#drop');
    function drawThumbs(){
      $('#thumbs').innerHTML=upUrls.map(function(u,i){return '<div class="th"><img src="'+u+'" alt="作文第 '+(i+1)+' 頁"><button type="button" data-rmf="'+i+'" aria-label="移除第 '+(i+1)+' 張">×</button></div>'}).join('');
      $$('[data-rmf]',p).forEach(function(b){b.addEventListener('click',function(){var i=+b.getAttribute('data-rmf');URL.revokeObjectURL(upUrls[i]);upUrls.splice(i,1);upFiles.splice(i,1);drawThumbs()})});
    }
    function addFiles(list){
      var err=$('#upErr');err.textContent='';
      Array.prototype.forEach.call(list,function(f){var m=checkFile(f,upFiles);if(m){err.textContent=m;return}upFiles.push(f);upUrls.push(URL.createObjectURL(f))});
      drawThumbs();
    }
    inp.addEventListener('change',function(){addFiles(inp.files);inp.value=''});
    ['dragenter','dragover'].forEach(function(ev){drop.addEventListener(ev,function(e){e.preventDefault();drop.classList.add('over')})});
    ['dragleave','drop'].forEach(function(ev){drop.addEventListener(ev,function(e){e.preventDefault();drop.classList.remove('over')})});
    drop.addEventListener('drop',function(e){if(e.dataTransfer)addFiles(e.dataTransfer.files)});
    drawThumbs();
    $('#upForm').addEventListener('submit',async function(e){
      e.preventDefault();var err=$('#upErr'),t=$('#upTitle').value.trim(),go=$('#upGo');
      if(!t){err.textContent='請填寫作文題目。';return}
      if(!upFiles.length){err.textContent='請至少上傳一張作文照片。';return}
      go.disabled=true;go.textContent='上傳中…';err.textContent='';
      try{
        var newId=await submitEssay({student_id:U.id,created_by:U.id,source:'student',title:t,grade:$('#upGrade').value,note:$('#upNote').value.trim()||null,status:'pending'},upFiles);
        transcribeEssay(newId);
        var n=upFiles.length;clearThumbs();render();toast('已收到「'+t+'」共 '+n+' 張,老師批改後可在會員專區查看');
      }catch(ex){err.textContent='上傳失敗:'+niceErr(ex);go.disabled=false;go.textContent='送出批改'}
    });
    listMine();
  }
  onAuth.push(render);render();
}

/* ---------- 會員專區 ---------- */
var FUL={none:'',to_ship:'準備寄出',shipped:'已寄出',done:'已完成'};
var ORD_ST={pending:'待付款',paid:'已付款',failed:'付款失敗',cancelled:'已取消'};
var ORD_KIND={product:'教材',course:'課程',membership:'付費會員'};
function initMember(){
  var app=$('#memberApp');if(!app)return;
  var tab='c',payMsg='',paying=false,rendering=0;
  async function checkPay(){
    var tn=new URLSearchParams(location.search).get('pay');
    if(!tn||!/^[A-Za-z0-9]{1,20}$/.test(tn)||paying)return;
    paying=true;tab='o';
    payMsg='<div class="paynote" role="status">確認付款結果中…</div>';render();
    var o=null;
    for(var i=0;i<20;i++){
      var r=await sb.from('orders').select('status,kind,amount').eq('merchant_trade_no',tn).maybeSingle();
      o=r.data;if(o&&o.status!=='pending')break;
      await sleep(2000);
    }
    try{history.replaceState(null,'',location.pathname)}catch(e){}
    if(o&&o.status==='paid'){
      await loadMine();
      if(o.kind==='product'){S.cart={};save();refreshBadge();syncAddBtns()}
      payMsg='<div class="paynote ok" role="status">付款成功!'+(o.kind==='membership'?'已自動開通付費會員,可以到直播專區收看。':o.kind==='course'?'課程已開通,可到「我的課程」進入學習。':'我們會盡快寄出教材,出貨進度可在下方訂單查看。')+'</div>';
    }else if(o&&(o.status==='failed'||o.status==='cancelled')){
      payMsg='<div class="paynote bad" role="status">付款沒有成功,你可以回到網站重新下單。如有疑問請聯繫我們。</div>';
    }else{
      payMsg='<div class="paynote" role="status">尚未收到款項。若你選的是超商或 ATM 付款,完成繳費後這裡會自動更新;若已刷卡成功,請稍候幾分鐘再重新整理。</div>';
    }
    paying=false;render();
  }
  async function render(){
    var my=++rendering;
    if(!ready){app.innerHTML='<div class="gate"><p>載入中…</p></div>';return}
    if(!U){
      app.innerHTML='<div class="gate"><h2>登入會員</h2><p>使用 Google 帳號登入,即可查看你的課程、作文批改與資源。</p><button type="button" class="gbtn" id="gLogin2" style="max-width:340px;margin:0 auto"><span class="g" aria-hidden="true">G</span>使用 Google 帳號登入</button><p class="mfoot">不需要另外設定密碼。</p></div>';
      $('#gLogin2').addEventListener('click',function(){askLogin()});return;
    }
    if(tab!=='e'){try{var ur=await sb.from('essays').select('id,status,student_seen_at').eq('student_id',U.id).eq('status','graded');UNSEEN=(ur.data||[]).filter(function(x){return !x.student_seen_at}).length}catch(_){UNSEEN=0}if(my!==rendering)return}
    var body='';
    if(tab==='c'){
      var cs=Object.keys(ENR).map(function(id){var c=byId(GW.courses,id);return c?'<li><a href="'+c.learn+'">'+esc(c.name)+'</a><em>前往學習</em></li>':''}).join('')||'<li class="none">尚未報名課程。<a href="courses.html" style="text-decoration:underline;margin-left:6px">看看線上課程</a></li>';
      body='<h2>我的課程</h2><ul class="mlist">'+cs+'</ul>';
    }else if(tab==='e'){
      var es=await fetchMyEssays();if(my!==rendering)return;
      var fpaths=[];es.forEach(function(e){e.essay_files.forEach(function(f){fpaths.push(f.path)})});
      var sm=await signedMap(fpaths);if(my!==rendering)return;
      if(es.some(function(x){return x.status==='graded'&&!x.student_seen_at})){sb.rpc('mark_essays_seen').then(function(){UNSEEN=0})}
      body='<h2>我的作文</h2><ul class="mlist">'+(es.map(function(e){
        var fb=e.status==='graded'?'<div class="fbk">'+(scoreTx(e)?'<div class="scorebox"><span>分數</span><b>'+esc(scoreTx(e))+'</b></div>':'')+'<b>老師評語</b><p>'+esc(e.feedback||'(老師已批改,沒有文字評語)').replace(/\n/g,'<br>')+'</p>'+e.essay_files.filter(function(f){return f.kind==='feedback'&&sm[f.path]}).sort(function(a,b){return a.page_no-b.page_no}).map(function(f){return '<a href="'+sm[f.path]+'" target="_blank" rel="noopener"><img src="'+sm[f.path]+'" alt="老師批改照片" loading="lazy"></a>'}).join('')+'</div>':'';
        var subs=e.essay_files.filter(function(f){return f.kind==='submission'}).sort(function(a,b){return a.page_no-b.page_no});
        var n=subs.length;
        var imgs=subs.filter(function(f){return sm[f.path]}).map(function(f,i){return '<a href="'+sm[f.path]+'" target="_blank" rel="noopener"><img src="'+sm[f.path]+'" alt="作文第 '+(i+1)+' 頁" loading="lazy"></a>'}).join('');
        var tx;
        if(e.transcript_status==='done'&&e.transcript)tx='<b>作文文字</b><span class="tnote">'+esc(TX_NOTE[e.transcript_engine]||TX_NOTE.vision)+'</span><div class="ttext">'+esc(e.transcript).replace(/\n/g,'<br>')+'</div>';
        else if(e.transcript_status==='pending')tx='<b>作文文字</b><p class="tnote">辨識中,請稍後切換分頁再看。</p>';
        else tx='<b>作文文字</b><p class="tnote">尚未辨識。</p><button type="button" class="btn btn-line sm" data-retx="'+e.id+'">自動辨識</button>';
        return '<li class="col"><div class="l1"><span>'+esc(e.title)+'('+esc(e.grade||'')+'・'+n+' 張・'+dateShort(e.created_at)+')</span><em>'+(e.status==='graded'&&!e.student_seen_at?'<span class="newpill">新批改</span>':'')+STATUS_ES[e.status]+'</em></div><div class="ecols"><div class="eimgs">'+imgs+'</div><div class="etext">'+tx+'</div></div>'+fb+'</li>'}).join('')||'<li class="none">尚未上傳作文。<a href="essay.html" style="text-decoration:underline;margin-left:6px">前往作文批改</a></li>')+'</ul>';
    }else if(tab==='r'){
      var rs=Object.keys(CLAIMED).map(function(id){var r=PUB.resources[id];return r?'<li><span>'+esc(r.name)+'</span><em><button type="button" class="more" data-dl="'+esc(id)+'">下載</button></em></li>':''}).join('')||'<li class="none">尚未領取資源。<a href="resources.html" style="text-decoration:underline;margin-left:6px">免費資源</a></li>';
      body='<h2>我的資源</h2><ul class="mlist">'+rs+'</ul>';
    }else if(tab==='o'){
      var r=await sb.from('orders').select('id,merchant_trade_no,kind,status,amount,plan_id,course_id,fulfillment,created_at,order_items(name,qty)').eq('user_id',U.id).order('created_at',{ascending:false});
      if(my!==rendering)return;
      body='<h2>我的訂單</h2><ul class="mlist">'+((r.data||[]).map(function(o){
        var what=o.kind==='product'?(o.order_items||[]).map(function(i){return esc(i.name)+' × '+i.qty}).join('、'):o.kind==='membership'?'付費會員('+esc(planName(o.plan_id))+')':esc((byId(GW.courses,o.course_id)||{}).name||'線上課程');
        var ful=o.kind==='product'&&o.status==='paid'&&FUL[o.fulfillment]?'・'+FUL[o.fulfillment]:'';
        return '<li class="col"><div class="l1"><span>'+what+'</span><em>'+ORD_ST[o.status]+ful+'</em></div><small class="sub">'+fmtDate(o.created_at)+'・'+money(o.amount)+'・訂單 '+esc(o.merchant_trade_no)+'</small></li>'}).join('')||'<li class="none">還沒有訂單。</li>')+'</ul>';
    }else{
      var on=isMember();
      body='<h2>帳號</h2><ul class="mlist"><li><span>登入方式</span><em>Google 帳號</em></li><li><span>會員等級</span><em>'+(on?'付費會員':'免費會員')+'</em></li>'+(MEM?'<li><span>方案</span><em>'+(MEM.plan?esc(planName(MEM.plan))+'・':'')+(MEM.status==='cancelled'?'已取消續約・':'')+'有效至 '+fmtDate(MEM.valid_until)+'</em></li>':'')+'</ul><p style="color:var(--text-soft);font-size:14px;margin-bottom:14px">'+(on?'你可以到直播專區進入會員限定直播。':'付費會員可觀看會員限定直播,在網站付款後自動開通。<a href="membership.html" style="text-decoration:underline;margin-left:4px">了解付費會員</a>')+'</p>'+
        (on&&MEM.status==='active'&&MEM.plan?'<button type="button" class="btn btn-line" id="cancelSub">取消續約</button> ':'')+(isAdmin()?'<a class="btn btn-line" href="admin.html">老師後台</a> ':'')+'<button type="button" class="btn btn-line" id="logoutBtn">登出</button>';
    }
    app.innerHTML=payMsg+'<div class="profile"><span class="av">'+esc((U.name||'?').charAt(0).toUpperCase())+'</span><div><b>'+esc(U.name)+'</b><small>'+esc(U.email)+'</small></div></div>'+
     '<div class="tabs mtabs" role="tablist">'+[['c','我的課程'],['e','我的作文'],['r','我的資源'],['o','我的訂單'],['a','帳號']].map(function(t){return '<button type="button" role="tab" data-t="'+t[0]+'" aria-selected="'+(tab===t[0])+'">'+t[1]+(t[0]==='e'&&UNSEEN>0&&tab!=='e'?' <span class="newpill">'+UNSEEN+'</span>':'')+'</button>'}).join('')+'</div><div class="panel">'+body+'</div>';
    $$('[data-t]',app).forEach(function(b){b.addEventListener('click',function(){tab=b.getAttribute('data-t');render()})});
    $$('[data-dl]',app).forEach(function(b){b.addEventListener('click',async function(){
      var rr=PUB.resources[b.getAttribute('data-dl')];
      if(!rr||!rr.storage_path){toast('檔案還在準備中');return}
      var s=await sb.storage.from('resources').createSignedUrl(rr.storage_path,120);
      if(s.data)window.open(s.data.signedUrl,'_blank','noopener');else toast('下載失敗,請稍後再試');
    })});
    $$('[data-retx]',app).forEach(function(b){b.addEventListener('click',async function(){
      b.disabled=true;b.textContent='辨識中…';
      var ok=await transcribeEssay(b.getAttribute('data-retx'),function(m){b.textContent=m});
      toast(ok?'辨識完成':'辨識暫時失敗,請稍後再試');render();
    })});
    var lo=$('#logoutBtn');if(lo)lo.addEventListener('click',signOut);
    var cs2=$('#cancelSub');
    if(cs2)cs2.addEventListener('click',function(){
      openModal('<h3 id="mTitle">取消續約</h3><p class="lead">取消後不會再自動扣款,已付款的期間(到 '+fmtDate(MEM.valid_until)+')仍可繼續使用。</p><div class="err" id="cxErr" role="alert"></div><button type="button" class="btn btn-fill" id="cxGo" style="width:100%">確認取消續約</button>',function(){
        $('#cxGo').addEventListener('click',async function(){
          this.disabled=true;
          try{await callFn('cancel-membership',{});await loadMine();closeDlg(modal);toast('已取消續約');fire()}
          catch(e){$('#cxErr').textContent=niceErr(e);this.disabled=false}
        });
      });
    });
  }
  onAuth.push(function(){render();checkPay()});render();
}

/* ---------- 老師後台 ---------- */
function parseYt(v){return ytId(v)}
function initAdmin(){
  var app=$('#adminApp');if(!app)return;
  var aTab='e',tf={who:'',title:'',grade:'國三',open:false},tFiles=[],tUrls=[],names={};
  function clearT(){tUrls.forEach(function(u){URL.revokeObjectURL(u)});tUrls=[];tFiles=[]}
  function nm(id){return id&&names[id]?names[id].name||names[id].email:'(未知)'}
  async function loadNames(){var r=await sb.from('profiles').select('id,name,email,created_at,role');(r.data||[]).forEach(function(x){names[x.id]=x});return r.data||[]}
  async function count(table,filter){var q=sb.from(table).select('id',{count:'exact',head:true});if(filter)q=filter(q);var r=await q;return r.count||0}

  async function render(){
    if(!ready){app.innerHTML='<div class="gate"><p>載入中…</p></div>';return}
    if(!U){app.innerHTML='<div class="gate"><h2>老師後台</h2><p>請使用老師的 Google 帳號登入。</p><button type="button" class="btn btn-fill" id="admLogin">使用 Google 帳號登入</button></div>';$('#admLogin').addEventListener('click',function(){askLogin('請用老師的 Google 帳號登入後台')});return}
    if(!isAdmin()){app.innerHTML='<div class="gate"><h2>沒有權限</h2><p>這個帳號('+esc(U.email)+')不是老師帳號。</p><a class="btn btn-line" href="member.html">回會員專區</a></div>';return}
    app.innerHTML='<div class="tiles" id="tiles"></div><div class="tabs" role="tablist" style="max-width:860px">'+[['e','作文批改'],['o','訂單'],['m','會員'],['p','教材'],['c','課程'],['l','直播'],['s','設定']].map(function(t){return '<button type="button" role="tab" data-at="'+t[0]+'" aria-selected="'+(aTab===t[0])+'">'+t[1]+'</button>'}).join('')+'</div><div class="panel" id="aBody"><p>載入中…</p></div><p class="mfoot"><button type="button" class="more" id="admOut">登出</button></p>';
    $$('[data-at]',app).forEach(function(b){b.addEventListener('click',function(){aTab=b.getAttribute('data-at');render()})});
    $('#admOut').addEventListener('click',signOut);
    tiles();
    var body=$('#aBody');
    try{await TABS[aTab](body)}catch(e){body.innerHTML='<p class="err">讀取失敗:'+esc(niceErr(e))+'</p>'}
  }
  async function tiles(){
    var c=await Promise.all([count('essays',function(q){return q.eq('status','pending')}),count('orders',function(q){return q.eq('status','paid').eq('fulfillment','to_ship')}),count('memberships',function(q){return q.eq('status','active')})]);
    var t=$('#tiles');if(t)t.innerHTML='<div class="tile"><b>'+c[0]+'</b><span>待批改作文</span></div><div class="tile"><b>'+c[1]+'</b><span>待出貨訂單</span></div><div class="tile"><b>'+c[2]+'</b><span>訂閱中的會員</span></div>';
  }
  var TABS={};

  /* --- 作文 --- */
  TABS.e=async function(body){
    await loadNames();
    var r=await sb.from('essays').select('id,student_id,source,source_note,title,grade,note,status,feedback,created_at,score,score_max,transcript,transcript_status,transcript_engine').order('status',{ascending:false}).order('created_at',{ascending:false}).limit(150);
    var rows=r.data||[];
    var h='<div class="upanel" id="tPanel" style="margin-bottom:18px"><div style="display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap"><div><h3>老師自行上傳作文</h3><p class="lead" style="margin-bottom:0">手邊額外需要批閱的作文,可以直接上傳,和學生送來的作文一起排進待批改。</p></div><button type="button" class="btn btn-line sm" id="tToggle" aria-expanded="'+tf.open+'">'+(tf.open?'收合':'＋ 上傳作文')+'</button></div>';
    if(tf.open){
      h+='<form id="tForm" novalidate style="margin-top:16px"><div class="row2"><label class="fld" for="tWho">學生或來源備註(選填)<input id="tWho" placeholder="例如:王同學、班級作業" maxlength="40" value="'+esc(tf.who)+'"></label><label class="fld" for="tGrade">年級<select id="tGrade">'+['國一','國二','國三','高一','高二','高三','其他'].map(function(g){return '<option'+(g===tf.grade?' selected':'')+'>'+g+'</option>'}).join('')+'</select></label></div>'+
       '<label class="fld" for="tTitle" style="margin-bottom:12px">作文題目<input id="tTitle" placeholder="例如:溫暖的心" maxlength="60" value="'+esc(tf.title)+'"></label>'+
       '<label class="drop" id="tDrop" for="tFile">'+ico('i-upload')+'<span><b>點選選擇照片</b>,或把照片拖曳到這裡</span><span style="font-size:12.5px">最多 '+MAXF+' 張・每張 '+MAXMB+' MB 以內・JPG / PNG / WebP</span><input id="tFile" type="file" accept="image/jpeg,image/png,image/webp" multiple></label>'+
       '<div class="thumbs" id="tThumbs">'+tUrls.map(function(u,i){return '<div class="th"><img src="'+u+'" alt="作文第 '+(i+1)+' 頁"><button type="button" data-trm="'+i+'" aria-label="移除第 '+(i+1)+' 張">×</button></div>'}).join('')+'</div>'+
       '<div class="err" id="tErr" role="alert" style="margin-top:8px"></div><button class="btn btn-fill" type="submit" id="tGo">加入待批改</button></form>';
    }
    h+='</div><div class="twrap"><table class="tbl"><thead><tr><th>學生</th><th>題目</th><th>年級</th><th>來源</th><th>日期</th><th>狀態</th><th></th></tr></thead><tbody>'+
      rows.map(function(e){var teacher=e.source==='teacher';
        return '<tr><td>'+esc(teacher?(e.source_note||'(老師自行上傳)'):nm(e.student_id))+'</td><td>'+esc(e.title)+'</td><td>'+esc(e.grade||'')+'</td><td><span class="pill'+(teacher?' ok':'')+'">'+(teacher?'老師上傳':'學生上傳')+'</span></td><td>'+dateShort(e.created_at)+'</td><td><span class="pill '+(e.status==='pending'?'warn':'ok')+'">'+STATUS_ES[e.status]+'</span>'+(scoreTx(e)?' <small>'+esc(scoreTx(e))+'</small>':'')+'</td><td><button type="button" class="btn btn-line sm" data-gr="'+e.id+'">'+(e.status==='pending'?'批改':'查看')+'</button></td></tr>'}).join('')+(rows.length?'':'<tr><td colspan="7" class="none">還沒有作文</td></tr>')+'</tbody></table></div>';
    body.innerHTML=h;
    var tt=$('#tToggle');tt.addEventListener('click',function(){tf.open=!tf.open;render()});
    var tForm=$('#tForm');
    if(tForm){
      $('#tWho').addEventListener('input',function(){tf.who=this.value});$('#tTitle').addEventListener('input',function(){tf.title=this.value});$('#tGrade').addEventListener('change',function(){tf.grade=this.value});
      var tfi=$('#tFile'),td=$('#tDrop');
      function tAdd(list){var er=$('#tErr');er.textContent='';
        Array.prototype.forEach.call(list,function(f){var m=checkFile(f,tFiles);if(m){er.textContent=m;return}tFiles.push(f);tUrls.push(URL.createObjectURL(f))});
        TABS.e(body);
      }
      tfi.addEventListener('change',function(){tAdd(tfi.files);tfi.value=''});
      ['dragenter','dragover'].forEach(function(ev){td.addEventListener(ev,function(e){e.preventDefault();td.classList.add('over')})});
      ['dragleave','drop'].forEach(function(ev){td.addEventListener(ev,function(e){e.preventDefault();td.classList.remove('over')})});
      td.addEventListener('drop',function(e){if(e.dataTransfer)tAdd(e.dataTransfer.files)});
      $$('[data-trm]',body).forEach(function(b){b.addEventListener('click',function(){var i=+b.getAttribute('data-trm');URL.revokeObjectURL(tUrls[i]);tUrls.splice(i,1);tFiles.splice(i,1);TABS.e(body)})});
      tForm.addEventListener('submit',async function(e){
        e.preventDefault();var er=$('#tErr'),t=$('#tTitle').value.trim(),go=$('#tGo');
        if(!t){er.textContent='請填寫作文題目。';return}
        if(!tFiles.length){er.textContent='請至少上傳一張作文照片。';return}
        go.disabled=true;go.textContent='上傳中…';
        try{
          var tId=await submitEssay({student_id:null,created_by:U.id,source:'teacher',source_note:$('#tWho').value.trim()||null,title:t,grade:$('#tGrade').value,status:'pending'},tFiles);
          transcribeEssay(tId);
          var n=tFiles.length;clearT();tf.who='';tf.title='';tf.open=false;toast('已加入「'+t+'」共 '+n+' 張,列在待批改');render();
        }catch(ex){er.textContent='上傳失敗:'+niceErr(ex);go.disabled=false;go.textContent='加入待批改'}
      });
    }
    $$('[data-gr]',body).forEach(function(b){b.addEventListener('click',function(){openGrade(b.getAttribute('data-gr'),rows)})});
  };
  async function openGrade(id,rows){
    var e=rows.filter(function(x){return x.id===id})[0];if(!e)return;
    var fr=await sb.from('essay_files').select('path,kind,page_no').eq('essay_id',id).order('page_no');
    var files=fr.data||[],sm=await signedMap(files.map(function(f){return f.path}));
    var subs=files.filter(function(f){return f.kind==='submission'}),fbs=files.filter(function(f){return f.kind==='feedback'});
    var fpick=[],TPL=[],tplEdit=false;
    try{var tr=await sb.from('feedback_templates').select('id,label,body,sort_order').order('sort_order');TPL=tr.data||[]}catch(_){}
    var lastMax='';try{lastMax=localStorage.getItem('gw-score-max')||''}catch(_){}
    var maxV=e.score_max!=null?e.score_max:(lastMax||60);
    openModal('<h3 id="mTitle">'+esc(e.title)+'</h3><p class="lead">'+esc(e.source==='teacher'?(e.source_note||'老師自行上傳'):nm(e.student_id))+'・'+esc(e.grade||'')+'・'+fmtDate(e.created_at)+'</p>'+
      (e.note?'<p class="gnote"><b>學生留言:</b>'+esc(e.note)+'</p>':'')+
      '<div class="gimgs">'+subs.map(function(f,i){return sm[f.path]?'<a href="'+sm[f.path]+'" target="_blank" rel="noopener"><img src="'+sm[f.path]+'" alt="作文第 '+(i+1)+' 頁"></a>':''}).join('')+'</div>'+
      (fbs.length?'<p class="gnote"><b>已上傳的批改照片:</b></p><div class="gimgs">'+fbs.map(function(f){return sm[f.path]?'<a href="'+sm[f.path]+'" target="_blank" rel="noopener"><img src="'+sm[f.path]+'" alt="批改照片"></a>':''}).join('')+'</div>':'')+
      '<label class="fld" for="gTx">作文文字(自動辨識,可直接修改;學生也看得到)<textarea id="gTx" rows="8" maxlength="20000" placeholder="'+(e.transcript_status==='pending'?'辨識中…請稍後按「重新辨識」更新':'尚未辨識')+'">'+esc(e.transcript||'')+'</textarea></label><button type="button" class="btn btn-line sm" id="gRetx" style="margin:-4px 0 12px">重新辨識</button>'+
      '<div class="scoreRow"><label for="gScore">分數<input id="gScore" type="number" inputmode="decimal" min="0" max="100" step="0.5" value="'+(e.score!=null?e.score:'')+'" placeholder="例如 45"></label><span class="sl">/</span><label for="gMax">滿分<input id="gMax" type="number" inputmode="decimal" min="1" max="100" step="0.5" value="'+maxV+'"></label><small>不打分數就留空</small></div>'+
      '<div class="fld"><div class="tplHead"><span>評語範本(點一下插入)</span><button type="button" class="more" id="tplMng">管理</button></div><div class="tplRow" id="tplRow"></div></div>'+
      '<label class="fld" for="gFb">文字評語<textarea id="gFb" rows="6" maxlength="4000" placeholder="寫給學生的評語與建議">'+esc(e.feedback||'')+'</textarea></label>'+
      '<div class="tplSave"><button type="button" class="more" id="tplAdd">＋ 把目前評語存成範本</button><span id="tplForm" hidden><input id="tplLabel" maxlength="20" placeholder="範本名稱(20 字內)"> <button type="button" class="btn btn-line sm" id="tplOk">存</button></span></div>'+
      '<label class="fld" for="gFile">批改後的照片(選填,JPG / PNG / WebP)<input id="gFile" type="file" accept="image/jpeg,image/png,image/webp" multiple></label>'+
      '<div class="err" id="gErr" role="alert"></div><button type="button" class="btn btn-fill" id="gGo" style="width:100%">'+(e.status==='graded'?'更新評語':'儲存並標為已批改')+'</button>',function(){
        function drawTpl(){
          var row=$('#tplRow');if(!row)return;
          row.innerHTML=TPL.length?TPL.map(function(t){return '<span class="tplc"><button type="button" class="chip" data-tpl="'+t.id+'" title="'+esc(t.body)+'">'+esc(t.label)+'</button>'+(tplEdit?'<button type="button" class="tplx" data-tdel="'+t.id+'" aria-label="刪除範本 '+esc(t.label)+'">×</button>':'')+'</span>'}).join(''):'<span class="tnote">還沒有範本,寫好評語後可以存成範本。</span>';
          $$('[data-tpl]',row).forEach(function(b){b.addEventListener('click',function(){var t=TPL.filter(function(x){return String(x.id)===b.getAttribute('data-tpl')})[0];if(!t)return;var ta=$('#gFb');var cur=ta.value;ta.value=(cur&&!/\n$/.test(cur)?cur+'\n':cur)+t.body;if(ta.value.length>4000)ta.value=ta.value.slice(0,4000);ta.focus()})});
          $$('[data-tdel]',row).forEach(function(b){b.addEventListener('click',async function(){var id2=b.getAttribute('data-tdel');var dr=await sb.from('feedback_templates').delete().eq('id',+id2);if(dr.error){$('#gErr').textContent='刪除範本失敗:'+niceErr(dr.error);return}TPL=TPL.filter(function(x){return String(x.id)!==id2});drawTpl()})});
        }
        drawTpl();
        $('#tplMng').addEventListener('click',function(){tplEdit=!tplEdit;this.textContent=tplEdit?'完成':'管理';drawTpl()});
        $('#tplAdd').addEventListener('click',function(){var er=$('#gErr');if(!$('#gFb').value.trim()){er.textContent='先寫好評語,才能存成範本。';return}er.textContent='';$('#tplForm').hidden=false;$('#tplLabel').focus()});
        $('#tplOk').addEventListener('click',async function(){
          var er=$('#gErr'),lb=$('#tplLabel').value.trim(),bd=$('#gFb').value.trim();
          if(!lb){er.textContent='請幫範本取個名稱。';return}
          if(bd.length>1000){er.textContent='範本最多 1000 字,請縮短後再存。';return}
          var ins=await sb.from('feedback_templates').insert({label:lb,body:bd,sort_order:TPL.length+1}).select('id,label,body,sort_order');
          if(ins.error){er.textContent='存範本失敗:'+niceErr(ins.error);return}
          var row0=(ins.data&&ins.data[0])||null;if(row0)TPL.push(row0);
          $('#tplLabel').value='';$('#tplForm').hidden=true;er.textContent='';drawTpl();toast('已存成範本');
        });
        $('#gRetx').addEventListener('click',async function(){
          var bt=this;bt.disabled=true;bt.textContent='辨識中…';
          var ok=await transcribeEssay(id,function(m){bt.textContent=m});
          if(ok){var rr=await sb.from('essays').select('transcript,transcript_engine').eq('id',id).maybeSingle();if(rr.data){$('#gTx').value=rr.data.transcript||'';e.transcript=rr.data.transcript;e.transcript_status='done';e.transcript_engine=rr.data.transcript_engine}}
          else $('#gErr').textContent='辨識暫時失敗,請稍後再試。';
          bt.disabled=false;bt.textContent='重新辨識';
        });
        $('#gFile').addEventListener('change',function(){fpick=[];var er=$('#gErr');er.textContent='';Array.prototype.forEach.call(this.files,function(f){var m=checkFile(f,fpick);if(m){er.textContent=m;return}fpick.push(f)})});
        $('#gGo').addEventListener('click',async function(){
          var er=$('#gErr'),fb=$('#gFb').value.trim();
          if(!fb&&!fpick.length&&!fbs.length){er.textContent='請寫下評語,或上傳批改後的照片。';return}
          var sc=$('#gScore').value.trim(),mx=$('#gMax').value.trim(),scN=null,mxN=null;
          if(sc!==''){scN=+sc;mxN=+mx;if(!isFinite(scN)||!isFinite(mxN)||mx===''){er.textContent='請填寫分數與滿分。';return}if(mxN<1||mxN>100){er.textContent='滿分請填 1 到 100。';return}if(scN<0||scN>mxN){er.textContent='分數要在 0 到滿分之間。';return}}
          this.disabled=true;this.textContent='儲存中…';
          var up=[];
          try{
            var stamp=Date.now();
            for(var i=0;i<fpick.length;i++){
              var path=id+'/feedback-'+stamp+'-'+(i+1)+'.'+OK_MIME[fpick[i].type];
              var u=await sb.storage.from('essays').upload(path,fpick[i],{contentType:fpick[i].type,upsert:false});
              if(u.error)throw u.error;up.push(path);
            }
            if(up.length){var ir=await sb.from('essay_files').insert(up.map(function(p,i){return {essay_id:id,path:p,page_no:i+1,kind:'feedback'}}));if(ir.error)throw ir.error}
            var upd={status:'graded',feedback:fb||null,graded_at:new Date().toISOString(),graded_by:U.id,score:scN,score_max:scN==null?null:mxN,student_seen_at:null};
            var txv=$('#gTx').value.trim();
            if(txv!==(e.transcript||'').trim()){upd.transcript=txv||null;upd.transcript_status=txv?'done':'none';upd.transcript_engine=txv?'manual':null;upd.transcript_at=new Date().toISOString()}
            var ur=await sb.from('essays').update(upd).eq('id',id);
            if(ur.error)throw ur.error;
            if(scN!=null){try{localStorage.setItem('gw-score-max',String(mxN))}catch(_){}}
            var told=false;try{var nr=await callFn('notify-graded',{essay_id:id});told=!!(nr&&nr.ok&&!nr.already)}catch(_){}
            closeDlg(modal);toast(told?'已儲存批改,並寄信通知學生':'已儲存批改');render();
          }catch(ex){
            try{if(up.length)await sb.storage.from('essays').remove(up)}catch(_){}
            er.textContent='儲存失敗:'+niceErr(ex);this.disabled=false;this.textContent='儲存並標為已批改';
          }
        });
      });
  }

  /* --- 訂單 --- */
  TABS.o=async function(body){
    await loadNames();
    var r=await sb.from('orders').select('id,merchant_trade_no,user_id,kind,status,amount,plan_id,course_id,recipient_name,recipient_phone,recipient_address,note,fulfillment,created_at,order_items(name,qty)').order('created_at',{ascending:false}).limit(150);
    var rows=r.data||[];
    body.innerHTML='<div class="twrap"><table class="tbl"><thead><tr><th>日期</th><th>會員</th><th>內容</th><th>金額</th><th>付款</th><th>出貨</th></tr></thead><tbody>'+rows.map(function(o){
      var what=o.kind==='product'?(o.order_items||[]).map(function(i){return esc(i.name)+' × '+i.qty}).join('<br>'):o.kind==='membership'?'付費會員('+esc(planName(o.plan_id))+')':esc((byId(GW.courses,o.course_id)||{}).name||'線上課程');
      var rec=o.kind==='product'?'<details><summary>收件資料</summary>'+esc(o.recipient_name||'')+'<br>'+esc(o.recipient_phone||'')+'<br>'+esc(o.recipient_address||'')+(o.note?'<br>備註:'+esc(o.note):'')+'</details>':'';
      var ship=o.kind==='product'&&o.status==='paid'?'<select data-ful="'+o.id+'">'+['to_ship','shipped','done'].map(function(v){return '<option value="'+v+'"'+(o.fulfillment===v?' selected':'')+'>'+FUL[v]+'</option>'}).join('')+'</select>':'—';
      return '<tr><td>'+fmtDate(o.created_at)+'</td><td>'+esc(nm(o.user_id))+'</td><td>'+what+rec+'</td><td>'+money(o.amount)+'</td><td><span class="pill '+(o.status==='paid'?'ok':o.status==='pending'?'warn':'')+'">'+ORD_ST[o.status]+'</span></td><td>'+ship+'</td></tr>'}).join('')+(rows.length?'':'<tr><td colspan="6" class="none">還沒有訂單</td></tr>')+'</tbody></table></div><p class="mfoot">教材付款成功後會自動列為「準備寄出」。寄出後請改成「已寄出」。</p>';
    $$('[data-ful]',body).forEach(function(s){s.addEventListener('change',async function(){
      var u=await sb.from('orders').update({fulfillment:s.value}).eq('id',s.getAttribute('data-ful'));
      if(u.error){toast('更新失敗:'+niceErr(u.error));TABS.o(body)}else{toast('已更新出貨狀態');tiles()}
    })});
  };

  /* --- 會員 --- */
  TABS.m=async function(body){
    var profs=await loadNames();
    var mr=await sb.from('memberships').select('user_id,plan,status,valid_until,source');
    var mm={};(mr.data||[]).forEach(function(x){mm[x.user_id]=x});
    var q='';
    function draw(){
      var list=profs.filter(function(p){return !q||((p.name||'')+(p.email||'')).toLowerCase().indexOf(q)>-1});
      $('#mRows').innerHTML=list.map(function(p){
        var m=mm[p.id],on=m&&new Date(m.valid_until).getTime()+3*864e5>Date.now();
        return '<tr><td>'+esc(p.name||'')+'</td><td>'+esc(p.email)+'</td><td>'+fmtDate(p.created_at)+'</td><td><span class="pill '+(on?'ok':'')+'">'+(on?(m.source==='manual'?'手動開通':planName(m.plan)):'免費')+'</span>'+(m?'<small class="sub"> 到 '+fmtDate(m.valid_until)+(m.status==='cancelled'?'・已取消續約':'')+'</small>':'')+'</td><td>'+(p.role==='admin'?'老師':'<select data-grant="'+p.id+'"><option value="">手動開通…</option><option value="30">30 天</option><option value="90">90 天</option><option value="365">1 年</option></select>'+(on?' <button type="button" class="btn btn-line sm" data-stop="'+p.id+'">停用</button>':''))+'</td></tr>'}).join('')||'<tr><td colspan="5" class="none">沒有符合的會員</td></tr>';
      $$('[data-grant]',body).forEach(function(s){s.addEventListener('change',async function(){
        if(!s.value)return;var uid=s.getAttribute('data-grant'),old=mm[uid],base=old&&new Date(old.valid_until).getTime()>Date.now()?new Date(old.valid_until).getTime():Date.now();
        var until=new Date(base+(+s.value)*864e5).toISOString(),res;
        if(old)res=await sb.from('memberships').update({status:'active',valid_until:until,updated_at:new Date().toISOString()}).eq('user_id',uid);
        else res=await sb.from('memberships').insert({user_id:uid,plan:null,status:'active',valid_until:until,source:'manual'});
        if(res.error){toast('開通失敗:'+niceErr(res.error));return}
        toast('已手動開通');TABS.m(body);tiles();
      })});
      $$('[data-stop]',body).forEach(function(b){b.addEventListener('click',async function(){
        var uid=b.getAttribute('data-stop');
        var res=await sb.from('memberships').update({status:'cancelled',valid_until:new Date(Date.now()-4*864e5).toISOString(),updated_at:new Date().toISOString()}).eq('user_id',uid);
        if(res.error){toast('停用失敗:'+niceErr(res.error));return}
        toast('已停用。若對方是用信用卡訂閱,請另外請他到會員專區取消續約');TABS.m(body);tiles();
      })});
    }
    body.innerHTML='<label class="fld" for="mQ" style="max-width:320px;margin-bottom:12px">搜尋姓名或 Email<input id="mQ" type="search"></label><div class="twrap"><table class="tbl"><thead><tr><th>姓名</th><th>Email</th><th>加入日</th><th>付費會員</th><th></th></tr></thead><tbody id="mRows"></tbody></table></div><p class="mfoot">客人在網站付款成功後,系統會自動開通,這裡不用處理。手動開通只用在退款、補開或贈送的情況。</p>';
    $('#mQ').addEventListener('input',function(){q=this.value.trim().toLowerCase();draw()});
    draw();
  };

  /* --- 教材 --- */
  TABS.p=async function(body){
    var r=await sb.from('products').select('id,kind,name,price,active,sort').order('sort');
    var rows=r.data||[];
    body.innerHTML='<div class="twrap"><table class="tbl"><thead><tr><th>教材</th><th>售價(NT$)</th><th>類型</th><th>上架</th><th></th></tr></thead><tbody>'+rows.map(function(p){
      return '<tr data-prow="'+esc(p.id)+'"><td>'+esc(p.name)+'</td><td><input type="number" min="0" step="10" value="'+p.price+'" data-f="price" style="width:90px"></td><td><select data-f="kind"><option value="physical"'+(p.kind==='physical'?' selected':'')+'>實體書(需寄送)</option><option value="digital"'+(p.kind==='digital'?' selected':'')+'>電子檔</option></select></td><td><input type="checkbox" data-f="active"'+(p.active?' checked':'')+' aria-label="上架"></td><td><button type="button" class="btn btn-line sm" data-save="'+esc(p.id)+'">儲存</button></td></tr>'}).join('')+'</tbody></table></div><p class="mfoot">價格會立刻套用到網站與結帳。已付款的舊訂單金額不受影響。</p>';
    $$('[data-save]',body).forEach(function(b){b.addEventListener('click',async function(){
      var tr=b.closest('tr'),price=parseInt($('[data-f=price]',tr).value,10);
      if(!(price>=0)){toast('請輸入正確的價格');return}
      var u=await sb.from('products').update({price:price,kind:$('[data-f=kind]',tr).value,active:$('[data-f=active]',tr).checked}).eq('id',b.getAttribute('data-save'));
      toast(u.error?'儲存失敗:'+niceErr(u.error):'已儲存');
    })});
  };

  /* --- 課程 --- */
  TABS.c=async function(body){
    var cr=await sb.from('courses').select('id,name,price,status,sort').order('sort');
    var chr=await sb.from('course_chapters').select('id,course_id,position,title,is_preview').order('position');
    var ids=(chr.data||[]).map(function(x){return x.id});
    var vr=ids.length?await sb.from('chapter_videos').select('chapter_id,youtube_id').in('chapter_id',ids):{data:[]};
    var vm={};(vr.data||[]).forEach(function(x){vm[x.chapter_id]=x.youtube_id});
    var h='';
    (cr.data||[]).forEach(function(c){
      var chs=(chr.data||[]).filter(function(x){return x.course_id===c.id});
      h+='<div class="ccfg" data-crow="'+esc(c.id)+'"><div class="ccfg-h"><b>'+esc(c.name)+'</b><label>狀態 <select data-f="status"><option value="draft"'+(c.status==='draft'?' selected':'')+'>籌備中</option><option value="open"'+(c.status==='open'?' selected':'')+'>開放報名</option></select></label><label>價格 NT$ <input type="number" min="0" step="10" data-f="price" value="'+c.price+'" style="width:90px"></label><button type="button" class="btn btn-line sm" data-csave="'+esc(c.id)+'">儲存</button></div><p class="mfoot" style="margin:0 0 8px">價格填 0 代表免費報名。</p>'+
        '<div class="twrap"><table class="tbl"><thead><tr><th>#</th><th>章節</th><th>YouTube 網址或影片代碼</th><th>試看</th><th></th></tr></thead><tbody>'+chs.map(function(ch){
          return '<tr data-ch="'+ch.id+'"><td>'+(ch.position+1)+'</td><td><input data-f="title" value="'+esc(ch.title)+'" maxlength="80"></td><td><input data-f="yt" value="'+esc(vm[ch.id]||'')+'" placeholder="https://youtu.be/…"></td><td><input type="checkbox" data-f="prev"'+(ch.is_preview?' checked':'')+' aria-label="試看"></td><td><button type="button" class="btn btn-line sm" data-chsave="'+ch.id+'">儲存</button></td></tr>'}).join('')+'</tbody></table></div><button type="button" class="btn btn-line sm" data-chadd="'+esc(c.id)+'" style="margin-top:8px">＋ 新增章節</button></div>';
    });
    body.innerHTML=h+'<p class="mfoot">影片請在 YouTube 設為「不公開」,貼上網址即可。只有報名的學生(或標為試看的章節)能取得影片代碼。</p>';
    $$('[data-csave]',body).forEach(function(b){b.addEventListener('click',async function(){
      var box=b.closest('[data-crow]'),price=parseInt($('[data-f=price]',box).value,10);
      if(!(price>=0)){toast('請輸入正確的價格');return}
      var u=await sb.from('courses').update({status:$('[data-f=status]',box).value,price:price}).eq('id',b.getAttribute('data-csave'));
      toast(u.error?'儲存失敗:'+niceErr(u.error):'已儲存課程設定');
    })});
    $$('[data-chsave]',body).forEach(function(b){b.addEventListener('click',async function(){
      var tr=b.closest('tr'),id=+b.getAttribute('data-chsave'),raw=$('[data-f=yt]',tr).value.trim(),yid=parseYt(raw);
      if(raw&&!yid){toast('看不出這是 YouTube 網址,請確認');return}
      var u=await sb.from('course_chapters').update({title:$('[data-f=title]',tr).value.trim()||'未命名章節',is_preview:$('[data-f=prev]',tr).checked}).eq('id',id);
      if(u.error){toast('儲存失敗:'+niceErr(u.error));return}
      var v=yid?await sb.from('chapter_videos').upsert({chapter_id:id,youtube_id:yid},{onConflict:'chapter_id'}):await sb.from('chapter_videos').delete().eq('chapter_id',id);
      toast(v.error?'影片儲存失敗:'+niceErr(v.error):'已儲存章節');
    })});
    $$('[data-chadd]',body).forEach(function(b){b.addEventListener('click',async function(){
      var cid=b.getAttribute('data-chadd'),mx=(chr.data||[]).filter(function(x){return x.course_id===cid}).reduce(function(m,x){return Math.max(m,x.position)},-1);
      var u=await sb.from('course_chapters').insert({course_id:cid,position:mx+1,title:'新章節'});
      if(u.error){toast('新增失敗:'+niceErr(u.error));return}
      TABS.c(body);
    })});
  };

  /* --- 直播 --- */
  TABS.l=async function(body){
    var er=await sb.from('live_events').select('id,title,starts_at').order('starts_at',{ascending:false,nullsFirst:false}).limit(30);
    var ids=(er.data||[]).map(function(x){return x.id});
    var lr=ids.length?await sb.from('live_links').select('event_id,url').in('event_id',ids):{data:[]};
    var lm={};(lr.data||[]).forEach(function(x){lm[x.event_id]=x.url});
    body.innerHTML='<form id="lForm" novalidate style="margin-bottom:18px"><h3>新增會員直播</h3><div class="row2"><label class="fld" for="lTitle">標題<input id="lTitle" maxlength="80" placeholder="例如:10/30 學測國寫衝刺直播"></label><label class="fld" for="lAt">開播時間<input id="lAt" type="datetime-local"></label></div><label class="fld" for="lUrl">會員直播連結(YouTube)<input id="lUrl" placeholder="https://youtube.com/live/…"></label><div class="err" id="lErr" role="alert"></div><button class="btn btn-fill" type="submit">新增</button></form>'+
      '<div class="twrap"><table class="tbl"><thead><tr><th>標題</th><th>開播</th><th>會員連結</th><th></th></tr></thead><tbody>'+(er.data||[]).map(function(e){
        return '<tr data-ev="'+e.id+'"><td>'+esc(e.title)+'</td><td>'+(e.starts_at?esc(fmtDT(e.starts_at)):'')+'</td><td><input data-f="url" value="'+esc(lm[e.id]||'')+'" style="min-width:220px"></td><td><button type="button" class="btn btn-line sm" data-lsave="'+e.id+'">儲存連結</button> <button type="button" class="btn btn-line sm" data-ldel="'+e.id+'">刪除</button></td></tr>'}).join('')+((er.data||[]).length?'':'<tr><td colspan="4" class="none">還沒有直播</td></tr>')+'</tbody></table></div><p class="mfoot">連結只有付費會員(與老師)看得到。公開直播請在「設定」填入 YouTube 頻道網址。</p>';
    function okUrl(u){try{var x=new URL(u);return /^https?:$/.test(x.protocol)}catch(e){return false}}
    $('#lForm').addEventListener('submit',async function(e){
      e.preventDefault();var er2=$('#lErr'),t=$('#lTitle').value.trim(),u=$('#lUrl').value.trim(),at=$('#lAt').value;
      if(!t){er2.textContent='請填寫標題。';return}
      if(!okUrl(u)){er2.textContent='請貼上完整的直播網址(https://…)。';return}
      var ins=await sb.from('live_events').insert({title:t,starts_at:at?new Date(at).toISOString():null}).select('id').single();
      if(ins.error){er2.textContent='新增失敗:'+niceErr(ins.error);return}
      var lk=await sb.from('live_links').insert({event_id:ins.data.id,url:u});
      if(lk.error){await sb.from('live_events').delete().eq('id',ins.data.id);er2.textContent='新增失敗:'+niceErr(lk.error);return}
      toast('已新增直播');TABS.l(body);
    });
    $$('[data-lsave]',body).forEach(function(b){b.addEventListener('click',async function(){
      var id=+b.getAttribute('data-lsave'),u=$('[data-f=url]',b.closest('tr')).value.trim();
      if(!okUrl(u)){toast('請貼上完整的直播網址(https://…)');return}
      var r2=await sb.from('live_links').upsert({event_id:id,url:u},{onConflict:'event_id'});
      toast(r2.error?'儲存失敗:'+niceErr(r2.error):'已更新連結');
    })});
    $$('[data-ldel]',body).forEach(function(b){b.addEventListener('click',async function(){
      if(b.getAttribute('data-ask')!=='1'){b.setAttribute('data-ask','1');b.textContent='再按一次刪除';return}
      var r2=await sb.from('live_events').delete().eq('id',+b.getAttribute('data-ldel'));
      if(r2.error)toast('刪除失敗:'+niceErr(r2.error));else TABS.l(body);
    })});
  };

  /* --- 設定 --- */
  TABS.s=async function(body){
    var pr=await sb.from('plans').select('id,name,amount,period_type,frequency,exec_times,active,sort').order('sort');
    var sr=await sb.from('site_settings').select('key,value');
    var st={};(sr.data||[]).forEach(function(x){st[x.key]=x.value});
    body.innerHTML='<h3>付費會員方案</h3><div class="twrap"><table class="tbl"><thead><tr><th>方案</th><th>金額(NT$)</th><th>扣款週期</th><th>開放</th><th></th></tr></thead><tbody>'+(pr.data||[]).map(function(p){
      return '<tr data-plan="'+esc(p.id)+'"><td>'+esc(p.name)+'</td><td><input type="number" min="1" step="10" data-f="amount" value="'+p.amount+'" style="width:100px"></td><td>每 '+p.frequency+' '+(p.period_type==='Y'?'年':p.period_type==='M'?'個月':'天')+',最多 '+p.exec_times+' 期</td><td><input type="checkbox" data-f="active"'+(p.active?' checked':'')+' aria-label="開放"></td><td><button type="button" class="btn btn-line sm" data-psave="'+esc(p.id)+'">儲存</button></td></tr>'}).join('')+'</tbody></table></div><p class="mfoot">已經在扣款的訂閱者,金額不會跟著改(綠界以下單當時的金額為準)。價格確認後把「開放」打勾,網站才會顯示並開放加入。</p>'+
      '<h3 style="margin-top:22px">網站設定</h3><form id="sForm" class="fm" style="max-width:520px"><label class="fld" style="flex-direction:row;gap:10px;align-items:center"><input type="checkbox" id="sPay"'+(st.payments_enabled===true?' checked':'')+'> 開放線上付款(教材、付費會員、付費課程)</label><label class="fld" for="sLine">LINE 官方帳號連結<input id="sLine" value="'+esc(st.line_url||'')+'" placeholder="https://lin.ee/…"></label><label class="fld" for="sYt">YouTube 頻道網址(公開直播)<input id="sYt" value="'+esc(st.youtube_url||'')+'" placeholder="https://www.youtube.com/@…"></label><div class="err" id="sErr" role="alert"></div><button class="btn btn-fill" type="submit" style="align-self:flex-start">儲存</button></form>';
    $$('[data-psave]',body).forEach(function(b){b.addEventListener('click',async function(){
      var tr=b.closest('tr'),amt=parseInt($('[data-f=amount]',tr).value,10);
      if(!(amt>0)){toast('請輸入正確的金額');return}
      var u=await sb.from('plans').update({amount:amt,active:$('[data-f=active]',tr).checked}).eq('id',b.getAttribute('data-psave'));
      toast(u.error?'儲存失敗:'+niceErr(u.error):'已儲存方案');
    })});
    $('#sForm').addEventListener('submit',async function(e){
      e.preventDefault();var er2=$('#sErr'),a=$('#sLine').value.trim(),b2=$('#sYt').value.trim();
      function ok(u){if(!u)return true;try{return /^https?:$/.test(new URL(u).protocol)}catch(x){return false}}
      if(!ok(a)||!ok(b2)){er2.textContent='請貼上完整網址(https://…),或留空。';return}
      var r2=await sb.from('site_settings').upsert([{key:'payments_enabled',value:$('#sPay').checked,updated_at:new Date().toISOString()},{key:'line_url',value:a,updated_at:new Date().toISOString()},{key:'youtube_url',value:b2,updated_at:new Date().toISOString()}],{onConflict:'key'});
      if(r2.error){er2.textContent='儲存失敗:'+niceErr(r2.error);return}
      er2.textContent='';toast('已儲存');
    });
  };
  onAuth.push(render);render();
}

/* ---------- 聯絡表單 ---------- */
var cf=$('#contactForm');
if(cf)cf.addEventListener('submit',async function(e){
  e.preventDefault();var err=$('#cErr'),hp=$('#cHp');
  if(hp&&hp.value)return;
  if(!$('#cName').value.trim()){err.textContent='請輸入姓名。';return}
  if(!CAN_EMAIL.test($('#cMail').value.trim())){err.textContent='請輸入正確的 Email。';return}
  if(!$('#cMsg').value.trim()){err.textContent='請簡單寫下想詢問的內容。';return}
  if(!sb){err.textContent='留言功能暫時無法使用,請先用 LINE 聯繫我們。';return}
  var btn=cf.querySelector('button[type=submit]');btn.disabled=true;
  var topic=$('#cTopic')?$('#cTopic').value:'';
  var r=await sb.from('contact_messages').insert({name:$('#cName').value.trim().slice(0,60),email:$('#cMail').value.trim().slice(0,120),message:((topic?'【'+topic+'】':'')+$('#cMsg').value.trim()).slice(0,2000)});
  btn.disabled=false;
  if(r.error){err.textContent='送出失敗,請稍後再試或改用 LINE 聯繫。';return}
  err.textContent='';cf.reset();toast('已收到你的留言,我們會盡快回覆');
});

initMembership();initLive();initCourse();initLearn();initCart();initRes();initEssay();initMember();initAdmin();
boot();
