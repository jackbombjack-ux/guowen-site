/* ---------- 水墨 2.0:更細緻的山水(覆寫 scene / heroSVG) ----------
   - 山脈改為「墨暈漸層」:山頭濃、山腳淡,融進雲霧
   - 加上皴法(沿山勢的細筆觸)與勾勒山稜
   - 遠山、中山、近山共四層,中間隔著雲霧;近山帶松林
   - 標題級畫面(hd)另有飛鳥與孤舟 */
function ridge2(r,o){
  var terms=[];for(var i=0;i<3;i++)terms.push({f:o.fr*(1+i*1.9+r()*.7),p:r()*6.283,w:1/(1+i*1.1)});
  var pts=[];
  for(var x=-10;x<=o.W+10;x+=(o.step||8)){
    var v=0,t=0;terms.forEach(function(q){v+=q.w*(1-Math.abs(Math.sin(x*q.f+q.p)));t+=q.w});
    v=Math.pow(v/t,o.sharp||1.6);
    var e=o.env?o.env(x/o.W):1;
    pts.push([x,o.base-o.amp*v*e]);
  }
  var seg=pts.map(function(p){return p[0]+' '+p[1].toFixed(1)}).join(' L');
  return {pts:pts,line:'M'+seg,d:'M-10 '+(o.H+10)+' L'+seg+' L'+(o.W+10)+' '+(o.H+10)+'Z'};
}
/* 一層山:漸層墨色 + 皴筆 + 山稜勾勒。回傳 {svg, pts} */
function mountain(r,id,o,l){
  var R=ridge2(r,{W:o.W,H:o.H,base:l.b+(o.lift||0),amp:l.a*(o.amp||1),fr:l.f,sharp:l.sh,env:o.env,step:o.step});
  var s='<defs><linearGradient id="'+id+'f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--'+l.c+')" stop-opacity="'+l.top+'"/><stop offset="1" style="stop-color:var(--'+l.c+')" stop-opacity="'+l.bot+'"/></linearGradient><clipPath id="'+id+'c"><path d="'+R.d+'"/></clipPath></defs>';
  var n=Math.round((o.W/640)*40*Math.min(1.4,(o.amp||1)+.3)*l.dens),st='';
  for(var k=0;k<n;k++){
    var p=R.pts[Math.floor(r()*R.pts.length)],x=p[0]+(r()-.5)*16,y=p[1]+7+r()*Math.min(80,l.a*.45),len=14+r()*34,bend=(r()-.5)*9;
    st+='M'+x.toFixed(1)+' '+y.toFixed(1)+' q'+bend.toFixed(1)+' '+(len/2).toFixed(1)+' '+(bend*.5+(r()-.5)*4).toFixed(1)+' '+len.toFixed(1)+' ';
  }
  s+='<g filter="url(#'+l.fl+')"><path fill="url(#'+id+'f)" d="'+R.d+'"/>'+
     '<g clip-path="url(#'+id+'c)"><path fill="none" stroke="var(--'+l.c+')" stroke-width="'+(o.W>800?1.1:.8)+'" stroke-linecap="round" opacity="'+l.cun+'" d="'+st+'"/></g>'+
     '<path fill="none" stroke="var(--'+l.c+')" stroke-width="'+(o.W>800?1.5:1.1)+'" stroke-linejoin="round" opacity="'+l.edge+'" d="'+R.line+'"/></g>';
  return {svg:s,pts:R.pts};
}
function miniPine(x,y,s){ // 山稜上的小松:一撇主幹加幾層疏葉
  var d='M'+x.toFixed(1)+' '+y.toFixed(1)+' v-'+(18*s).toFixed(1)+' ';
  for(var k=0;k<3;k++){var w=(9-k*2)*s,yy=y-(6+k*6)*s;d+='M'+(x-w).toFixed(1)+' '+yy.toFixed(1)+' L'+x.toFixed(1)+' '+(yy-8*s).toFixed(1)+' L'+(x+w).toFixed(1)+' '+yy.toFixed(1)+' '}
  return d;
}
function ridgePines(r,pts,count,s0,lo,hi){
  var d='';
  for(var i=0;i<count;i++){var p=pts[Math.floor(lo+r()*(hi-lo))];if(!p)continue;d+=miniPine(p[0],p[1]+3,s0*(.7+r()*.6))}
  return '<path fill="none" stroke="var(--ik3)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" opacity=".7" d="'+d+'"/>';
}
function birds(r,W,H,n){
  var s='<g class="birds">';
  for(var i=0;i<n;i++){var x=W*(.2+r()*.55),y=H*(.12+r()*.2),k=.8+r()*.7;
    s+='<path class="bird" style="--bd:'+(i*-3.1).toFixed(1)+'s" fill="none" stroke="var(--ik3)" stroke-width="'+(1.3*k).toFixed(1)+'" stroke-linecap="round" opacity=".6" d="M'+x.toFixed(0)+' '+y.toFixed(0)+' q'+(5*k).toFixed(1)+' '+(-5*k).toFixed(1)+' '+(10*k).toFixed(1)+' 0 q'+(5*k).toFixed(1)+' '+(-5*k).toFixed(1)+' '+(10*k).toFixed(1)+' 0"/>'}
  return s+'</g>';
}
function boat(x,y,s){
  return '<g class="boat" transform="translate('+x+' '+y+') scale('+s+')"><path d="M-22 0 h44 l-6 6 h-32z" fill="var(--ik3)" opacity=".9"/><path d="M-2 0 v-17" stroke="var(--ik3)" stroke-width="1.4" fill="none"/><path d="M-2 -17 q9 5 7 14 h-7z" fill="var(--ik2)" opacity=".7"/><ellipse cx="0" cy="8" rx="30" ry="2.2" fill="var(--ik2)" opacity=".25"/></g>';
}
function scene(seed,o){
  o=o||{};var r=rng(seed),id='g'+(++INK_N),W=640,H=400,am=o.amp||1,lift=o.lift||0;
  var s='<svg class="sc" viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="'+id+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--sc-top)"/><stop offset="1" style="stop-color:var(--sc-bot)"/></linearGradient></defs><rect width="'+W+'" height="'+H+'" fill="url(#'+id+')"/>';
  if(o.sun){var sx=o.sunx||470,sy=o.suny||96,sr=o.sunr||34;
    s+='<circle class="iks" cx="'+sx+'" cy="'+sy+'" r="'+(sr*2.3)+'" opacity=".13" filter="url(#glow)"/><circle class="iks" cx="'+sx+'" cy="'+sy+'" r="'+sr+'" opacity=".55" filter="url(#soft)"/><circle cx="'+sx+'" cy="'+sy+'" r="'+(sr+9)+'" fill="none" stroke="var(--seal)" stroke-width=".8" opacity=".25"/>';}
  if(o.glow)s+='<circle cx="'+o.glow[0]+'" cy="'+o.glow[1]+'" r="'+o.glow[2]+'" fill="#FFD59A" opacity=".5" filter="url(#glow)"/>';
  var base={W:W,H:H,amp:am,lift:lift,env:o.env,step:8};
  var Ls=[
    {b:206,a:130,f:.010,sh:1.5,c:'ik1',top:.50,bot:.04,shade:.30,crag:.06,fl:'wash',dens:.55,cun:.30,edge:.30},
    {b:256,a:140,f:.0135,sh:1.6,c:'ik1',top:.66,bot:.20,shade:.38,crag:.09,fl:'wash',dens:.8,cun:.40,edge:.40},
    {b:316,a:128,f:.0165,sh:1.7,c:'ik2',top:.78,bot:.42,shade:.46,crag:.11,fl:'wash2',dens:1,cun:.45,edge:.50},
    {b:382,a:88,f:.0205,sh:1.4,c:'ik3',top:.90,bot:.97,shade:.30,crag:.12,fl:'wash2',dens:1.1,cun:.40,edge:.56}];
  var near=null;
  Ls.forEach(function(l,i){
    var m=mountain(r,id+'m'+i,base,l);s+=m.svg;if(i===3)near=m;
    if(i<3)s+='<ellipse fill="url(#fogG)" cx="'+(120+r()*400).toFixed(0)+'" cy="'+(l.b+lift+34)+'" rx="'+(300+r()*80).toFixed(0)+'" ry="'+(34+r()*10).toFixed(0)+'"/>';
  });
  s+=ridgePines(r,near.pts,5+Math.round(r()*3),.62,6,near.pts.length-6);
  if(o.pines){var p='';for(var i=0;i<7;i++)p+=pine(20+i*24+r()*14,396,.55+r()*.5)+' ';s+='<path class="ik3" opacity=".9" d="'+p+'"/>'}
  if(o.hd){s+=rock(r,-20,H+2,150+r()*60,26+r()*10)+rock(r,W-170,H+2,190,22+r()*8);s+=birds(r,W,H,3);if(seed%2===0)s+=boat(150+r()*260,(316+lift+6),.8)}
  s+='<rect width="'+W+'" height="'+H+'" fill="url(#vigG)"/>';
  return s+(o.extra||'')+'</svg>';
}
function heroSVG(){
  var r=rng(11),W=1240,H=560,env=function(u){return 1-.64*Math.min(1,Math.max(0,(u-.06)/.72))};
  var base={W:W,H:H,amp:1,lift:0,env:env,step:10};
  var s='<svg class="sc" viewBox="0 0 1240 560" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="hgBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--sc-top)"/><stop offset="1" style="stop-color:var(--sc-bot)"/></linearGradient><linearGradient id="hgSc" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--sheet)"/><stop offset="1" style="stop-color:var(--sheet-2)"/></linearGradient><clipPath id="hgClip"><path d="M560 -20 C600 100 690 150 690 240 C690 320 630 372 584 428 L682 442 C764 392 804 332 794 246 C786 160 764 92 846 -20Z"/></clipPath></defs><rect width="1240" height="560" fill="url(#hgBg)"/>';
  s+='<circle class="iks" cx="470" cy="92" r="88" opacity=".12" filter="url(#glow)"/><circle class="iks" cx="470" cy="92" r="38" opacity=".5" filter="url(#soft)"/><circle cx="470" cy="92" r="50" fill="none" stroke="var(--seal)" stroke-width="1" opacity=".22"/>';
  s+='<g class="px" data-k="5"><g class="layer-far">'+mountain(r,'hf',base,{b:300,a:340,f:.0080,sh:1.5,c:'ik1',top:.56,bot:.04,shade:.34,crag:.07,fl:'wash',dens:.8,cun:.34,edge:.30}).svg+'</g></g>';
  s+='<g class="layer-mist"><ellipse fill="url(#fogG)" cx="260" cy="262" rx="560" ry="58"/><ellipse fill="url(#fogG)" cx="820" cy="330" rx="520" ry="50"/></g>';
  s+='<g class="px" data-k="10"><g class="layer-mid">'+mountain(r,'hm',base,{b:382,a:330,f:.0100,sh:1.65,c:'ik1',top:.76,bot:.24,shade:.44,crag:.10,fl:'wash',dens:1,cun:.42,edge:.40}).svg+'</g></g>';
  s+='<g class="layer-mist"><ellipse fill="url(#fogG)" cx="360" cy="396" rx="620" ry="52"/></g>';
  var m3=mountain(r,'hn',base,{b:448,a:300,f:.0112,sh:1.7,c:'ik2',top:.86,bot:.50,shade:.52,crag:.12,fl:'wash2',dens:1.1,cun:.46,edge:.52});
  s+='<g class="px" data-k="16"><g class="layer-mid">'+m3.svg+ridgePines(r,m3.pts,5,1.1,14,m3.pts.length-14)+'</g></g>';
  s+='<g class="layer-mist"><ellipse fill="url(#fogG)" cx="640" cy="478" rx="700" ry="46"/></g>';
  var m4=mountain(r,'hz',base,{b:556,a:170,f:.0085,sh:1.15,c:'ik3',top:.92,bot:.97,shade:.32,crag:.12,fl:'wash2',dens:1.2,cun:.40,edge:.58});
  s+='<g class="px" data-k="26"><g class="layer-near">'+m4.svg;
  var p='';for(var i=0;i<12;i++)p+=pine(14+i*26+r()*16,556,.85+r()*.7)+' ';
  s+=rock(r,-30,562,260,70)+rock(r,1010,562,300,56)+'<path class="ik3" d="'+p+'"/><ellipse class="ik3" cx="742" cy="458" rx="70" ry="12" opacity=".8" filter="url(#wash)"/><path class="ik3" d="'+pagoda(742,448,.95)+'"/></g></g>';
  s+=birds(r,W,H,5)+boat(300,402,1.1);
  var cols=['壬戌之秋七月既望','蘇子與客泛舟遊於','赤壁之下清風徐來','水波不興舉酒屬客','誦明月之詩歌窈窕','之章少焉月出於東','山之上徘徊於斗牛'],t='';
  cols.forEach(function(c,k){var x=832-k*31;t+='<text font-size="19" letter-spacing="2" opacity=".62">';Array.from(c).forEach(function(ch,j){t+='<tspan x="'+x+'" y="'+(8+j*24)+'">'+ch+'</tspan>'});t+='</text>'});
  s+='<g class="layer-scroll"><path d="M560 -20 C600 100 690 150 690 240 C690 320 630 372 584 428 L682 442 C764 392 804 332 794 246 C786 160 764 92 846 -20Z" fill="url(#hgSc)" stroke="var(--sheet-line)" stroke-width="1"/><g clip-path="url(#hgClip)"><g transform="rotate(7 720 200) translate(-6 20)">'+t+'</g></g></g>';
  s+='<g class="layer-book">'+bookG(560,462,1.18)+'</g>';
  s+='<rect width="1240" height="560" fill="url(#vigG)"/>';
  return s+'</svg>';
}
/* 頁尾上緣的山影 */
function footerMtn(){
  var r=rng(77),W=1240,H=90,m=ridge2(r,{W:W,H:H,base:78,amp:64,fr:.007,sharp:1.5,step:10}),m2=ridge2(r,{W:W,H:H,base:84,amp:44,fr:.011,sharp:1.6,step:10});
  return '<svg class="f-mtn" viewBox="0 0 1240 90" preserveAspectRatio="none" aria-hidden="true"><path d="'+m.d+'" fill="var(--dark)" opacity=".5"/><path d="'+m2.d+'" fill="var(--dark)"/></svg>';
}
