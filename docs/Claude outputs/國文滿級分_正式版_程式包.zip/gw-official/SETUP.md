# 上線設定步驟

照順序做。每一步完成後再做下一步。標「你需要提供」的,是只有帳號擁有者才能取得的東西。

## 0. 先準備好的帳號

1. GitHub 帳號與一個新的 repo(放這包程式)
2. Supabase 帳號(supabase.com)
3. Google Cloud 帳號(用來建立「Google 登入」的 OAuth 用戶端)
4. 綠界科技特店(收款用,見第 6 步)
5. 網域(例如 chinese-win.tw),可之後再接

## 1. 建立 Supabase 專案

1. 建立專案,區域選 Northeast Asia (Tokyo) 或 Singapore。記下資料庫密碼。
2. 進入 SQL Editor,**依序**貼上並執行:
   `supabase/migrations/20261023000001_schema.sql` → `…02_security.sql` → `…03_storage.sql` → `…04_essay_cleanup.sql` → `supabase/seed.sql`
3. 在 SQL Editor 加入老師的 Google 帳號(可多個,全小寫):
   ```sql
   insert into public.admin_emails (email) values ('老師的gmail@gmail.com');
   ```
   該帳號第一次用 Google 登入網站時,就會自動成為老師。若老師已登入過,執行上面這行也會立即升級。
4. Project Settings → API:記下 `Project URL` 與 `anon public` key(這兩個可以公開)。
   **`service_role` 金鑰絕對不要放進網站或 GitHub。**

## 2. Google 登入

1. Google Cloud Console → API 與服務 → 憑證 → 建立「OAuth 用戶端 ID」(網頁應用程式)。
   - 已授權的重新導向 URI:`https://<你的專案代號>.supabase.co/auth/v1/callback`
   - OAuth 同意畫面:填工作室名稱、客服 Email;網站首頁、隱私權政策、服務條款填網站網址。
   - 同意畫面請「發佈為正式版」,否則只有測試使用者能登入。
2. Supabase → Authentication → Providers → Google:貼上 Client ID 與 Client Secret,啟用。
3. Supabase → Authentication → URL Configuration:
   - Site URL:`https://你的網域`
   - Redirect URLs:加入 `https://你的網域/**`(測試時可再加 `http://localhost:8000/**`)

## 3. 部署後端函式

安裝 Supabase CLI 後,在這個資料夾:

```bash
supabase login
supabase link --project-ref <你的專案代號>
supabase secrets set SITE_URL=https://你的網域 ECPAY_MODE=stage
supabase functions deploy create-order ecpay-return ecpay-period-return cancel-membership
```

- `ECPAY_MODE=stage` 是綠界測試環境,**會自動使用綠界公開的測試商店資料**,不需要你的金鑰,先用它把整條流程測通。
- 若網站同時有 www 與非 www 網址,再加 `EXTRA_ORIGINS=https://www.你的網域`。
- 兩個「綠界通知」函式不需要登入(綠界伺服器沒有登入資訊),安全性來自 CheckMacValue 簽章驗證;`config.toml` 已設定好。

## 4. 發佈網站

1. 編輯 `docs/config.js`,填入 `supabaseUrl` 與 `supabaseAnonKey`(第 1 步記下的兩個值)。
2. 推到 GitHub;Settings → Pages → Source 選 `main` 分支的 `/docs` 資料夾。
3. 接網域:Pages → Custom domain 填網域,並在 `docs/` 放一個 `CNAME` 檔(內容只有網域一行);網域 DNS 依 GitHub 指示設定。勾選 Enforce HTTPS。
4. 網域:sitemap.xml、robots.txt、CNAME 已使用 chineses.win(重新打包時可用環境變數 `GW_DOMAIN` 改)。

若之後改了 `content.py` 或前端程式,重新建置:`GW_PROD=1 python3 build_site.py`(輸出到 `repo/docs`),再把 `config.js` 的兩個值填回去。

## 5. 用老師帳號進後台,補齊內容

登入網站 → 會員專區 → 帳號 → 「老師後台」:

- **設定**:填 LINE、YouTube 頻道連結;「開放線上付款」在綠界完成前保持不勾;確認價格後把兩個付費會員方案的金額改對並勾「開放」。
- **教材**:確認 6 本售價,以及是「實體書(需寄送)」或「電子檔」。
- **課程**:貼上每個章節的 YouTube 網址(影片請設為「不公開」);價格(0 = 免費)與狀態改成「開放報名」。
- **直播**:新增會員直播並貼連結。
- 免費資源 PDF:Supabase → Storage → `resources` bucket 上傳檔案,再到 Table Editor → `resources` 把 `storage_path` 填成檔名。

## 6. 綠界(收款)——可以晚點再做

**沒有綠界也可以先上線**:網站預設「線上付款」是關閉的(後台「設定」的「開放線上付款」沒勾)。關閉時:購物車改成引導客人用 LINE 訂購、付費會員顯示「即將開放」、付費課程不能購買;免費課程、免費資源、作文批改照常運作。老師可在後台「會員」手動開通付費會員、在「訂單」管理出貨。後端函式也會擋下建立訂單。等綠界測試與正式特店都完成後,再到後台勾選開放。

1. **先用測試環境**:第 3 步 `ECPAY_MODE=stage` 已可用。前台下單,跳到綠界測試付款頁,用綠界官方文件提供的測試信用卡付款,確認:
   - 付款後回到「會員專區」顯示付款成功;
   - 付費會員自動開通、課程自動報名、教材訂單出現在後台「訂單」。
   - 在綠界測試後台可手動「模擬付款」,本系統會忽略 SimulatePaid 的通知(避免被偽造)——要測自動開通請用真的測試刷卡流程。
2. **申請正式特店**:一般付款與「信用卡定期定額」要分別申請/審核;付費會員需要後者。
3. 取得正式 MerchantID / HashKey / HashIV 後,由你(帳號擁有者)自己執行:
   ```bash
   supabase secrets set ECPAY_MODE=production ECPAY_MERCHANT_ID=… ECPAY_HASH_KEY=… ECPAY_HASH_IV=…
   ```
   請不要把這三個值貼到聊天或 GitHub。
4. 通知網址(函式已在每筆訂單自動帶入,綠界後台若有欄位要求白名單再填):
   - `https://<專案代號>.supabase.co/functions/v1/ecpay-return`
   - `https://<專案代號>.supabase.co/functions/v1/ecpay-period-return`

## 7. 上線前檢查清單

- [ ] 用一般 Google 帳號走完:登入、領資源、上傳作文、報名課程、買教材、加入會員、取消續約
- [ ] 老師帳號批改作文,學生在會員專區看到評語
- [ ] 非老師帳號打開 `admin.html` 顯示「沒有權限」
- [ ] 未付費帳號在直播專區看不到連結
- [ ] 隱私權政策、服務條款由工作室確認(目前是草案);退換貨規則補上
- [ ] 手機(iPhone Safari、Android Chrome)各測一次作文上傳

## 已知限制與待確認

- **綠界定期定額的細節要用測試環境實測確認**:首期授權是否也送到定期定額通知網址、欄位名稱等,本專案依官方文件實作並有單元測試,但沒有連到真的綠界驗證過。
- 付費會員只支援信用卡(綠界定期定額的限制)。
- 目前沒有自動寄 Email(付款成功信、出貨通知),也沒有電子發票。要的話另行加。
- 教材預設為實體書,結帳會要求收件資料;若是電子檔,後台「教材」改成「電子檔」即可(結帳不再要收件資料,但下載交付機制尚未做)。
- 運費:目前不另外計算。若要收運費,需決定規則後加進後端定價。
- Supabase 免費方案閒置一段時間會暫停,正式營運建議用付費方案。
- HEIC 照片:iPhone 從相簿選取會自動轉為 JPG;直接上傳 HEIC 檔案會被擋並提示。

## 作文批改:分數、範本、Email 通知

- 資料庫:執行 `supabase/migrations/20261023000007_essay_score_templates.sql`(新增分數、已讀欄位與評語範本表,並預設 6 句範本)。
- 老師批改視窗:可填「分數 / 滿分」(留空則不顯示分數);評語範本點一下插入,「＋ 把目前評語存成範本」可新增,「管理」可刪除。
- 學生:會員專區「我的作文」分頁會顯示紅色「新批改」標記與分數,開啟後自動標為已讀。
- Email 通知(選用):部署 Edge Function `notify-graded`,並在 Secrets 設定 `RESEND_API_KEY`(到 resend.com 註冊取得)。
  寄件人預設是 Resend 測試信箱(只能寄給自己);要寄給學生,請在 Resend 驗證 chineses.win 網域,再設定 `RESEND_FROM`,例如 `國文滿級分 <noreply@chineses.win>`。
  沒設定 `RESEND_API_KEY` 時會自動略過,不影響批改;每篇作文只寄一次。
